# Lar dos Idosos Santa Luiza de Marillac — Site Institucional

Site institucional de uma **ILPI (Instituição de Longa Permanência para Idosos) filantrópica** de Juiz de Fora – MG. O objetivo é apresentar a instituição, mostrar transparência na gestão e facilitar doações (materiais e PIX), agendamento de visitas e contato.

> ⚠️ **Status:** projeto em desenvolvimento. Parte do conteúdo (textos institucionais, depoimentos, números de impacto, chave PIX/QR Code e documentos de transparência) é **demonstrativa/provisória** e precisa ser substituída por dados reais antes da publicação. Veja a seção [Pendências antes de publicar](#pendências-antes-de-publicar).

## Páginas

| Rota | Conteúdo |
|---|---|
| `/` (Início) | Hero, diferenciais, notícias, eventos, galeria, depoimentos, mapa, FAQ |
| `#/sobre` | Missão, visão, valores e serviços |
| `#/nossa-historia` | Linha do tempo da instituição |
| `#/corrente-do-bem` | Lista de necessidades, doação material e via PIX, calculadora de impacto |
| `#/transparencia` | Prestação de contas, relatórios e documentos |
| `#/contato` | Formulário (via WhatsApp), endereço, telefone e e-mail |

## Principais recursos

- **Acessibilidade voltada a idosos:** link "pular para o conteúdo", fonte ampliada, alto contraste, suporte a `prefers-reduced-motion`, controle por voz e leitura em voz alta.
- **Corrente do Bem:** lista de necessidades por categoria e prioridade, com fluxo de doação.
- **Calculadora de impacto da doação** e seção de transparência com gráficos.
- **Calendário de eventos**, galeria estilo Instagram, notícias recentes e histórias de moradores.
- **Mapa interativo** (Google Maps), busca central e FAQ.
- **Agendamento de visita e contato** via WhatsApp (`wa.me`) com mensagem pré-preenchida.

## Stack

| Camada | Tecnologia |
|---|---|
| Linguagem | TypeScript (TSX) |
| UI | React 19 |
| Build / dev server | Vite 8 |
| Estilo | Tailwind CSS 4 (`@tailwindcss/vite`), fontes Inter e Manrope |
| Formulários e validação | react-hook-form, zod, @hookform/resolvers |
| Animação, ícones e gráficos | motion, lucide-react, recharts |
| Notificações | react-hot-toast |

É uma **SPA sem backend**. A navegação é feita por estado e `#/rota` (sem React Router), sincronizada com `popstate` e `hashchange`.

## Estrutura do projeto

```
├── index.html
├── public/                  # logo e arquivos estáticos (ex.: logo.png)
├── src/
│   ├── App.tsx              # roteamento por hash e modais globais
│   ├── main.tsx
│   ├── index.css            # tema Tailwind e modos de acessibilidade
│   ├── components/common/   # Header, Footer, modais, seções da home etc.
│   ├── pages/               # Home, Sobre, Nossa História, Corrente do Bem, Transparência, Contato
│   ├── data/                # dados institucionais e de transparência
│   ├── types/               # tipos TypeScript
│   └── utils/               # utilitários (notificações)
├── vite.config.ts
├── tsconfig.json
└── package.json
```

## Como rodar localmente

**Pré-requisito:** Node.js (versão LTS recomendada).

```bash
# 1. Instalar dependências
npm install

# 2. Rodar em desenvolvimento (http://localhost:3000)
npm run dev

# 3. Gerar build de produção
npm run build

# 4. Visualizar o build localmente
npm run preview

# 5. Checar tipos
npm run lint
```

> O repositório também contém um `bun.lock`. Use **npm ou bun**, mas escolha um só e mantenha apenas o lockfile correspondente.

## Dados institucionais

As informações da instituição (nome, endereço, telefone, WhatsApp, e-mail, Instagram, horários, linhas de ônibus) ficam centralizadas em `src/data/institutionalData.ts`, no objeto `INSTITUTION_INFO`. As necessidades da Corrente do Bem, os marcos da história e os documentos de transparência também estão nesse arquivo; os dados de impacto financeiro ficam em `src/data/transparencyImpactData.ts`.

## Pendências antes de publicar

### Doações (crítico)
- [ ] Substituir a chave PIX provisória (hoje é o e-mail da instituição, `INSTITUTION_INFO.email`) pela **chave PIX oficial**.
- [ ] Inserir o **QR Code PIX real** no `DonationModal` (hoje é um placeholder).
- [ ] Confirmar tudo com a diretoria.

### Conteúdo
- [ ] Revisar os itens marcados com `isDemonstrative: true` em `institutionalData.ts`.
- [ ] Homologar missão, visão, valores e marcos históricos (marcados como "provisório").
- [ ] Substituir depoimentos, histórias de moradores, posts de Instagram e números de impacto por conteúdo **real e autorizado**.
- [ ] Adicionar os **PDFs reais** de transparência (hoje existem apenas metadados).
- [ ] Confirmar dados como "mais de 50 anos" e linhas de ônibus.

### Privacidade e LGPD
- [ ] Revisar o texto do `PrivacyModal` com alguém que entenda de LGPD.
- [ ] Obter autorização de uso de imagem e histórias de moradores e responsáveis.
- [ ] Lembrar que os formulários não enviam dados a servidor: tudo passa pelo WhatsApp da instituição.

### Código
- [ ] Adicionar `public/logo.png` e **remover o upload de logo via `localStorage`** (`components/common/Logo.tsx`), que é ferramenta de desenvolvimento.
- [ ] Remover dependências não utilizadas: `@google/genai`, `express` e `dotenv` (o `.env.example` e a `GEMINI_API_KEY` também não são usados pelo site).
- [ ] Decidir o comportamento do tema: `App.tsx` força modo claro, mas `CentralSearchBar` e `VoiceAccessibilityControl` ainda tentam alternar para escuro.
- [ ] Conferir se o projeto compila com as versões atuais (`npm run build` e `npm run lint`), pois `typescript ^7`, `vite ^8` e `@tailwindcss/vite ^4.3` são majors muito novos.
- [ ] Dividir componentes muito grandes (`EventsCalendarSection`, `InstagramGallerySection`, `InteractiveMapSection`, `HomePage`).
- [ ] Revisar o alias `@`, que aponta para a raiz do projeto e não para `src/`.

## Acessibilidade

O projeto prioriza o público idoso, mas ainda precisa de validação:

- O controle por voz usa `SpeechRecognition`, que funciona bem principalmente em Chrome/Edge e exige **HTTPS** e permissão de microfone.
- O modo "alto contraste" aplica apenas `filter: contrast(1.15)` e não garante conformidade com a WCAG.
- Recomenda-se auditoria com leitores de tela e testes com pessoas idosas.

## Serviços externos

Google Fonts, Google Maps (iframe) e links para WhatsApp, Waze, Google Agenda e Instagram. Sem conexão, as fontes caem para o fallback do sistema.

## Limitações conhecidas

- **Rotas por hash** (`/#/transparencia`): sem SEO por página e sem compartilhamento amigável. Se SEO for prioridade, considere React Router com pré-renderização.
- Sem backend: não há registro de doações, visitas ou mensagens.

## Origem

Projeto gerado no Google AI Studio e evoluído a partir daí.

## Licença

A definir pela instituição.
