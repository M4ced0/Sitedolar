import React, { useState, useEffect } from 'react';
import { PageRoute, NeedItem } from './types';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { DonationModal } from './components/common/DonationModal';
import { ScheduleVisitModal } from './components/common/ScheduleVisitModal';
import { PrivacyModal } from './components/common/PrivacyModal';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { NossaHistoriaPage } from './pages/NossaHistoriaPage';
import { CorrenteDoBemPage } from './pages/CorrenteDoBemPage';
import { TransparencyPage } from './pages/TransparencyPage';
import { ContactPage } from './pages/ContactPage';
import { ReadingProgressBar } from './components/common/ReadingProgressBar';
import { VoiceAccessibilityControl } from './components/common/VoiceAccessibilityControl';
import { Toaster } from 'react-hot-toast';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageRoute>('home');
  const [isDonationModalOpen, setIsDonationModalOpen] = useState(false);
  const [isVisitModalOpen, setIsVisitModalOpen] = useState(false);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);
  const [isVoicePanelOpen, setIsVoicePanelOpen] = useState(false);
  const [selectedNeedForDonation, setSelectedNeedForDonation] = useState<NeedItem | null>(null);

  // Guarantee all pages render in crisp, clean Light Mode
  useEffect(() => {
    document.documentElement.classList.remove('dark');
    localStorage.setItem('theme', 'light');
  }, []);

  // Synchronize route with hash or path for seamless history navigation
  useEffect(() => {
    const handleLocationChange = () => {
      const hash = window.location.hash.replace('#/', '').replace('#', '');
      const path = window.location.pathname.replace(/^\//, '');

      const target = hash || path;

      if (target === 'sobre') setCurrentPage('sobre');
      else if (target === 'nossa-historia') setCurrentPage('nossa-historia');
      else if (target === 'corrente-do-bem') setCurrentPage('corrente-do-bem');
      else if (target === 'transparencia') setCurrentPage('transparencia');
      else if (target === 'contato') setCurrentPage('contato');
      else setCurrentPage('home');
    };

    handleLocationChange();
    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const navigateTo = (page: PageRoute) => {
    setCurrentPage(page);
    const hash = page === 'home' ? '' : `#/${page}`;
    window.history.pushState(null, '', hash || window.location.pathname);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const [donationModalOptions, setDonationModalOptions] = useState<{
    tab?: 'material' | 'pix';
    amount?: number;
    impactText?: string;
  } | null>(null);

  const handleOpenDonationModal = (
    optionsOrNeed?: NeedItem | { need?: NeedItem; tab?: 'material' | 'pix'; amount?: number; impactText?: string }
  ) => {
    if (!optionsOrNeed) {
      setSelectedNeedForDonation(null);
      setDonationModalOptions(null);
    } else if ('id' in optionsOrNeed) {
      setSelectedNeedForDonation(optionsOrNeed as NeedItem);
      setDonationModalOptions(null);
    } else {
      setSelectedNeedForDonation(optionsOrNeed.need || null);
      setDonationModalOptions({
        tab: optionsOrNeed.tab,
        amount: optionsOrNeed.amount,
        impactText: optionsOrImpactText(optionsOrNeed.impactText),
      });
    }
    setIsDonationModalOpen(true);
  };

  function optionsOrImpactText(text?: string) {
    return text;
  }

  const handleCloseDonationModal = () => {
    setIsDonationModalOpen(false);
    setSelectedNeedForDonation(null);
    setDonationModalOptions(null);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#27343B] font-body">
      {/* Skip to main content for accessibility */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 z-50 px-4 py-2 bg-[#073B91] text-white rounded-md text-xs font-semibold focus:outline-hidden"
      >
        Pular para o conteúdo principal
      </a>

      {/* Subtle horizontal scroll progress bar */}
      <ReadingProgressBar currentPage={currentPage} />

      {/* Persistent institutional header with Aegis-style utility ribbon */}
      <Header
        currentPage={currentPage}
        onNavigate={navigateTo}
        onOpenDonationModal={() => handleOpenDonationModal()}
        onOpenVisitModal={() => setIsVisitModalOpen(true)}
        onOpenVoiceAccessibility={() => setIsVoicePanelOpen(true)}
      />

      {/* Main page view */}
      <main id="main-content" className="flex-1 w-full" tabIndex={-1}>
        {currentPage === 'home' && (
          <HomePage
            onNavigate={navigateTo}
            onOpenDonationModal={handleOpenDonationModal}
            onOpenVisitModal={() => setIsVisitModalOpen(true)}
          />
        )}
        {currentPage === 'sobre' && (
          <AboutPage
            onNavigate={navigateTo}
            onOpenDonationModal={() => handleOpenDonationModal()}
            onOpenVisitModal={() => setIsVisitModalOpen(true)}
          />
        )}
        {currentPage === 'nossa-historia' && (
          <NossaHistoriaPage
            onNavigate={navigateTo}
            onOpenDonationModal={() => handleOpenDonationModal()}
          />
        )}
        {currentPage === 'corrente-do-bem' && (
          <CorrenteDoBemPage
            onNavigate={navigateTo}
            onOpenDonationModal={handleOpenDonationModal}
          />
        )}
        {currentPage === 'transparencia' && (
          <TransparencyPage
            onNavigate={navigateTo}
            onOpenDonationModal={() => handleOpenDonationModal()}
          />
        )}
        {currentPage === 'contato' && (
          <ContactPage
            onNavigate={navigateTo}
            onOpenPrivacyModal={() => setIsPrivacyModalOpen(true)}
            onOpenVisitModal={() => setIsVisitModalOpen(true)}
          />
        )}
      </main>

      {/* Institutional footer */}
      <Footer
        onNavigate={navigateTo}
        onOpenDonationModal={() => handleOpenDonationModal()}
        onOpenPrivacyModal={() => setIsPrivacyModalOpen(true)}
      />

      {/* Accessibility Voice & Audio Description Control */}
      <VoiceAccessibilityControl
        currentPage={currentPage}
        onNavigate={navigateTo}
        onOpenDonationModal={() => handleOpenDonationModal()}
        onOpenVisitModal={() => setIsVisitModalOpen(true)}
        isOpenExternal={isVoicePanelOpen}
        onToggleExternal={setIsVoicePanelOpen}
      />

      {/* Global Modals */}
      <DonationModal
        isOpen={isDonationModalOpen}
        onClose={handleCloseDonationModal}
        selectedNeed={selectedNeedForDonation}
        initialTab={donationModalOptions?.tab}
        suggestedAmount={donationModalOptions?.amount}
        suggestedImpactText={donationModalOptions?.impactText}
      />

      <ScheduleVisitModal
        isOpen={isVisitModalOpen}
        onClose={() => setIsVisitModalOpen(false)}
      />

      <PrivacyModal
        isOpen={isPrivacyModalOpen}
        onClose={() => setIsPrivacyModalOpen(false)}
      />

      {/* Global Toast Notifications (react-hot-toast) */}
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            borderRadius: '12px',
            background: '#ffffff',
            color: '#27343B',
            boxShadow: '0 10px 30px -5px rgba(0, 0, 0, 0.12), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
            border: '1px solid #E2E8F0',
            fontSize: '14px',
            fontWeight: 500,
          },
          success: {
            iconTheme: {
              primary: '#76A900',
              secondary: '#ffffff',
            },
          },
        }}
      />
    </div>
  );
}
