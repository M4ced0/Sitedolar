import toast from 'react-hot-toast';

export const notifySuccess = (message: string, duration = 4000) => {
  toast.success(message, {
    duration,
    position: 'top-right',
    style: {
      borderRadius: '14px',
      background: '#FFFFFF',
      color: '#27343B',
      border: '1px solid #E2E8F0',
      boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.04)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      fontSize: '14px',
      fontWeight: '500',
      padding: '12px 18px',
    },
    iconTheme: {
      primary: '#76A900',
      secondary: '#FFFFFF',
    },
  });
};

export const notifyInfo = (message: string, duration = 3500) => {
  toast(message, {
    duration,
    position: 'top-right',
    icon: 'ℹ️',
    style: {
      borderRadius: '14px',
      background: '#FFFFFF',
      color: '#073B91',
      border: '1px solid #BFDBFE',
      boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.08)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      fontSize: '14px',
      fontWeight: '500',
      padding: '12px 18px',
    },
  });
};

export const notifyError = (message: string, duration = 4500) => {
  toast.error(message, {
    duration,
    position: 'top-right',
    style: {
      borderRadius: '14px',
      background: '#FFFFFF',
      color: '#991B1B',
      border: '1px solid #FECACA',
      boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.08)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      fontSize: '14px',
      fontWeight: '500',
      padding: '12px 18px',
    },
  });
};
