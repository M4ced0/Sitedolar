export type PageRoute = 'home' | 'sobre' | 'nossa-historia' | 'corrente-do-bem' | 'transparencia' | 'contato';

export interface NeedItem {
  id: string;
  name: string;
  category: 'alimentos' | 'higiene' | 'limpeza' | 'diario' | 'outros';
  categoryLabel: string;
  description: string;
  quantityNeeded?: number;
  unit: string;
  priority: 'alta' | 'media' | 'regular';
  status: 'ativa' | 'em_andamento' | 'atendida';
  isDemonstrative: boolean;
}

export interface TransparencyDoc {
  id: string;
  title: string;
  category: 'prestacao' | 'estatuto' | 'relatorio' | 'certidao' | 'regimento';
  categoryLabel: string;
  year: number;
  month?: string;
  fileSize: string;
  publishDate: string;
  fileType: 'pdf';
  isDemonstrative: boolean;
  summary: string;
}

export interface TimelineMilestone {
  year: string;
  title: string;
  description: string;
  tag: string;
  isDemonstrativeNote?: string;
}

export interface ServiceDifferential {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface ExpenseCategoryImpact {
  id: string;
  name: string;
  value: number;
  percentage: number;
  color: string;
  iconName: string;
  description: string;
  concreteBenefit: string;
}

export interface QuarterlyFinancialReport {
  quarter: string;
  label: string;
  cuidadosAssistenciais: number;
  infraestruturaOperacao: number;
  arrecadacaoTotal: number;
  totalAplicado: number;
}

export interface AnnualImpactSummary {
  year: number;
  totalInvested: number;
  totalDonations: number;
  directCarePercentage: number;
  averageMonthlyPerResident: number;
  activeResidents: number;
  mealsServedAnnual: number;
  nursingCareHoursAnnual: number;
  categories: ExpenseCategoryImpact[];
  quarterly: QuarterlyFinancialReport[];
}
