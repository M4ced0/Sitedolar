import React, { useState, useEffect, useRef } from 'react';
import { Upload, X, Camera } from 'lucide-react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark' | 'monochrome-white';
  showSubtitle?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showUploadButton?: boolean;
  placeholderOnly?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  variant = 'light',
  showSubtitle = true,
  size = 'md',
  showUploadButton = false,
  placeholderOnly = false,
}) => {
  const isDarkBg = variant === 'monochrome-white';
  const blueColor = isDarkBg ? '#FFFFFF' : '#073B91';
  const greenColor = isDarkBg ? '#9FE000' : '#76A900';
  const mutedColor = isDarkBg ? '#E2E8F0' : '#66737A';

  const [originalLogoUrl, setOriginalLogoUrl] = useState<string | null>(null);
  const [imageError, setImageError] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Check for uploaded original logo or static /logo.png
  useEffect(() => {
    // 1. Check local storage if user uploaded original logo in browser
    const stored = localStorage.getItem('original_logo_image');
    if (stored) {
      setOriginalLogoUrl(stored);
      return;
    }

    // 2. Otherwise check if /logo.png exists
    const testImg = new Image();
    testImg.src = '/logo.png';
    testImg.onload = () => {
      setOriginalLogoUrl('/logo.png');
      setImageError(false);
    };
    testImg.onerror = () => {
      // No original logo found yet
      setOriginalLogoUrl(null);
      setImageError(true);
    };

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'original_logo_image') {
        setOriginalLogoUrl(e.newValue);
        setImageError(false);
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          localStorage.setItem('original_logo_image', result);
          setOriginalLogoUrl(result);
          setImageError(false);
          window.dispatchEvent(new Event('original_logo_updated'));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    const handleCustomEvent = () => {
      const stored = localStorage.getItem('original_logo_image');
      setOriginalLogoUrl(stored);
      setImageError(!stored);
    };
    window.addEventListener('original_logo_updated', handleCustomEvent);
    return () => window.removeEventListener('original_logo_updated', handleCustomEvent);
  }, []);

  const handleRemoveUploadedLogo = (e: React.MouseEvent) => {
    e.stopPropagation();
    localStorage.removeItem('original_logo_image');
    setOriginalLogoUrl(null);
    setImageError(true);
    window.dispatchEvent(new Event('original_logo_updated'));
  };

  const imageSizes = {
    sm: 'h-8 max-w-[120px]',
    md: 'h-10 max-w-[160px]',
    lg: 'h-12 max-w-[190px]',
  };

  const titleSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg',
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Hidden file input for original logo upload if user wants to upload directly */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept="image/png,image/jpeg,image/svg+xml,image/webp"
        className="hidden"
        aria-hidden="true"
      />

      {/* Render ORIGINAL logo if available */}
      {originalLogoUrl && !imageError ? (
        <div className="relative shrink-0 flex items-center group">
          <img
            src={originalLogoUrl}
            alt="Logo Original"
            className={`${imageSizes[size]} w-auto object-contain`}
            onError={() => setImageError(true)}
          />
          <button
            type="button"
            onClick={handleRemoveUploadedLogo}
            title="Remover ou trocar logo original"
            className="absolute -top-1.5 -right-1.5 p-0.5 bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      ) : placeholderOnly ? (
        /* SOLICITADO PELO USUÁRIO NO CABEÇALHO: Apenas escrito 'Espaço pra logo' */
        <div
          onClick={(e) => {
            e.stopPropagation();
            fileInputRef.current?.click();
          }}
          className="flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl border-2 border-dashed border-stone-300 bg-stone-50 hover:bg-stone-100 text-[#27343B] font-bold text-xs sm:text-sm tracking-wide transition-all cursor-pointer shadow-2xs group"
          title="Clique para carregar a sua logo original (PNG, JPG ou SVG)"
        >
          <Camera className="w-4 h-4 text-[#76A900] group-hover:scale-110 transition-transform" />
          <span className="whitespace-nowrap">Espaço pra logo</span>
        </div>
      ) : (
        /* Padrão Institucional Completo (usado no Rodapé) */
        <div className="flex flex-col justify-center leading-tight">
          <span
            className="text-[10px] tracking-wider uppercase font-semibold"
            style={{ color: mutedColor }}
          >
            Lar dos Idosos
          </span>
          <span
            className={`font-heading font-bold tracking-tight ${titleSizes[size]}`}
            style={{ color: blueColor }}
          >
            Santa Luiza de Marillac
          </span>
          {showSubtitle && (
            <span
              className="text-[10px] font-medium tracking-wide uppercase mt-0.5"
              style={{ color: greenColor }}
            >
              ILPI Filantrópica · Juiz de Fora - MG
            </span>
          )}
        </div>
      )}

      {/* Optional upload trigger button for testing or inserting original logo */}
      {showUploadButton && !originalLogoUrl && !placeholderOnly && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            fileInputRef.current?.click();
          }}
          className="ml-2 text-[11px] inline-flex items-center gap-1 px-2 py-1 rounded-md bg-stone-100 hover:bg-stone-200 text-[#073B91] border border-stone-200 transition-colors cursor-pointer"
          title="Fazer upload da Logo Original (PNG, JPG ou SVG)"
        >
          <Upload className="w-3 h-3 text-[#76A900]" />
          <span>Inserir Logo Original</span>
        </button>
      )}
    </div>
  );
};
