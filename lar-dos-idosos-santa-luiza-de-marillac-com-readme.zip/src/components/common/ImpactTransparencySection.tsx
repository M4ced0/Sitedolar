import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  HeartPulse,
  Utensils,
  Pill,
  Building2,
  Sparkles,
  Smile,
  ShieldCheck,
  CheckCircle2,
  Heart,
  PieChart as PieChartIcon,
  BarChart3,
  Calendar,
  Info,
  DollarSign,
  ArrowRight,
  Clock,
  ExternalLink,
} from 'lucide-react';
import { TRANSPARENCY_IMPACT_DATA } from '../../data/transparencyImpactData';
import { ExpenseCategoryImpact, PageRoute } from '../../types';

interface ImpactTransparencySectionProps {
  onOpenDonationModal: () => void;
  onNavigate?: (page: PageRoute) => void;
  onSelectTab?: (tab: 'prestacao' | 'documentos') => void;
}

const CATEGORY_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  HeartPulse,
  Utensils,
  Pill,
  Building2,
  Sparkles,
  Smile,
};

export const ImpactTransparencySection: React.FC<ImpactTransparencySectionProps> = ({
  onOpenDonationModal,
  onNavigate,
  onSelectTab,
}) => {
  const [selectedYear, setSelectedYear] = useState<number>(2025);
  const [chartMode, setChartMode] = useState<'both' | 'pie' | 'bar'>('both');
  const [activeCategoryId, setActiveCategoryId] = useState<string>('saude-enfermagem');
  const [hoveredSliceIndex, setHoveredSliceIndex] = useState<number | null>(null);

  const yearData = useMemo(() => {
    return TRANSPARENCY_IMPACT_DATA[selectedYear] || TRANSPARENCY_IMPACT_DATA[2025];
  }, [selectedYear]);

  const activeCategory = useMemo(() => {
    return (
      yearData.categories.find((c) => c.id === activeCategoryId) ||
      yearData.categories[0]
    );
  }, [yearData, activeCategoryId]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const formatShortCurrency = (val: number) => {
    if (val >= 1000) {
      return `R$ ${(val / 1000).toFixed(0)}k`;
    }
    return `R$ ${val}`;
  };

  // Custom Tooltip for Pie Chart in Clean Light Mode
  const CustomPieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload as ExpenseCategoryImpact;
      return (
        <div className="bg-white p-3.5 rounded-xl shadow-xl border border-stone-200 text-xs font-body max-w-xs z-50">
          <div className="flex items-center gap-2 mb-1.5">
            <span
              className="w-3 h-3 rounded-full shrink-0"
              style={{ backgroundColor: data.color }}
            />
            <p className="font-heading font-bold text-stone-900 text-sm">
              {data.name}
            </p>
          </div>
          <div className="flex justify-between items-center py-1 border-b border-stone-100 text-stone-600">
            <span>Investimento Anual:</span>
            <span className="font-bold text-[#073B91]">
              {formatCurrency(data.value)}
            </span>
          </div>
          <div className="flex justify-between items-center py-1 text-stone-600">
            <span>Proporção do Total:</span>
            <span className="font-bold text-[#76A900]">
              {data.percentage}%
            </span>
          </div>
          <p className="mt-2 text-[11px] text-stone-500 italic leading-relaxed border-t border-stone-100 pt-1.5">
            {data.concreteBenefit}
          </p>
        </div>
      );
    }
    return null;
  };

  // Custom Tooltip for Bar Chart in Clean Light Mode
  const CustomBarTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3.5 rounded-xl shadow-xl border border-stone-200 text-xs font-body min-w-[220px] z-50">
          <p className="font-heading font-bold text-stone-900 border-b border-stone-100 pb-1.5 mb-2">
            {label}
          </p>
          <div className="space-y-1.5">
            {payload.map((item: any, idx: number) => (
              <div key={idx} className="flex justify-between items-center gap-3">
                <span className="flex items-center gap-1.5 text-stone-600">
                  <span
                    className="w-2.5 h-2.5 rounded-xs shrink-0"
                    style={{ backgroundColor: item.color }}
                  />
                  <span>{item.name}:</span>
                </span>
                <span className="font-bold text-stone-900">
                  {formatCurrency(item.value)}
                </span>
              </div>
            ))}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <section
      id="transparencia-impacto"
      className="py-12 lg:py-16 bg-white font-body border-b border-stone-200"
    >
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Cabeçalho da Seção de Transparência de Impacto */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-stone-200/80">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Transparência de Impacto & Governança Visual</span>
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-[#27343B] leading-tight">
              Onde Cada Real doado é Transformado em Dignidade
            </h2>
            <p className="text-sm sm:text-base text-[#66737A] leading-relaxed">
              Visualização gráfica interativa da distribuição financeira dos recursos do Lar dos Idosos Santa Luiza de Marillac. Cada centavo é aplicado com prestação de contas aberta e auditada.
            </p>
          </div>

          {/* Seletores de Exercício Contábil e Modo */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {/* Seletor de Ano */}
            <div className="bg-stone-100 p-1 rounded-xl flex items-center border border-stone-200">
              <span className="text-xs font-semibold px-2.5 text-stone-500 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Ano:
              </span>
              {[2025, 2024].map((yr) => (
                <button
                  key={yr}
                  type="button"
                  onClick={() => setSelectedYear(yr)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    selectedYear === yr
                      ? 'bg-[#073B91] text-white shadow-2xs'
                      : 'text-stone-700 hover:text-stone-900'
                  }`}
                >
                  {yr}
                </button>
              ))}
            </div>

            {/* Alternador de Gráficos */}
            <div className="bg-stone-100 p-1 rounded-xl flex items-center border border-stone-200">
              <button
                type="button"
                onClick={() => setChartMode('both')}
                title="Visualizar Gráfico de Pizza e Barras"
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                  chartMode === 'both'
                    ? 'bg-white text-[#073B91] shadow-2xs'
                    : 'text-stone-700 hover:text-stone-900'
                }`}
              >
                <span>Consolidado</span>
              </button>
              <button
                type="button"
                onClick={() => setChartMode('pie')}
                title="Apenas Gráfico de Pizza"
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                  chartMode === 'pie'
                    ? 'bg-white text-[#073B91] shadow-2xs'
                    : 'text-stone-700 hover:text-stone-900'
                }`}
              >
                <PieChartIcon className="w-3.5 h-3.5 text-[#073B91]" />
                <span className="hidden sm:inline">Pizza</span>
              </button>
              <button
                type="button"
                onClick={() => setChartMode('bar')}
                title="Apenas Gráfico de Barras"
                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                  chartMode === 'bar'
                    ? 'bg-white text-[#073B91] shadow-2xs'
                    : 'text-stone-700 hover:text-stone-900'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5 text-[#76A900]" />
                <span className="hidden sm:inline">Barras</span>
              </button>
            </div>
          </div>
        </div>

        {/* 4 Cards de Indicadores de Impacto (KPIs) em Modo Claro */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {/* KPI 1 */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-50/80 to-white border border-blue-100 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#073B91]">
                Assistência Direta
              </span>
              <span className="p-2 rounded-xl bg-blue-100/70 text-[#073B91]">
                <Heart className="w-4 h-4 fill-current" />
              </span>
            </div>
            <p className="font-heading text-2xl sm:text-3xl font-extrabold text-[#27343B]">
              {yearData.directCarePercentage}%
            </p>
            <p className="text-xs text-[#66737A] mt-1">
              Do total aplicado vai direto para saúde, enfermagem e alimentação.
            </p>
          </div>

          {/* KPI 2 */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-lime-50/80 to-white border border-lime-100 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#76A900]">
                Total Investido
              </span>
              <span className="p-2 rounded-xl bg-lime-100/70 text-[#76A900]">
                <DollarSign className="w-4 h-4" />
              </span>
            </div>
            <p className="font-heading text-2xl sm:text-3xl font-extrabold text-[#27343B]">
              {formatCurrency(yearData.totalInvested)}
            </p>
            <p className="text-xs text-[#66737A] mt-1">
              Recursos geridos com lisura no exercício contábil de {yearData.year}.
            </p>
          </div>

          {/* KPI 3 */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-50/80 to-white border border-amber-100 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-700">
                Alimentação & Saúde
              </span>
              <span className="p-2 rounded-xl bg-amber-100/70 text-amber-700">
                <Utensils className="w-4 h-4" />
              </span>
            </div>
            <p className="font-heading text-2xl sm:text-3xl font-extrabold text-[#27343B]">
              {yearData.mealsServedAnnual.toLocaleString('pt-BR')}+
            </p>
            <p className="text-xs text-[#66737A] mt-1">
              Refeições balanceadas supervisionadas por nutricionista ao ano.
            </p>
          </div>

          {/* KPI 4 */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-purple-50/80 to-white border border-purple-100 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-purple-700">
                Cuidado Integral
              </span>
              <span className="p-2 rounded-xl bg-purple-100/70 text-purple-700">
                <Clock className="w-4 h-4" />
              </span>
            </div>
            <p className="font-heading text-2xl sm:text-3xl font-extrabold text-[#27343B]">
              {yearData.nursingCareHoursAnnual.toLocaleString('pt-BR')} h
            </p>
            <p className="text-xs text-[#66737A] mt-1">
              Plantão de enfermagem ininterrupto 24 horas por dia, 365 dias.
            </p>
          </div>
        </div>

        {/* Área de Visualização com Recharts */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-10">
          {/* Painel do Gráfico de Pizza */}
          {(chartMode === 'both' || chartMode === 'pie') && (
            <div
              className={`bg-[#F5F8F0]/50 rounded-3xl p-6 sm:p-7 border border-stone-200/90 transition-all ${
                chartMode === 'both' ? 'lg:col-span-7' : 'lg:col-span-12'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
                <div>
                  <div className="flex items-center gap-2">
                    <PieChartIcon className="w-5 h-5 text-[#073B91]" />
                    <h3 className="font-heading text-lg sm:text-xl font-bold text-[#27343B]">
                      Distribuição de Gastos & Investimentos
                    </h3>
                  </div>
                  <p className="text-xs text-[#66737A] mt-0.5">
                    Exercício {yearData.year} · Clique ou passe o mouse em uma categoria para inspecionar
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#073B91] bg-white px-3 py-1.5 rounded-full border border-stone-200 self-start sm:self-auto">
                  Total: {formatCurrency(yearData.totalInvested)}
                </span>
              </div>

              {/* Gráfico Recharts Pie */}
              <div className="h-[280px] sm:h-[320px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip content={<CustomPieTooltip />} />
                    <Pie
                      data={yearData.categories}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={65}
                      outerRadius={105}
                      paddingAngle={3}
                      onClick={(entry: any) => {
                        const targetId = entry?.payload?.id || entry?.id;
                        if (targetId) setActiveCategoryId(targetId);
                      }}
                      onMouseEnter={(_, index) => setHoveredSliceIndex(index)}
                      onMouseLeave={() => setHoveredSliceIndex(null)}
                      cursor="pointer"
                    >
                      {yearData.categories.map((entry, index) => {
                        const isSelected = entry.id === activeCategoryId;
                        const isHovered = hoveredSliceIndex === index;
                        return (
                          <Cell
                            key={`cell-${entry.id}`}
                            fill={entry.color}
                            stroke={isSelected || isHovered ? '#FFFFFF' : 'transparent'}
                            strokeWidth={isSelected ? 3 : 1}
                            className="transition-all duration-200"
                            style={{
                              filter: isSelected ? 'drop-shadow(0px 4px 8px rgba(0,0,0,0.2))' : undefined,
                              transform: isSelected ? 'scale(1.03)' : undefined,
                              transformOrigin: 'center center',
                            }}
                          />
                        );
                      })}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>

                {/* Centro do Donut com Categoria Ativa */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center px-4">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-stone-500">
                    Selecionado
                  </span>
                  <span className="font-heading font-extrabold text-xl sm:text-2xl text-[#27343B]">
                    {activeCategory.percentage}%
                  </span>
                  <span className="text-[11px] font-medium text-stone-600 max-w-[130px] truncate">
                    {activeCategory.name}
                  </span>
                </div>
              </div>

              {/* Lista Rápida Interativa das Categorias */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-4 pt-4 border-t border-stone-200">
                {yearData.categories.map((cat) => {
                  const isSelected = cat.id === activeCategoryId;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setActiveCategoryId(cat.id)}
                      className={`text-left p-2.5 rounded-xl text-xs transition-all border cursor-pointer ${
                        isSelected
                          ? 'bg-white border-[#073B91] shadow-xs'
                          : 'bg-white/70 border-stone-200/80 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: cat.color }}
                        />
                        <span className="font-bold text-[#27343B] truncate">
                          {cat.percentage}%
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-600 line-clamp-1">
                        {cat.name}
                      </p>
                      <p className="text-[10px] font-mono text-stone-400">
                        {formatShortCurrency(cat.value)}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Painel do Gráfico de Barras */}
          {(chartMode === 'both' || chartMode === 'bar') && (
            <div
              className={`bg-[#F5F8F0]/50 rounded-3xl p-6 sm:p-7 border border-stone-200/90 transition-all ${
                chartMode === 'both' ? 'lg:col-span-5' : 'lg:col-span-12'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
                <div>
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-[#76A900]" />
                    <h3 className="font-heading text-lg sm:text-xl font-bold text-[#27343B]">
                      Evolução Trimestral
                    </h3>
                  </div>
                  <p className="text-xs text-[#66737A] mt-0.5">
                    Comparativo de aplicação ao longo de {yearData.year}
                  </p>
                </div>
              </div>

              {/* Gráfico Recharts Bar */}
              <div className="h-[280px] sm:h-[320px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={yearData.quarterly}
                    margin={{ top: 15, right: 10, left: -15, bottom: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="#E2E8F0"
                    />
                    <XAxis
                      dataKey="quarter"
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      axisLine={{ stroke: '#CBD5E1' }}
                      tickLine={false}
                    />
                    <YAxis
                      tickFormatter={formatShortCurrency}
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip content={<CustomBarTooltip />} />
                    <Legend
                      wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                      iconType="circle"
                    />
                    <Bar
                      dataKey="cuidadosAssistenciais"
                      name="Cuidados de Saúde & Nutrição"
                      fill="#073B91"
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar
                      dataKey="infraestruturaOperacao"
                      name="Manutenção & Operação"
                      fill="#D97706"
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar
                      dataKey="arrecadacaoTotal"
                      name="Doações & Convênios"
                      fill="#76A900"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Resumo do Balanço Trimestral */}
              <div className="mt-4 pt-4 border-t border-stone-200 text-xs text-[#66737A] flex items-center justify-between">
                <span>Saldo positivo reinvestido no fundo de reserva da ILPI</span>
                <span className="font-semibold text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Conselho Fiscal Homologado
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Detalhamento da Categoria Selecionada (Spotlight de Impacto) */}
        <div className="bg-gradient-to-r from-blue-50/70 via-stone-50 to-lime-50/70 rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs mb-10">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="flex items-start gap-4">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-md"
                style={{ backgroundColor: activeCategory.color }}
              >
                {(() => {
                  const Icon = CATEGORY_ICONS[activeCategory.iconName] || HeartPulse;
                  return <Icon className="w-7 h-7" />;
                })()}
              </div>

              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className="text-xs font-bold px-2.5 py-0.5 rounded-full text-white"
                    style={{ backgroundColor: activeCategory.color }}
                  >
                    {activeCategory.percentage}% do Orçamento
                  </span>
                  <span className="text-xs font-mono font-bold text-stone-900">
                    {formatCurrency(activeCategory.value)} / ano
                  </span>
                  <span className="text-xs text-stone-400">·</span>
                  <span className="text-xs text-stone-500 font-medium">
                    Exercício {yearData.year}
                  </span>
                </div>

                <h3 className="font-heading text-xl sm:text-2xl font-bold text-[#27343B]">
                  {activeCategory.name}
                </h3>

                <p className="text-xs sm:text-sm text-[#66737A] max-w-3xl leading-relaxed">
                  {activeCategory.description}
                </p>

                <div className="pt-2 flex items-center gap-2 text-xs font-semibold text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Impacto Concreto: {activeCategory.concreteBenefit}</span>
                </div>
              </div>
            </div>

            {/* Ações Relacionadas à Categoria */}
            <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0 lg:min-w-[220px]">
              <button
                type="button"
                onClick={onOpenDonationModal}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#073B91] hover:bg-[#052c6e] text-white text-xs font-bold transition-all shadow-md hover:shadow-lg cursor-pointer"
              >
                <Heart className="w-4 h-4 fill-current text-white" />
                <span>Apoiar com Doação</span>
              </button>

              {onSelectTab && (
                <button
                  type="button"
                  onClick={() => {
                    onSelectTab('prestacao');
                    const el = document.getElementById('documentos-contabeis');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white text-stone-700 hover:text-[#073B91] border border-stone-200 text-xs font-semibold transition-all hover:bg-stone-50 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Ver Balancete Oficial</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Banner Informativo de Prestação de Contas Rigorosa */}
        <div className="p-5 rounded-2xl bg-[#F5F8F0] border border-stone-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs font-body">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-[#073B91] shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-[#27343B]">
                Compromisso com Auditoria e Ética Pública
              </p>
              <p className="text-[#66737A] mt-0.5">
                Todos os demonstrativos são registrados sob as normas contábeis do Terceiro Setor (NBC TG 1000) e fiscalizados pelo Ministério Público e Conselho Municipal dos Direitos da Pessoa Idosa de Juiz de Fora.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                const el = document.getElementById('documentos-contabeis');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#073B91] hover:underline cursor-pointer"
            >
              <span>Acessar Documentos e PDFs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
