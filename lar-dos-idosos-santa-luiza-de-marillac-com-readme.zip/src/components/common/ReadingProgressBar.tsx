import React, { useState, useEffect } from 'react';

interface ReadingProgressBarProps {
  currentPage: string;
}

export const ReadingProgressBar: React.FC<ReadingProgressBarProps> = ({ currentPage }) => {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const calculateScrollProgress = () => {
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;
      const scrollTop = window.scrollY || document.documentElement.scrollTop;

      const totalScrollableDistance = documentHeight - windowHeight;

      if (totalScrollableDistance <= 0) {
        setScrollProgress(0);
        return;
      }

      const progress = (scrollTop / totalScrollableDistance) * 100;
      setScrollProgress(Math.min(100, Math.max(0, progress)));
    };

    // Calculate immediately on mount or page change
    calculateScrollProgress();

    window.addEventListener('scroll', calculateScrollProgress, { passive: true });
    window.addEventListener('resize', calculateScrollProgress, { passive: true });

    return () => {
      window.removeEventListener('scroll', calculateScrollProgress);
      window.removeEventListener('resize', calculateScrollProgress);
    };
  }, [currentPage]);

  return (
    <div
      aria-hidden="true"
      className="fixed top-0 left-0 right-0 z-[60] h-[3px] bg-transparent pointer-events-none"
    >
      <div
        className="h-full bg-gradient-to-r from-[#76A900] via-[#86be00] to-[#073B91] transition-transform duration-75 ease-out origin-left shadow-xs"
        style={{
          transform: `scaleX(${scrollProgress / 100})`,
        }}
      />
    </div>
  );
};
