import React, { useState } from 'react';
import {
  Heart,
  Quote,
  Sparkles,
  BookOpen,
  Calendar,
  X,
  Smile,
  Flower2,
  Music,
  Coffee,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  User,
  Camera,
  Image as ImageIcon,
} from 'lucide-react';
import { WireframePlaceholder } from './WireframePlaceholder';

export interface ResidentStory {
  id: string;
  name: string;
  popularName: string;
  age: number;
  timeAtHome: string;
  tag: string;
  origin: string;
  passion: string;
  quote: string;
  shortBio: string;
  fullBio: string[];
  favoriteMoments: string[];
  photoUrl: string;
  photoAlt: string;
  category: 'memoria' | 'arte' | 'musica' | 'jardim';
}

export const RESIDENT_STORIES: ResidentStory[] = [
  {
    id: 'dona-maria-lourdes',
    name: 'Maria de Lourdes Rezende',
    popularName: 'Dona Lourdinha',
    age: 84,
    timeAtHome: '4 anos no Lar',
    tag: 'Memórias & Educação',
    origin: 'Natural de Juiz de Fora (MG)',
    passion: 'Professora primária aposentada, leitora ávida e contadora de histórias',
    quote:
      'Aqui redescobri a alegria de conversar todos os dias. O sol da manhã no pátio e a amizade dos cuidadores aquecem meu coração. Me sinto cuidada como em família.',
    shortBio:
      'Lecionou por mais de 35 anos em escolas públicas da Zona da Mata mineira. No Lar, lidera a roda de leitura semanal e adora declamar poesias para os colegas.',
    fullBio: [
      'Nascida em Juiz de Fora, Dona Lourdinha dedicou mais de três décadas de sua vida à alfabetização de crianças no bairro Mariano Procópio.',
      'Ao chegar ao Lar Santa Luiza de Marillac em 2022, encontrou não apenas um espaço seguro e acompanhamento médico contínuo, mas uma nova plateia afetuosa para seus livros favoritos.',
      'Hoje, ela é a guardiã da pequena biblioteca do Lar, onde organiza momentos semanais de leitura partilhada e declama versos de Carlos Drummond de Andrade e Cecília Meireles.',
    ],
    favoriteMoments: [
      'Café da tarde compartilhado sob a sombra dos ipês',
      'Roda de leitura e declamação de poesias nas terças-feiras',
      'Visita dos estudantes voluntários de Juiz de Fora',
    ],
    photoUrl: '', // Wireframe: Inserir foto de Dona Lourdinha (800x800px)
    photoAlt: 'Retrato de Dona Maria de Lourdes',
    category: 'memoria',
  },
  {
    id: 'seu-jose-antonio',
    name: 'José Antônio de Oliveira',
    popularName: 'Seu Zé da Gaita',
    age: 79,
    timeAtHome: '3 anos no Lar',
    tag: 'Música & Convivência',
    origin: 'Natural de Juiz de Fora (MG)',
    passion: 'Ex-ferroviário da Leopoldina e tocador autodidata de gaita de boca',
    quote:
      'A música traz de volta os melhores anos da minha vida. Quando toco uma moda antiga no salão, vejo todo mundo sorrindo e batendo palma. Isso não tem preço.',
    shortBio:
      'Trabalhou com orgulho nos trilhos de Minas Gerais. Sua gaita de boca é a trilha sonora dos finais de tarde no pátio e das comemorações de aniversário dos colegas.',
    fullBio: [
      'Seu José Antônio acompanhou o desenvolvimento ferroviário de Minas Gerais durante quase 40 anos como técnico de manutenção de locomotivas.',
      'Aprendeu a tocar harmônica ainda jovem ouvindo o rádio de pilha nas estações de trem. Sua precisão e ritmo animam qualquer ambiente.',
      'No Lar Santa Luiza de Marillac, recebeu assistência de fisioterapia e enfermagem que lhe devolveram a agilidade nas mãos e o ânimo de viver.',
    ],
    favoriteMoments: [
      'Apresentações espontâneas de gaita no pátio central',
      'Sessões de fisioterapia preventiva com a equipe multidisciplinar',
      'Conversas sobre a história ferroviária de Juiz de Fora',
    ],
    photoUrl: '', // Wireframe: Inserir foto de Seu José Antônio (800x800px)
    photoAlt: 'Retrato de Seu José Antônio',
    category: 'musica',
  },
  {
    id: 'dona-geralda-barbosa',
    name: 'Geralda Maria Barbosa',
    popularName: 'Dona Geraldinha',
    age: 88,
    timeAtHome: '5 anos no Lar',
    tag: 'Arte & Artesanato',
    origin: 'Interior de Minas Gerais',
    passion: 'Bordadeira de ponto de cruz, contadora de causos e devota vicentina',
    quote:
      'Cada ponto do bordado é uma oração por quem ajuda o Lar. Não me sinto sozinha um único dia: aqui nós somos respeitados pelo que somos.',
    shortBio:
      'Criou cinco filhos com seu trabalho artesanal. Hoje, seus panos bordados enfeitam o refeitório e são entregues como lembrança afetuosa a doadores e benfeitores.',
    fullBio: [
      'Com mãos habilidosas que atravessaram gerações, Dona Geraldinha é exemplo de resiliência e amor ao próximo no Lar Santa Luiza.',
      'Sempre atenta às celebrações vicentinas, ela dedica parte de suas manhãs a ensinar técnicas de bordado simples a outras residentes e voluntárias.',
      'Sua alimentação balanceada e o acompanhamento nutricional dedicado permitiram que ela mantivesse excelente vitalidade e autonomia.',
    ],
    favoriteMoments: [
      'Oficina de artesanato e bordado comunitário',
      'Momentos de oração ecumênica na capela institucional',
      'Receber cartões e cartas de benfeitores do Lar',
    ],
    photoUrl: '', // Wireframe: Inserir foto de Dona Geraldinha
    photoAlt: 'Retrato de Dona Geralda Barbosa',
    category: 'arte',
  },
  {
    id: 'seu-benedito-oliveira',
    name: 'Benedito Carlos Silveira',
    popularName: 'Seu Dito',
    age: 82,
    timeAtHome: '2 anos no Lar',
    tag: 'Natureza & Xadrez',
    origin: 'Matias Barbosa (MG)',
    passion: 'Agricultor aposentado, mestre de xadrez do Lar e jardineiro dedicado',
    quote:
      'A terra ensina a ter paciência. Ver as mudas de hortelã e couve crescerem na horta do Lar me dá a certeza de que a vida sempre floresce de novo.',
    shortBio:
      'Cuida diariamente da horta de ervas medicinais e temperos do Lar. Nos fins de tarde, desafia voluntários e funcionários em partidas estratégicas de damas e xadrez.',
    fullBio: [
      'Após uma vida de trabalho dedicada à agricultura familiar, Seu Benedito encontrou no Lar Santa Luiza um refúgio acolhedor com verde e tranquilidade.',
      'Com o auxílio da equipe de terapia ocupacional, ele idealizou canteiros suspensos de horta orgânica que hoje abastecem a cozinha com temperos frescos.',
      'Seu senso de humor e espírito acolhedor tornam suas partidas de xadrez na varanda um ponto de encontro favorito de residentes e visitantes.',
    ],
    favoriteMoments: [
      'Rega matinal das mudas da horta comunitária',
      'Partidas de xadrez na varanda com estudantes da UFJF',
      'Almoços com temperos frescos colhidos por suas próprias mãos',
    ],
    photoUrl: '', // Wireframe: Inserir foto de Seu Benedito
    photoAlt: 'Retrato de Seu Benedito',
    category: 'jardim',
  },
];

interface ResidentLifeStoriesProps {
  onOpenVisitModal?: () => void;
  onOpenDonationModal?: () => void;
}

export const ResidentLifeStories: React.FC<ResidentLifeStoriesProps> = ({
  onOpenVisitModal,
  onOpenDonationModal,
}) => {
  const [selectedResident, setSelectedResident] = useState<ResidentStory | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<'todos' | 'memoria' | 'musica' | 'arte' | 'jardim'>('todos');

  const filteredStories =
    selectedFilter === 'todos'
      ? RESIDENT_STORIES
      : RESIDENT_STORIES.filter((s) => s.category === selectedFilter);

  return (
    <section
      id="historias-de-vida"
      aria-label="Histórias de Vida dos Residentes"
      className="py-20 lg:py-28 bg-gradient-to-b from-[#FAFBF7] via-[#F2F7EC]/60 to-[#FAFBF7] border-b border-stone-200/80 font-body"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header da Seção */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl space-y-3">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#76A900]/15 border border-[#76A900]/30 text-xs font-bold tracking-wider uppercase text-[#4d7000] font-body shadow-2xs">
              <Heart className="w-3.5 h-3.5 text-[#76A900] fill-[#76A900]/20" />
              <span>Humanização & Biografias dos Residentes</span>
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-[#27343B] tracking-tight leading-[1.15] text-balance">
              Histórias de Vida que Inspiram Nosso Cuidado
            </h2>
            <p className="text-base sm:text-lg text-[#66737A] leading-relaxed">
              No Lar Santa Luiza de Marillac, cada morador carrega décadas de sabedoria, memórias e talentos. Conheça um pouco da trajetória de quem faz da nossa casa um verdadeiro lar em Juiz de Fora.
            </p>
          </div>

          {/* Filtros por Afinidade */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setSelectedFilter('todos')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                selectedFilter === 'todos'
                  ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                  : 'bg-[#F5F8F0] text-[#27343B] hover:bg-stone-200'
              }`}
            >
              Todos ({RESIDENT_STORIES.length})
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('memoria')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
                selectedFilter === 'memoria'
                  ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                  : 'bg-[#F5F8F0] text-[#27343B] hover:bg-stone-200'
              }`}
            >
              <BookOpen className="w-3 h-3" />
              <span>Memórias</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('musica')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
                selectedFilter === 'musica'
                  ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                  : 'bg-[#F5F8F0] text-[#27343B] hover:bg-stone-200'
              }`}
            >
              <Music className="w-3 h-3" />
              <span>Música</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('arte')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
                selectedFilter === 'arte'
                  ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                  : 'bg-[#F5F8F0] text-[#27343B] hover:bg-stone-200'
              }`}
            >
              <Smile className="w-3 h-3" />
              <span>Artesanato</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('jardim')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all ${
                selectedFilter === 'jardim'
                  ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                  : 'bg-[#F5F8F0] text-[#27343B] hover:bg-stone-200'
              }`}
            >
              <Flower2 className="w-3 h-3" />
              <span>Natureza</span>
            </button>
          </div>
        </div>

        {/* Grade de Cards com Fotos e Biografias */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {filteredStories.map((resident) => (
            <div
              key={resident.id}
              className="group bg-[#F5F8F0]/50 hover:bg-white rounded-3xl border border-stone-200/80 hover:border-stone-300 shadow-2xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between overflow-hidden"
            >
              <div>
                {/* Imagem do Residente -> Wireframe */}
                <div className="relative p-2">
                  <WireframePlaceholder
                    label={`Foto: ${resident.popularName}`}
                    suggestedDimensions="800 × 800 px"
                    aspectRatio="aspect-4/3"
                    type="card"
                    slotId={`residente-${resident.id}`}
                    notes={`${resident.name} (${resident.age} anos)`}
                    className="w-full h-full"
                  />
                  {/* Badge de Destaque */}
                  <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-full text-[11px] font-semibold text-[#073B91] flex items-center gap-1 shadow-2xs border border-slate-200">
                    <Heart className="w-3 h-3 text-[#76A900] fill-[#76A900]/20" />
                    <span>{resident.tag}</span>
                  </div>
                </div>

                {/* Conteúdo do Card */}
                <div className="p-6 space-y-4">
                  <div>
                    <div className="flex items-baseline justify-between gap-2">
                      <h3 className="font-heading font-bold text-xl text-[#27343B] group-hover:text-[#073B91] transition-colors">
                        {resident.popularName}
                      </h3>
                      <span className="text-xs font-semibold text-stone-500 font-mono">
                        {resident.age} anos
                      </span>
                    </div>
                    <p className="text-xs text-[#073B91] font-medium mt-0.5">
                      {resident.passion}
                    </p>
                  </div>

                  {/* Citação Direta do Morador */}
                  <div className="relative bg-white/80 p-3.5 rounded-2xl border border-stone-200/60">
                    <Quote className="w-4 h-4 text-[#76A900] opacity-60 mb-1" />
                    <p className="text-xs italic text-[#4A5568] leading-relaxed line-clamp-3">
                      "{resident.quote}"
                    </p>
                  </div>

                  {/* Breve Biografia */}
                  <p className="text-xs text-[#66737A] leading-relaxed line-clamp-3">
                    {resident.shortBio}
                  </p>
                </div>
              </div>

              {/* Ação Inferior: Abrir Biografia Completa */}
              <div className="p-6 pt-0">
                <button
                  type="button"
                  onClick={() => setSelectedResident(resident)}
                  className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-semibold text-[#073B91] bg-white group-hover:bg-[#073B91] group-hover:text-white border border-stone-300 group-hover:border-[#073B91] transition-all shadow-2xs"
                >
                  <span>Conhecer história completa</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Rodapé da Seção com Nota Humanitária e Botões de Ação */}
        <div className="mt-14 p-6 sm:p-8 bg-[#F5F8F0] rounded-3xl border border-stone-200/80 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white text-[#76A900] border border-stone-200 flex items-center justify-center shrink-0 shadow-2xs">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="font-heading font-bold text-base text-[#27343B]">
                Cuidado com Dignidade, Autonomia e Consentimento
              </h4>
              <p className="text-xs sm:text-sm text-[#66737A] max-w-2xl leading-relaxed">
                As histórias e imagens aqui compartilhadas celebram a individualidade de cada idoso, com respeito irrestrito à sua privacidade, autorização familiar e aos princípios vicentinos de caridade e valorização da vida humana.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 w-full sm:w-auto">
            {onOpenVisitModal && (
              <button
                type="button"
                onClick={onOpenVisitModal}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-xl shadow-2xs transition-colors"
              >
                <Calendar className="w-4 h-4" />
                <span>Agendar Visita ao Lar</span>
              </button>
            )}

            {onOpenDonationModal && (
              <button
                type="button"
                onClick={onOpenDonationModal}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold text-[#073B91] bg-white hover:bg-stone-100 border border-stone-300 rounded-xl shadow-2xs transition-colors"
              >
                <Heart className="w-4 h-4 text-[#76A900]" />
                <span>Apoiar na Corrente do Bem</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* MODAL DETALHADO: BIOGRAFIA COMPLETA DO RESIDENTE */}
      {selectedResident && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200"
          onClick={() => setSelectedResident(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-stone-200 shadow-2xl p-6 sm:p-8 space-y-6 relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Botão Fechar */}
            <button
              type="button"
              onClick={() => setSelectedResident(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-stone-400 hover:text-[#27343B] hover:bg-stone-100 transition-colors"
              aria-label="Fechar modal de história"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Cabeçalho do Modal com Wireframe e Identificação */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 pt-2">
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden shrink-0 border-2 border-dashed border-slate-300 bg-slate-100 flex flex-col items-center justify-center p-2 text-center shadow-xs">
                <User className="w-8 h-8 text-slate-400 mb-1" />
                <span className="text-[10px] font-bold text-slate-600 uppercase">
                  Wireframe
                </span>
                <span className="text-[9px] text-slate-400 font-mono">
                  800 × 800 px
                </span>
              </div>

              <div className="text-center sm:text-left space-y-1.5 flex-1">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#76A900]/15 text-[#5e8700]">
                  <Sparkles className="w-3 h-3" />
                  <span>{selectedResident.tag}</span>
                </div>
                <h3 className="font-heading font-bold text-2xl text-[#27343B]">
                  {selectedResident.name}
                </h3>
                <p className="text-xs text-[#073B91] font-semibold">
                  Conhecido carinhosamente como {selectedResident.popularName} · {selectedResident.age} anos
                </p>
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs text-[#66737A] pt-1">
                  <span>{selectedResident.origin}</span>
                  <span>•</span>
                  <span>{selectedResident.timeAtHome}</span>
                </div>
              </div>
            </div>

            {/* Citação em Destaque */}
            <div className="bg-[#F5F8F0] p-4 sm:p-5 rounded-2xl border border-stone-200/80">
              <Quote className="w-6 h-6 text-[#76A900] mb-2 opacity-80" />
              <p className="text-sm sm:text-base italic text-[#27343B] leading-relaxed">
                "{selectedResident.quote}"
              </p>
            </div>

            {/* Texto Biográfico Completo */}
            <div className="space-y-3 text-sm text-[#4A5568] leading-relaxed">
              <h4 className="font-heading font-bold text-base text-[#27343B] flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-[#073B91]" />
                <span>Trajetória e Vida no Lar</span>
              </h4>
              {selectedResident.fullBio.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>

            {/* Momentos Favoritos no Lar */}
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-2.5">
              <h5 className="font-heading font-bold text-xs uppercase tracking-wider text-[#073B91] flex items-center gap-1.5">
                <Coffee className="w-3.5 h-3.5 text-[#76A900]" />
                <span>Momentos que Aquecem a Rotina:</span>
              </h5>
              <ul className="space-y-1.5 text-xs text-[#66737A]">
                {selectedResident.favoriteMoments.map((moment, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#76A900] shrink-0" />
                    <span>{moment}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Ações do Modal */}
            <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-stone-200">
              {onOpenVisitModal && (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedResident(null);
                    onOpenVisitModal();
                  }}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-xl transition-colors"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Agendar Visita para Conhecer Nossos Residentes</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setSelectedResident(null)}
                className="px-5 py-3 text-xs sm:text-sm font-medium text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
