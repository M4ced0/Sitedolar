import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Quote,
  CheckCircle2,
  Heart,
  Star,
  MapPin,
  Calendar,
  Pause,
  Play,
  ShieldCheck,
  UserCheck,
  ArrowRight,
  HeartHandshake,
  User,
  Camera,
} from 'lucide-react';

export interface FamilyTestimonial {
  id: string;
  author: string;
  relation: string;
  residentName: string;
  residentAge: number;
  timeAtHome: string;
  quote: string;
  tag: string;
  highlightMetric: string;
  location: string;
  photoUrl: string;
  photoAlt: string;
  residentPhotoUrl: string;
  date: string;
  rating: number;
}

// Backward compatibility alias
export type Testimonial = FamilyTestimonial;

export const TESTIMONIALS_DATA: FamilyTestimonial[] = [
  {
    id: 'dep-1',
    author: 'Dra. Cláudia M. Rezende',
    relation: 'Filha da residente Maria de Lourdes',
    residentName: 'D. Lourdinha Rezende',
    residentAge: 84,
    timeAtHome: '4 anos no Lar',
    tag: 'Acolhimento & Afeto',
    highlightMetric: '4 anos de convivência serena e afetuosa',
    quote:
      'A paz de saber que nossa mãe está em um ambiente limpo, seguro e cercada por profissionais que realmente a tratam com carinho e paciência não tem preço. Quando venho visitá-la e a vejo lendo seus livros favoritos no jardim ensolarado com as amigas, tenho a certeza de que fizemos a melhor escolha pela dignidade dela.',
    location: 'Juiz de Fora - MG (Vila Furtado de Menezes)',
    photoUrl: '', // Wireframe: Inserir foto do familiar
    photoAlt: 'Retrato de Cláudia Rezende',
    residentPhotoUrl: '', // Wireframe: Inserir foto do residente
    date: 'Depoimento registrado e verificado',
    rating: 5,
  },
  {
    id: 'dep-2',
    author: 'Roberto Carlos Siqueira',
    relation: 'Filho do residente José Antônio',
    residentName: 'Seu Zé da Gaita',
    residentAge: 79,
    timeAtHome: '3 anos no Lar',
    tag: 'Enfermagem 24h & Saúde',
    highlightMetric: 'Acompanhamento médico e medicação rigorosa',
    quote:
      'A dedicação da equipe de enfermagem e o rigor na administração diária dos medicamentos nos deram imensa tranquilidade. Meu pai recuperou o apetite, voltou a tocar gaita nos finais de tarde e fez grandes amigos. Os relatórios de saúde são transparentes e a atenção da diretoria aos familiares é exemplar.',
    location: 'Juiz de Fora - MG (Bairro Granbery)',
    photoUrl: '', // Wireframe: Inserir foto do familiar
    photoAlt: 'Retrato de Roberto Carlos Siqueira',
    residentPhotoUrl: '', // Wireframe: Inserir foto do residente
    date: 'Depoimento registrado e verificado',
    rating: 5,
  },
  {
    id: 'dep-3',
    author: 'Patrícia Alvim Guimarães',
    relation: 'Sobrinha e curadora legal da Sra. Geralda',
    residentName: 'Dona Geraldinha',
    residentAge: 88,
    timeAtHome: '5 anos no Lar',
    tag: 'Dignidade & Respeito',
    highlightMetric: '5 anos de valorização da história individual',
    quote:
      'O respeito à história de vida e à individualidade de cada idoso é o que mais nos emociona. Não é uma instituição fria: é um lar de verdade, com afeto, alimentação fresca e balanceada, e muita transparência. Minha tia se sente valorizada, borda todos os dias e tem orgulho da sua moradia.',
    location: 'Juiz de Fora - MG (Bairro Santa Helena)',
    photoUrl: '', // Wireframe: Inserir foto do familiar
    photoAlt: 'Retrato de Patrícia Alvim Guimarães',
    residentPhotoUrl: '', // Wireframe: Inserir foto do residente
    date: 'Depoimento registrado e verificado',
    rating: 5,
  },
  {
    id: 'dep-4',
    author: 'Marcos Vinícius Tostes Silveira',
    relation: 'Filho do residente Benedito Carlos',
    residentName: 'Seu Dito',
    residentAge: 82,
    timeAtHome: '2 anos no Lar',
    tag: 'Qualidade de Vida & Horta',
    highlightMetric: 'Estímulo cognitivo, horta e lazer diário',
    quote:
      'Acompanhamos as visitas semanais e sempre encontramos o ambiente acolhedor, com cheiro de casa limpa e funcionários carinhosos. Ver meu pai entusiasmado cuidando da horta comunitária e jogando xadrez na varanda me devolveu o sono tranquilo. O Lar é uma bênção para nossa família.',
    location: 'Juiz de Fora - MG (Bairro Cascatinha)',
    photoUrl: '', // Wireframe: Inserir foto do familiar
    photoAlt: 'Retrato de Marcos Vinícius Tostes Silveira',
    residentPhotoUrl: '', // Wireframe: Inserir foto do residente
    date: 'Depoimento registrado e verificado',
    rating: 5,
  },
  {
    id: 'dep-5',
    author: 'Dra. Mariana Vasconcellos Prado',
    relation: 'Neta da residente Helena Vasconcellos',
    residentName: 'Dona Helena',
    residentAge: 86,
    timeAtHome: '3 anos no Lar',
    tag: 'Supervisão Médica & Nutrição',
    highlightMetric: 'Até 6 refeições balanceadas e nutrição clínica',
    quote:
      'Como médica, sempre fui muito criteriosa com protocolos sanitários, assepsia e vigilância geriátrica. Fiquei impressionada com o preparo técnico da equipe do Lar Santa Luiza, a higiene impecável das acomodações e a qualidade das 6 refeições diárias. Minha avó é cuidada com imensa reverência.',
    location: 'Juiz de Fora - MG (Bairro Bom Pastor)',
    photoUrl: '', // Wireframe: Inserir foto do familiar
    photoAlt: 'Retrato de Mariana Vasconcellos Prado',
    residentPhotoUrl: '', // Wireframe: Inserir foto do residente
    date: 'Depoimento registrado e verificado',
    rating: 5,
  },
  {
    id: 'dep-6',
    author: 'Teresa Mendonça Duarte',
    relation: 'Filha do residente Darcy Mendonça',
    residentName: 'Sr. Darcy',
    residentAge: 80,
    timeAtHome: '1 ano e meio no Lar',
    tag: 'Vínculo Familiar & Apoio',
    highlightMetric: 'Adaptação humanizada e diálogo aberto',
    quote:
      'A transição para o Lar foi conduzida com extremo carinho e apoio psicológico para toda a família. Nunca nos sentimos distantes: os horários de visita são acolhedores, temos canal direto com a coordenação e vemos nos olhos do meu pai a alegria de ser bem acolhido todos os dias.',
    location: 'Juiz de Fora - MG (Bairro Centro)',
    photoUrl: '', // Wireframe: Inserir foto do familiar
    photoAlt: 'Retrato de Teresa Mendonça Duarte',
    residentPhotoUrl: '', // Wireframe: Inserir foto do residente
    date: 'Depoimento registrado e verificado',
    rating: 5,
  },
];

interface TestimonialsSliderProps {
  onOpenVisitModal?: () => void;
  onOpenDonationModal?: () => void;
}

export const TestimonialsSlider: React.FC<TestimonialsSliderProps> = ({
  onOpenVisitModal,
  onOpenDonationModal,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [direction, setDirection] = useState<'next' | 'prev'>('next');
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const durationMs = 6500;
  const updateIntervalMs = 50;
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const touchStartXRef = useRef<number | null>(null);

  const testimonials = TESTIMONIALS_DATA;

  // Next / Prev handlers with direction tracking
  const handleNext = useCallback(() => {
    setDirection('next');
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    setProgress(0);
  }, [testimonials.length]);

  const handlePrev = useCallback(() => {
    setDirection('prev');
    setCurrentIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
    setProgress(0);
  }, [testimonials.length]);

  const handleSelect = (index: number) => {
    setDirection(index > currentIndex ? 'next' : 'prev');
    setCurrentIndex(index);
    setProgress(0);
  };

  // Auto-play interval with smooth progress bar
  useEffect(() => {
    if (isPaused) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        const next = prev + (updateIntervalMs / durationMs) * 100;
        if (next >= 100) {
          handleNext();
          return 0;
        }
        return next;
      });
    }, updateIntervalMs);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPaused, handleNext, durationMs]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handlePrev, handleNext]);

  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null) return;
    const diff = touchStartXRef.current - e.changedTouches[0].clientX;
    if (diff > 50) {
      handleNext();
    } else if (diff < -50) {
      handlePrev();
    }
    touchStartXRef.current = null;
  };

  const handleImageError = (id: string) => {
    setFailedImages((prev) => ({ ...prev, [id]: true }));
  };

  const current = testimonials[currentIndex];

  // Helper for initials
  const getInitials = (name: string) => {
    const parts = name.replace(/^(Dra\.|Dr\.|Sr\.|Sra\.)\s*/i, '').trim().split(' ');
    if (parts.length >= 2) {
      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <section
      aria-label="Depoimentos de familiares de residentes"
      className="py-20 lg:py-28 bg-[#FAFBF7] border-b border-stone-200/80 font-body relative overflow-hidden"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Decorative background ambient soft glows */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-[#76A900]/8 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-[#073B91]/6 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header da Seção Centralizado e Alinhado */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16 space-y-3">
          <span className="text-xs font-bold tracking-wider uppercase text-[#073B91] inline-flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5 text-[#76A900] fill-[#76A900]/30" />
            <span>Vozes de Quem Confia no Nosso Cuidado · Familiares</span>
          </span>

          <h2 className="font-heading text-3xl sm:text-4xl lg:text-[42px] font-bold text-[#27343B] tracking-tight leading-tight text-balance">
            Depoimentos Reais de Familiares dos Residentes
          </h2>

          <p className="text-base sm:text-lg text-[#5A666E] font-body leading-relaxed max-w-2xl mx-auto">
            A tranquilidade de quem confia quem mais ama ao Lar Santa Luiza de Marillac. Conheça as histórias de acolhimento contadas por filhas, filhos, netos e responsáveis.
          </p>

          {/* Institutional Trust Badges */}
          <div className="pt-2 flex flex-wrap items-center justify-center gap-4 sm:gap-8 text-xs sm:text-sm text-[#27343B] font-medium">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#76A900]" />
              <span>Depoimentos autorizados por escrito</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#073B91]" />
              <span>Famílias com acompanhamento contínuo</span>
            </div>
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#76A900]" />
              <span>Visitas presenciais livres e transparentes</span>
            </div>
          </div>
        </div>

        {/* Card Principal do Carrossel - Tema Claro, Nítido e Acolhedor */}
        <div className="max-w-4xl mx-auto">
          <div className="relative bg-white rounded-3xl border border-stone-200 shadow-xl shadow-stone-200/50 overflow-hidden transition-all duration-300">
            {/* Barra de Progresso do Autoplay */}
            <div className="w-full bg-stone-100 h-1.5 relative overflow-hidden">
              <div
                className="h-full bg-linear-to-r from-[#073B91] via-[#76A900] to-[#073B91] transition-all duration-100 ease-linear"
                style={{ width: `${progress}%` }}
              />
            </div>

            {/* Cabeçalho do Card: Selo, Estrelas, Categoria e Controle de Pause */}
            <div className="px-6 sm:px-10 pt-6 pb-4 flex flex-wrap items-center justify-between gap-3 border-b border-stone-100 bg-[#FAFBF7]">
              <div className="flex items-center gap-3">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#76A900]/12 border border-[#76A900]/25 text-xs font-semibold text-[#4E7300]">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span>{current.tag}</span>
                </span>
                <span className="hidden sm:inline-block text-xs text-[#5A666E]">
                  • {current.highlightMetric}
                </span>
              </div>

              <div className="flex items-center gap-4">
                {/* 5 Estrelas Douradas */}
                <div
                  className="flex items-center gap-0.5 text-amber-500"
                  aria-label="Avaliação 5 de 5 estrelas"
                >
                  {[...Array(current.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-amber-400 text-amber-500"
                    />
                  ))}
                </div>

                {/* Botão Pausar / Reproduzir */}
                <button
                  type="button"
                  onClick={() => setIsPaused((prev) => !prev)}
                  className="inline-flex items-center gap-1.5 text-xs text-[#5A666E] hover:text-[#073B91] p-1.5 rounded-lg hover:bg-stone-200/60 transition-colors cursor-pointer"
                  title={isPaused ? 'Continuar rotação automática' : 'Pausar rotação automática'}
                  aria-label={isPaused ? 'Continuar rotação automática' : 'Pausar rotação automática'}
                >
                  {isPaused ? (
                    <>
                      <Play className="w-3.5 h-3.5 text-[#073B91]" />
                      <span className="text-[11px] font-medium hidden sm:inline">Continuar</span>
                    </>
                  ) : (
                    <>
                      <Pause className="w-3.5 h-3.5" />
                      <span className="text-[11px] font-medium hidden sm:inline">Pausar</span>
                    </>
                  )}
                </button>

                {/* Indicador Numérico */}
                <span className="text-xs font-semibold font-mono text-[#073B91] bg-sky-50 px-2.5 py-0.5 rounded-full border border-sky-200/80">
                  {currentIndex + 1} / {testimonials.length}
                </span>
              </div>
            </div>

            {/* Conteúdo Principal do Depoimento com Fundo Claro e Tipografia Legível */}
            <div className="p-6 sm:p-10 lg:p-12 relative min-h-[380px] sm:min-h-[340px] flex flex-col justify-between bg-white">
              {/* Aspas decorativas translúcidas sutis */}
              <div className="absolute top-6 right-8 text-[#073B91]/8 pointer-events-none select-none">
                <Quote className="w-20 h-20 sm:w-28 sm:h-28 rotate-180" />
              </div>

              <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-10 items-center">
                {/* Coluna da Foto do Familiar & Contexto do Residente */}
                <div className="md:col-span-5 flex flex-col items-center sm:items-start text-center sm:text-left space-y-4">
                  <div className="relative">
                    {/* Foto do Familiar com Borda Suave */}
                    <div className="w-28 h-28 sm:w-32 sm:h-32 lg:w-36 lg:h-36 rounded-2xl overflow-hidden border-2 border-dashed border-stone-300 shadow-sm relative bg-[#F8FAF5] flex flex-col items-center justify-center p-3 text-center group">
                      {current.photoUrl && !failedImages[current.id] ? (
                        <img
                          src={current.photoUrl}
                          alt={current.photoAlt || current.author}
                          className="w-full h-full object-cover object-top transition-transform duration-700 hover:scale-105"
                          onError={() => handleImageError(current.id)}
                          loading="lazy"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center space-y-1">
                          <div className="w-10 h-10 rounded-full bg-white border border-stone-200 flex items-center justify-center text-[#073B91] font-bold text-sm shadow-2xs">
                            {getInitials(current.author)}
                          </div>
                          <span className="text-[10px] font-bold text-stone-700 uppercase tracking-tight">
                            Wireframe
                          </span>
                          <span className="text-[9px] text-stone-500 font-mono">
                            Foto Familiar
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Selo Verificado sobreposto */}
                    <div
                      className="absolute -bottom-2 -right-2 bg-white p-1.5 rounded-full shadow-md border border-stone-200 text-[#76A900]"
                      title="Familiar de residente com termo de autorização"
                    >
                      <CheckCircle2 className="w-5 h-5 fill-[#76A900] text-white" />
                    </div>
                  </div>

                  {/* Informações do Familiar */}
                  <div className="space-y-1">
                    <h3 className="font-heading font-bold text-lg sm:text-xl text-[#073B91]">
                      {current.author}
                    </h3>
                    <p className="text-xs sm:text-sm font-semibold text-[#27343B] font-body">
                      {current.relation}
                    </p>
                    <div className="flex items-center justify-center sm:justify-start gap-1 text-xs text-[#5A666E] font-body">
                      <MapPin className="w-3.5 h-3.5 text-[#76A900] shrink-0" />
                      <span>{current.location}</span>
                    </div>
                  </div>

                  {/* Cartão de Conexão com o Residente */}
                  <div className="w-full p-3 rounded-xl bg-[#F5F8F0] border border-stone-200/90 text-left flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 border border-dashed border-stone-300 bg-white flex items-center justify-center text-stone-400">
                      {current.residentPhotoUrl ? (
                        <img
                          src={current.residentPhotoUrl}
                          alt={`Residente ${current.residentName}`}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <User className="w-5 h-5 text-stone-500" />
                      )}
                    </div>
                    <div className="text-xs min-w-0">
                      <p className="font-semibold text-[#27343B] truncate">
                        {current.residentName} ({current.residentAge} anos)
                      </p>
                      <p className="text-[11px] text-[#5A666E]">
                        {current.timeAtHome} · [Foto Residente]
                      </p>
                    </div>
                  </div>
                </div>

                {/* Coluna da Citação (Quote) e Impacto */}
                <div className="md:col-span-7 space-y-5">
                  <blockquote className="text-lg sm:text-xl lg:text-[22px] text-stone-800 font-serif leading-relaxed italic">
                    &ldquo;{current.quote}&rdquo;
                  </blockquote>

                  <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3 text-xs text-[#5A666E]">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#073B91]" />
                      <span>{current.date}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[#4E7300] font-medium">
                      <HeartHandshake className="w-3.5 h-3.5" />
                      <span>Transparência Vicentina</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Controles de Navegação: Setas e Ações */}
              <div className="pt-8 mt-6 border-t border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-5">
                {/* Botões Prévio e Próximo com Animação */}
                <div className="flex items-center gap-3 order-2 sm:order-1">
                  <button
                    type="button"
                    onClick={handlePrev}
                    className="group inline-flex items-center justify-center p-3 rounded-full border border-stone-200 bg-white text-[#27343B] hover:border-[#073B91] hover:text-[#073B91] hover:bg-sky-50/50 shadow-2xs hover:shadow-xs transition-all duration-200 cursor-pointer active:scale-95"
                    aria-label="Ver depoimento anterior"
                  >
                    <ChevronLeft className="w-5 h-5 transition-transform group-hover:-translate-x-0.5" />
                  </button>

                  {/* Indicadores de Pontos (Dots) */}
                  <div
                    className="flex items-center gap-2 px-2"
                    role="tablist"
                    aria-label="Selecionar depoimento"
                  >
                    {testimonials.map((_, idx) => (
                      <button
                        key={idx}
                        type="button"
                        role="tab"
                        onClick={() => handleSelect(idx)}
                        className={`h-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                          currentIndex === idx
                            ? 'w-8 bg-[#073B91]'
                            : 'w-2.5 bg-stone-200 hover:bg-stone-300'
                        }`}
                        aria-label={`Ir para depoimento ${idx + 1}`}
                        aria-selected={currentIndex === idx}
                      />
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={handleNext}
                    className="group inline-flex items-center justify-center p-3 rounded-full border border-stone-200 bg-white text-[#27343B] hover:border-[#073B91] hover:text-[#073B91] hover:bg-sky-50/50 shadow-2xs hover:shadow-xs transition-all duration-200 cursor-pointer active:scale-95"
                    aria-label="Ver próximo depoimento"
                  >
                    <ChevronRight className="w-5 h-5 transition-transform group-hover:translate-x-0.5" />
                  </button>
                </div>

                {/* CTAs Interativos Rápidos */}
                <div className="flex items-center gap-3 order-1 sm:order-2 w-full sm:w-auto justify-center">
                  {onOpenVisitModal && (
                    <button
                      type="button"
                      onClick={onOpenVisitModal}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl border border-[#073B91]/30 text-xs font-semibold text-[#073B91] hover:bg-[#073B91]/5 bg-white transition-colors cursor-pointer"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Agendar Visita de Familiar</span>
                    </button>
                  )}

                  {onOpenDonationModal && (
                    <button
                      type="button"
                      onClick={onOpenDonationModal}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#76A900] hover:bg-[#628c00] text-white text-xs font-semibold shadow-xs hover:shadow-md transition-all cursor-pointer"
                    >
                      <Heart className="w-3.5 h-3.5 fill-white/30" />
                      <span>Apoiar Nossos Residentes</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Trilho de Miniaturas dos Familiares (Avatar Rail Selector) em Fundo Claro */}
          <div className="mt-8">
            <p className="text-center text-xs font-semibold uppercase tracking-wider text-[#5A666E] mb-4">
              Conheça os familiares que deixaram seu testemunho:
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {testimonials.map((item, idx) => {
                const isActive = currentIndex === idx;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelect(idx)}
                    className={`p-2.5 rounded-2xl border text-left transition-all duration-200 cursor-pointer flex items-center gap-2.5 ${
                      isActive
                        ? 'bg-white border-[#073B91] shadow-md ring-2 ring-[#073B91]/20 scale-[1.02]'
                        : 'bg-white hover:bg-[#F8FAF5] border-stone-200 hover:border-stone-300 shadow-2xs'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-full overflow-hidden shrink-0 border border-stone-200 bg-stone-100">
                      {!failedImages[item.id] && item.photoUrl ? (
                        <img
                          src={item.photoUrl}
                          alt={item.author}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-[#073B91] text-white font-bold text-[10px]">
                          {getInitials(item.author)}
                        </div>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p
                        className={`text-xs font-bold truncate ${
                          isActive ? 'text-[#073B91]' : 'text-[#27343B]'
                        }`}
                      >
                        {item.author.replace(/^(Dra\.|Dr\.)\s*/i, '')}
                      </p>
                      <p className="text-[10px] text-[#5A666E] truncate">
                        {item.relation.split(' ')[0]} {item.residentName.split(' ')[0]}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
