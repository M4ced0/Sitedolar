import { Camera, Image as ImageIcon } from 'lucide-react';

interface HumanizedHeroPhotoProps {
  className?: string;
}

export const HumanizedHeroPhoto: React.FC<HumanizedHeroPhotoProps> = ({
  className = '',
}) => {
  return (
    <div
      className={`relative w-full aspect-[4/3] lg:aspect-[16/11] rounded-2xl overflow-hidden bg-slate-100/90 border-2 border-dashed border-slate-300 shadow-md group ${className}`}
    >
      {/* Blueprint grid texture */}
      <div
        className="absolute inset-0 opacity-[0.25] pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle, #94a3b8 1px, transparent 1px)',
          backgroundSize: '16px 16px',
        }}
      />

      {/* Wireframe Centered Content */}
      <div className="relative z-10 w-full h-full flex flex-col items-center justify-center p-6 text-center space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider shadow-2xs">
          <Camera className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-600 transition-colors" />
          <span>Espaço Wireframe · Foto Principal</span>
        </div>

        <div className="w-14 h-14 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center justify-center text-slate-400 group-hover:border-emerald-400 group-hover:text-emerald-600 transition-all">
          <ImageIcon className="w-7 h-7" />
        </div>

        <div className="space-y-1 max-w-sm">
          <h4 className="text-sm font-bold text-slate-700">
            Foto Institucional Humanizada
          </h4>
          <p className="text-xs text-slate-500">
            Momento de carinho, dedicação e acolhimento à pessoa idosa
          </p>
          <p className="text-[11px] font-mono text-slate-400 bg-white/80 inline-block px-2.5 py-0.5 rounded border border-slate-200 mt-1">
            Dimensão sugerida: 1400 × 1000 px
          </p>
        </div>
      </div>

      {/* Subtle overlay vignette for high-end editorial feel */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-transparent pointer-events-none" />

      {/* Floating institutional credibility pill */}
      <div className="absolute bottom-5 left-5 right-5 sm:right-auto sm:max-w-xs bg-white/95 backdrop-blur-md px-4 py-3 rounded-xl border border-white/60 shadow-lg flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-[#76A900]/15 flex items-center justify-center shrink-0">
          <span className="w-2.5 h-2.5 rounded-full bg-[#76A900]" />
        </div>
        <div>
          <p className="font-heading text-xs font-bold text-[#073B91] leading-tight">
            Acolhimento Contínuo 24 Horas
          </p>
          <p className="text-[11px] text-[#66737A] font-body mt-0.5">
            Juiz de Fora · Mais de 50 anos de história
          </p>
        </div>
      </div>
    </div>
  );
};
