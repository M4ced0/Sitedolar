import React, { useState, useId } from 'react';
import {
  Calculator,
  Heart,
  ShoppingBag,
  Sparkles,
  Utensils,
  Activity,
  ShieldCheck,
  Package,
  Copy,
  Check,
  MessageCircle,
  QrCode,
  Volume2,
  VolumeX,
  Repeat,
  Info,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  Plus,
  Minus,
} from 'lucide-react';
import { INSTITUTION_INFO } from '../../data/institutionalData';
import { notifySuccess } from '../../utils/notifications';
import { PageRoute } from '../../types';

interface DonationImpactCalculatorProps {
  onOpenDonationModal: (options?: {
    tab?: 'material' | 'pix';
    amount?: number;
    impactText?: string;
  }) => void;
  onNavigate?: (page: PageRoute) => void;
}

// Concrete cost references calculated based on institutional care needs
interface ImpactItemDef {
  id: string;
  name: string;
  unitCost: number;
  unitLabel: string;
  icon: React.ComponentType<{ className?: string }>;
  accentColor: string;
  bgLight: string;
  borderColor: string;
  shortDesc: string;
  fullDesc: string;
  contents: string[];
}

const IMPACT_ITEMS: ImpactItemDef[] = [
  {
    id: 'cesta',
    name: 'Cesta Básica Nutricional Sênior',
    unitCost: 110,
    unitLabel: 'cesta',
    icon: ShoppingBag,
    accentColor: 'text-amber-800',
    bgLight: 'bg-amber-50/70',
    borderColor: 'border-amber-200',
    shortDesc: 'Alimentos selecionados para dietas com baixa restrição e alta densidade nutricional.',
    fullDesc: 'Arroz tipo 1, feijão carioquinha, aveia em flocos finos, leite em pó integral enriquecido, azeite extravirgem, macarrão integral e complementos adequados à deglutição da pessoa idosa.',
    contents: ['5kg Arroz', '2kg Feijão', '4 latas Leite em pó', '1L Azeite', 'Aveia e complementos'],
  },
  {
    id: 'higiene',
    name: 'Kit de Higiene Pessoal & Conforto',
    unitCost: 45,
    unitLabel: 'kit',
    icon: Sparkles,
    accentColor: 'text-[#073B91]',
    bgLight: 'bg-blue-50/60',
    borderColor: 'border-blue-200',
    shortDesc: 'Itens dermatológicos para banho diário, hidratação de pele frágil e higiene oral.',
    fullDesc: 'Sabonete líquido hipoalergênico, hidratante corporal intensivo para pele sênior, xampu neutro, escova dental cerdas extramacias, creme dental e esponja corporal macia.',
    contents: ['Sabonete líquido glicerinado', 'Hidratante corporal 400ml', 'Xampu neutro', 'Kit dental macio'],
  },
  {
    id: 'fraldas',
    name: 'Pacote de Fraldas Geriátricas',
    unitCost: 65,
    unitLabel: 'pacote',
    icon: Package,
    accentColor: 'text-[#76A900]',
    bgLight: 'bg-[#F5F8F0]',
    borderColor: 'border-[#76A900]/30',
    shortDesc: 'Proteção noturna anatômica com toque suave para prevenção de dermatites.',
    fullDesc: 'Fraldas descartáveis com indicador de umidade, gel superabsorvente e barreiras antivazamento, fundamentais para noites de sono tranquilas com proteção e respeito à dignidade.',
    contents: ['Fraldas descartáveis M/G/EG', 'Gel superabsorvente', 'Barreiras elásticas macias', 'Lenços umedecidos'],
  },
  {
    id: 'refeicoes',
    name: 'Dias de Nutrição Completa (6 ref./dia)',
    unitCost: 25,
    unitLabel: 'dia',
    icon: Utensils,
    accentColor: 'text-orange-800',
    bgLight: 'bg-orange-50/70',
    borderColor: 'border-orange-200',
    shortDesc: 'Todas as 6 refeições diárias de um residente preparadas com nutricionista.',
    fullDesc: 'Café da manhã com frutas e pão quentinho, colação matinal, almoço balanceado com carnes magras e legumes frescos, café da tarde mineiro, jantar leve e ceia reconfortante.',
    contents: ['Café da manhã', 'Colação de frutas', 'Almoço balanceado', 'Café da tarde', 'Jantar & Ceia'],
  },
  {
    id: 'fisioterapia',
    name: 'Sessão de Fisioterapia & Terapia Motora',
    unitCost: 75,
    unitLabel: 'sessão',
    icon: Activity,
    accentColor: 'text-indigo-800',
    bgLight: 'bg-indigo-50/70',
    borderColor: 'border-indigo-200',
    shortDesc: 'Exercícios preventivos de marcha, equilíbrio e alívio de dores articulares.',
    fullDesc: 'Atendimento com profissional especializado na terceira idade para preservação da autonomia de locomoção, fortalecimento muscular e prevenção rigorosa de quedas.',
    contents: ['Avaliação postural', 'Treino de marcha e equilíbrio', 'Exercícios articulares', 'Terapia sensorial'],
  },
  {
    id: 'curativos',
    name: 'Kit Primeiros Cuidados & Sinais Vitais',
    unitCost: 35,
    unitLabel: 'kit',
    icon: ShieldCheck,
    accentColor: 'text-rose-800',
    bgLight: 'bg-rose-50/70',
    borderColor: 'border-rose-200',
    shortDesc: 'Material estéril para curativos e monitoramento preventivo da equipe de enfermagem.',
    fullDesc: 'Gaze estéril, soro fisiológico em frascos individuais, esparadrapo microporado antialérgico, fitas para controle de glicemia capilar e termômetros digitais.',
    contents: ['Gazes estéreis', 'Soro fisiológico 0,9%', 'Fita micropore antialérgica', 'Fitas glicêmicas'],
  },
];

const PRESET_VALUES = [
  { value: 30, label: 'R$ 30', subtitle: 'Acolhimento' },
  { value: 60, label: 'R$ 60', subtitle: 'Kit Conforto' },
  { value: 120, label: 'R$ 120', subtitle: 'Cesta & Cuidados' },
  { value: 250, label: 'R$ 250', subtitle: 'Cuidado Completo' },
  { value: 500, label: 'R$ 500', subtitle: 'Padrinho do Mês' },
  { value: 1000, label: 'R$ 1.000', subtitle: 'Amigo Guardião' },
];

export const DonationImpactCalculator: React.FC<DonationImpactCalculatorProps> = ({
  onOpenDonationModal,
  onNavigate,
}) => {
  const [calculationMode, setCalculationMode] = useState<'byValue' | 'byCustomKit'>('byValue');
  const [donationValue, setDonationValue] = useState<number>(120);
  const [frequency, setFrequency] = useState<'once' | 'monthly'>('once');
  const [copiedPix, setCopiedPix] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [activeItemDetail, setActiveItemDetail] = useState<string | null>(null);

  // Custom kit counter state (by item)
  const [customKitCounts, setCustomKitCounts] = useState<{ [itemId: string]: number }>({
    cesta: 1,
    higiene: 1,
    fraldas: 1,
    refeicoes: 2,
    fisioterapia: 0,
    curativos: 1,
  });

  const headingId = useId();

  // Multiplier for recurring calculation (12 months display)
  const effectiveValue = frequency === 'monthly' ? donationValue * 12 : donationValue;

  // Custom kit total calculation
  const customKitTotal = Object.entries(customKitCounts).reduce((acc, [id, count]) => {
    const item = IMPACT_ITEMS.find((it) => it.id === id);
    return acc + (item ? item.unitCost * count : 0);
  }, 0);

  // Active value to calculate from
  const currentTotal = calculationMode === 'byValue' ? effectiveValue : customKitTotal;

  // Calculate items purely provided by amount
  const calculatedItems = IMPACT_ITEMS.map((item) => {
    const count = Math.floor(currentTotal / item.unitCost);
    const remainder = currentTotal % item.unitCost;
    const progressPercent = Math.min(100, Math.round(((currentTotal % item.unitCost) / item.unitCost) * 100));
    return {
      ...item,
      count,
      remainder,
      progressPercent,
    };
  });

  // Calculate a smart balanced "Mix Solidário"
  const getBalancedMix = (total: number) => {
    let budget = total;
    const mix: { name: string; count: number; unitLabel: string }[] = [];

    // Prioritize 1 Cesta if >= 110
    if (budget >= 110) {
      const cestas = Math.floor(budget / 110);
      mix.push({ name: 'Cesta Básica Nutricional', count: cestas, unitLabel: cestas > 1 ? 'cestas' : 'cesta' });
      budget -= cestas * 110;
    }

    // Then Kits Higiene if >= 45
    if (budget >= 45) {
      const kits = Math.floor(budget / 45);
      mix.push({ name: 'Kit de Higiene Pessoal', count: kits, unitLabel: kits > 1 ? 'kits' : 'kit' });
      budget -= kits * 45;
    }

    // Then Fraldas if >= 65
    if (budget >= 65) {
      const fraldas = Math.floor(budget / 65);
      mix.push({ name: 'Pacote de Fraldas Geriátricas', count: fraldas, unitLabel: fraldas > 1 ? 'pacotes' : 'pacote' });
      budget -= fraldas * 65;
    }

    // Then Dias de Refeições
    if (budget >= 25) {
      const dias = Math.floor(budget / 25);
      mix.push({ name: 'Dias de Refeição Completa', count: dias, unitLabel: dias > 1 ? 'dias' : 'dia' });
      budget -= dias * 25;
    }

    return { mix, remainder: budget };
  };

  const balancedMix = getBalancedMix(currentTotal);

  // Summary impact text
  const impactSummaryText = `Com R$ ${currentTotal.toLocaleString('pt-BR')}, você proporciona aproximadamente ${
    balancedMix.mix.length > 0
      ? balancedMix.mix.map((m) => `${m.count} ${m.name}`).join(' e ')
      : 'apoio imediato aos cuidados básicos dos nossos 42 moradores'
  }.`;

  const handleCopyPixKey = () => {
    const pixKey = INSTITUTION_INFO.email;
    navigator.clipboard.writeText(pixKey);
    setCopiedPix(true);
    notifySuccess('Chave PIX institucional copiada com sucesso!');
    setTimeout(() => setCopiedPix(false), 2500);
  };

  const handleOpenWhatsApp = () => {
    const valText = currentTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
    const text = encodeURIComponent(
      `Olá! Utilizei a Calculadora de Impacto no site do Lar dos Idosos Santa Luiza de Marillac.\n` +
      `Gostaria de contribuir com R$ ${valText}${frequency === 'monthly' ? ' (intenção de doação mensal)' : ''}.\n` +
      `Esse valor apoia:\n${balancedMix.mix.map((m) => `• ${m.count} ${m.name}`).join('\n')}\n\n` +
      `Como posso confirmar e enviar meu comprovante PIX ou combinar a entrega dos itens?`
    );
    window.open(`https://wa.me/${INSTITUTION_INFO.whatsappClean}?text=${text}`, '_blank');
  };

  const handleAudioNarration = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const narration = `Calculadora de Impacto de Doação do Lar dos Idosos Santa Luiza de Marillac. ` +
      `Para uma contribuição de ${currentTotal} reais ${frequency === 'monthly' ? 'acumulada ao longo de 12 meses' : 'pontual'}, ` +
      `seu gesto garante: ` +
      (balancedMix.mix.length > 0
        ? balancedMix.mix.map((m) => `${m.count} ${m.name}`).join(', ')
        : 'apoio com itens de necessidade contínua') +
      `. 100% da sua doação é aplicada na alimentação, higiene e saúde dos 42 residentes acolhidos em Juiz de Fora.`;

    const utterance = new SpeechSynthesisUtterance(narration);
    utterance.lang = 'pt-BR';
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleIncrementKit = (id: string) => {
    setCustomKitCounts((prev) => ({
      ...prev,
      [id]: (prev[id] || 0) + 1,
    }));
  };

  const handleDecrementKit = (id: string) => {
    setCustomKitCounts((prev) => ({
      ...prev,
      [id]: Math.max(0, (prev[id] || 0) - 1),
    }));
  };

  return (
    <section
      id="calculadora-impacto"
      aria-labelledby={headingId}
      className="py-16 sm:py-24 bg-gradient-to-b from-[#F5F8F0]/80 via-white to-[#F5F8F0]/40 border-y border-stone-200/80 transition-colors"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Ribbon */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 sm:mb-14">
          <div className="max-w-3xl space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white rounded-full border border-[#76A900]/30 shadow-2xs">
              <Calculator className="w-4 h-4 text-[#76A900]" />
              <span className="text-xs font-semibold tracking-wider uppercase text-[#76A900] font-body">
                Transparência & Solidariedade
              </span>
            </div>
            <h2 id={headingId} className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-[#27343B]">
              Calculadora de Impacto de Doação
            </h2>
            <p className="text-base sm:text-lg text-[#66737A] font-body leading-relaxed">
              Cada centavo doado transforma vidas com amor e dignidade. Veja exatamente o que o seu valor proporciona na alimentação, higiene e saúde dos nossos <strong className="text-[#073B91] font-semibold">42 idosos residentes</strong> em Juiz de Fora.
            </p>
          </div>

          {/* Accessibility Narration Control */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleAudioNarration}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                isSpeaking
                  ? 'bg-amber-100 border-amber-300 text-amber-900 shadow-xs'
                  : 'bg-white border-stone-300 text-stone-700 hover:border-[#073B91] hover:text-[#073B91] shadow-2xs'
              }`}
              title="Ouvir audiodescrição do impacto calculado"
              aria-label={isSpeaking ? 'Pausar leitura do resumo' : 'Ouvir resumo do impacto calculado por voz'}
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="w-4 h-4 text-amber-700 animate-pulse" />
                  <span>Pausar Leitura</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-[#073B91]" />
                  <span>Ouvir Impacto em Áudio</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Calculation Mode Switcher Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-2 bg-stone-100/80 rounded-2xl border border-stone-200/80 mb-8 max-w-2xl">
          <button
            type="button"
            onClick={() => setCalculationMode('byValue')}
            className={`flex-1 min-w-[200px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              calculationMode === 'byValue'
                ? 'bg-white text-[#073B91] shadow-xs border border-stone-200/60'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Ajustar por Valor em Dinheiro
          </button>
          <button
            type="button"
            onClick={() => setCalculationMode('byCustomKit')}
            className={`flex-1 min-w-[200px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              calculationMode === 'byCustomKit'
                ? 'bg-white text-[#073B91] shadow-xs border border-stone-200/60'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Montar Combo Solidário Personalizado
          </button>
        </div>

        {/* Main Interactive Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Interactive Controls */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-2xl border border-stone-200/90 shadow-xs p-6 sm:p-7 space-y-6">
              {calculationMode === 'byValue' ? (
                /* Mode 1: Value Slider & Presets */
                <>
                  {/* Frequency Toggle */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold uppercase tracking-wider text-stone-500 font-body">
                        Frequência da Solidariedade
                      </span>
                      {frequency === 'monthly' && (
                        <span className="text-[11px] font-bold text-[#76A900] bg-[#F5F8F0] px-2 py-0.5 rounded border border-[#76A900]/30 inline-flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" /> Impacto 12x no ano
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-2 bg-stone-100 p-1 rounded-xl">
                      <button
                        type="button"
                        onClick={() => setFrequency('once')}
                        className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                          frequency === 'once'
                            ? 'bg-white text-[#073B91] shadow-2xs font-bold'
                            : 'text-stone-600 hover:text-stone-900'
                        }`}
                      >
                        Doação Pontual (Única)
                      </button>
                      <button
                        type="button"
                        onClick={() => setFrequency('monthly')}
                        className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                          frequency === 'monthly'
                            ? 'bg-white text-[#76A900] shadow-2xs font-bold'
                            : 'text-stone-600 hover:text-stone-900'
                        }`}
                      >
                        <Repeat className="w-3.5 h-3.5" />
                        <span>Mensal Recorrente</span>
                      </button>
                    </div>
                  </div>

                  {/* Value Display & Direct Input */}
                  <div className="bg-[#F5F8F0]/70 rounded-xl p-5 border border-stone-200/80">
                    <div className="flex items-center justify-between text-xs text-stone-600 mb-1">
                      <span>Valor selecionado:</span>
                      <span className="text-[11px] text-stone-500">
                        {frequency === 'monthly' ? 'por mês (R$ ' + (donationValue * 12).toLocaleString('pt-BR') + '/ano)' : 'valor pontual'}
                      </span>
                    </div>

                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl sm:text-3xl font-bold font-mono text-[#073B91]">R$</span>
                      <input
                        type="number"
                        min="10"
                        max="5000"
                        step="5"
                        value={donationValue}
                        onChange={(e) => {
                          const val = Math.max(10, Math.min(5000, Number(e.target.value) || 10));
                          setDonationValue(val);
                        }}
                        className="font-mono text-3xl sm:text-4xl font-extrabold text-[#073B91] bg-transparent border-b-2 border-[#073B91]/30 focus:border-[#073B91] focus:outline-hidden w-40 text-left"
                        aria-label="Valor da doação em reais"
                      />
                    </div>

                    {/* Smooth Range Slider */}
                    <div className="mt-5 space-y-2">
                      <input
                        type="range"
                        min="20"
                        max="1000"
                        step="10"
                        value={donationValue}
                        onChange={(e) => setDonationValue(Number(e.target.value))}
                        className="w-full h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-[#76A900] focus:outline-hidden"
                        aria-label="Controle deslizante para valor da doação"
                      />
                      <div className="flex justify-between text-[11px] font-mono text-stone-500">
                        <span>R$ 20</span>
                        <span>R$ 250</span>
                        <span>R$ 500</span>
                        <span>R$ 1.000</span>
                      </div>
                    </div>
                  </div>

                  {/* Quick Preset Buttons */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-stone-500 font-body mb-2.5">
                      Sugestões Rápidas de Valores
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {PRESET_VALUES.map((preset) => (
                        <button
                          key={preset.value}
                          type="button"
                          onClick={() => setDonationValue(preset.value)}
                          className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                            donationValue === preset.value
                              ? 'bg-[#073B91] border-[#073B91] text-white shadow-xs'
                              : 'bg-white border-stone-200 text-stone-700 hover:border-[#073B91]/50 hover:bg-stone-50'
                          }`}
                        >
                          <div className="font-mono font-bold text-sm sm:text-base">
                            {preset.label}
                          </div>
                          <div className={`text-[10px] mt-0.5 truncate ${donationValue === preset.value ? 'text-blue-100' : 'text-stone-500'}`}>
                            {preset.subtitle}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                /* Mode 2: Custom Kit Builder */
                <>
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-[#073B91] font-heading">
                      Monte o seu Combo de Cuidados
                    </h3>
                    <p className="text-xs text-stone-600 leading-relaxed font-body">
                      Escolha as unidades exatas de cada item que deseja apoiar. O valor total será calculado automaticamente.
                    </p>
                  </div>

                  <div className="divide-y divide-stone-100 max-h-[380px] overflow-y-auto pr-1">
                    {IMPACT_ITEMS.map((item) => {
                      const count = customKitCounts[item.id] || 0;
                      return (
                        <div key={item.id} className="py-3 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span className={`p-2 rounded-lg ${item.bgLight} ${item.borderColor} border`}>
                              <item.icon className={`w-4 h-4 ${item.accentColor}`} />
                            </span>
                            <div className="min-w-0">
                              <p className="text-xs font-semibold text-stone-800 truncate">
                                {item.name}
                              </p>
                              <p className="text-[11px] font-mono text-stone-500">
                                R$ {item.unitCost} / {item.unitLabel}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() => handleDecrementKit(item.id)}
                              disabled={count === 0}
                              className="w-7 h-7 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center font-bold text-xs"
                              aria-label={`Diminuir quantidade de ${item.name}`}
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-6 text-center font-mono font-bold text-sm text-stone-800">
                              {count}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleIncrementKit(item.id)}
                              className="w-7 h-7 rounded-lg bg-[#073B91] hover:bg-[#052c6e] text-white flex items-center justify-center font-bold text-xs"
                              aria-label={`Aumentar quantidade de ${item.name}`}
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="p-4 bg-[#F5F8F0] rounded-xl border border-stone-200 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-stone-500 block font-body">Valor Total do Combo:</span>
                      <span className="font-mono font-extrabold text-2xl text-[#073B91]">
                        R$ {customKitTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setCustomKitCounts({ cesta: 1, higiene: 2, fraldas: 1, refeicoes: 5, fisioterapia: 0, curativos: 1 });
                      }}
                      className="text-[11px] text-[#073B91] hover:underline font-semibold"
                    >
                      Restaurar padrão
                    </button>
                  </div>
                </>
              )}

              {/* Action Buttons Block */}
              <div className="pt-2 border-t border-stone-100 space-y-2.5">
                <button
                  type="button"
                  onClick={() =>
                    onOpenDonationModal({
                      tab: 'pix',
                      amount: currentTotal,
                      impactText: impactSummaryText,
                    })
                  }
                  className="w-full py-3.5 px-5 bg-[#76A900] hover:bg-[#679400] text-white font-semibold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer font-body text-sm"
                >
                  <Heart className="w-4 h-4 fill-white/20" />
                  <span>Doar R$ {currentTotal.toLocaleString('pt-BR')} via PIX</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={handleCopyPixKey}
                    className="py-2.5 px-3 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {copiedPix ? <Check className="w-3.5 h-3.5 text-[#76A900]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedPix ? 'Chave Copiada!' : 'Copiar Chave PIX'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleOpenWhatsApp}
                    className="py-2.5 px-3 bg-[#F5F8F0] hover:bg-emerald-100/70 text-emerald-800 border border-emerald-200/60 rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Avisar no WhatsApp</span>
                  </button>
                </div>
              </div>

              {/* Transparency Notice */}
              <div className="flex items-start gap-2.5 p-3 bg-stone-50 rounded-xl border border-stone-200/60 text-[11px] text-stone-600 leading-snug">
                <Info className="w-4 h-4 text-[#073B91] shrink-0 mt-0.5" />
                <p>
                  O Lar dos Idosos Santa Luiza de Marillac é filantrópico e auditado. Prestação de contas disponível publicamente em nossa aba de Transparência.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Impact Outputs */}
          <div className="lg:col-span-7 space-y-6">
            {/* Spotlight Card: "Combinação Recomendada de Cuidado" */}
            <div className="bg-white rounded-2xl border-2 border-[#76A900]/30 shadow-md p-6 sm:p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-32 h-32 bg-[#76A900]/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between gap-4 mb-5">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#76A900] font-body block">
                    Resultado Concreto da sua Solidariedade
                  </span>
                  <h3 className="font-heading text-xl sm:text-2xl font-bold text-[#27343B]">
                    Com R$ {currentTotal.toLocaleString('pt-BR')} você garante:
                  </h3>
                </div>
                <div className="p-3 bg-[#F5F8F0] rounded-2xl text-center border border-[#76A900]/20 shrink-0">
                  <span className="text-[10px] uppercase font-bold text-stone-500 block">42 Residentes</span>
                  <span className="font-heading text-lg font-extrabold text-[#073B91]">100% Amor</span>
                </div>
              </div>

              {/* Dynamic Deliverables Pill Showcase */}
              {balancedMix.mix.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                  {balancedMix.mix.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-4 bg-[#F5F8F0]/70 rounded-xl border border-stone-200/70 flex items-center gap-3.5 hover:border-[#76A900]/40 transition-colors"
                    >
                      <span className="w-10 h-10 rounded-xl bg-white shadow-2xs border border-stone-200/80 flex items-center justify-center font-mono font-bold text-base text-[#073B91] shrink-0">
                        {item.count}x
                      </span>
                      <div>
                        <p className="font-heading font-bold text-sm text-[#27343B] leading-tight">
                          {item.name}
                        </p>
                        <p className="text-[11px] text-stone-500 font-body">
                          Garantidos integralmente para os moradores
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-5 bg-stone-50 rounded-xl border border-stone-200 text-stone-600 text-sm mb-6">
                  Valores a partir de R$ 25 já garantem um dia inteiro de 6 refeições balanceadas para um idoso!
                </div>
              )}

              {/* Resident Context Quote */}
              <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-100 flex items-start gap-3">
                <Heart className="w-4 h-4 text-[#073B91] shrink-0 mt-0.5 fill-[#073B91]/20" />
                <p className="text-xs text-[#073B91] leading-relaxed font-body italic">
                  &ldquo;Nossa nutrição supervisionada e produtos de higiene específicos mantêm a pele íntegra e a vitalidade de Dona Lourdinha, Seu Zé e todos os 42 moradores atendidos no Lar.&rdquo;
                  <span className="block not-italic font-semibold text-[11px] text-stone-600 mt-1">
                    — Equipe de Cuidado e Nutrição do Lar Santa Luiza de Marillac
                  </span>
                </p>
              </div>
            </div>

            {/* Individual Item Direct Breakdown Cards */}
            <div>
              <div className="flex items-center justify-between mb-3.5">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-500 font-body">
                  Poder de Compra por Categoria no Lar
                </h4>
                <span className="text-[11px] text-stone-500">
                  Clique em um item para ver o que vem nele
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {calculatedItems.map((item) => {
                  const isExpanded = activeItemDetail === item.id;
                  return (
                    <div
                      key={item.id}
                      onClick={() => setActiveItemDetail(isExpanded ? null : item.id)}
                      className={`p-4 rounded-xl border bg-white transition-all cursor-pointer relative ${
                        item.count > 0 ? 'border-stone-300 shadow-2xs hover:border-[#073B91]' : 'border-stone-200 opacity-80'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className={`p-2 rounded-lg ${item.bgLight} border ${item.borderColor}`}>
                          <item.icon className={`w-4 h-4 ${item.accentColor}`} />
                        </span>
                        <div className="text-right">
                          <span className="font-mono text-xl font-extrabold text-[#073B91] block">
                            {item.count}
                          </span>
                          <span className="text-[10px] text-stone-500 font-mono">
                            {item.unitLabel}{item.count > 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>

                      <h5 className="font-heading font-bold text-xs text-[#27343B] leading-tight mb-1">
                        {item.name}
                      </h5>

                      <p className="text-[11px] text-[#66737A] font-body line-clamp-2">
                        {item.shortDesc}
                      </p>

                      {/* Small progress meter toward next unit */}
                      <div className="mt-3 pt-2 border-t border-stone-100">
                        <div className="flex justify-between text-[10px] text-stone-500 mb-1">
                          <span>R$ {item.unitCost} cada</span>
                          <span>{item.progressPercent}% próx.</span>
                        </div>
                        <div className="w-full h-1.5 bg-stone-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#76A900] rounded-full transition-all duration-300"
                            style={{ width: `${item.progressPercent}%` }}
                          />
                        </div>
                      </div>

                      {/* Expanded Accordion info */}
                      {isExpanded && (
                        <div className="mt-3 pt-3 border-t border-stone-200 text-[11px] text-stone-700 space-y-1.5 animate-in fade-in duration-200">
                          <p className="font-semibold text-stone-900">Composição do item:</p>
                          <ul className="space-y-0.5 text-stone-600">
                            {item.contents.map((c, i) => (
                              <li key={i} className="flex items-center gap-1.5">
                                <CheckCircle2 className="w-3 h-3 text-[#76A900] shrink-0" />
                                <span>{c}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Alternative Action: Material Donation Direct Delivery */}
            <div className="p-5 bg-gradient-to-r from-[#F5F8F0] to-white rounded-2xl border border-stone-200/90 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="space-y-1 text-center sm:text-left">
                <p className="font-heading font-bold text-sm text-[#073B91]">
                  Prefere doar os itens físicos diretamente no Lar?
                </p>
                <p className="text-xs text-stone-600 font-body">
                  Recebemos cestas básicas, pacotes de fraldas e kits de higiene de segunda a sábado em nossa portaria.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (onNavigate) {
                    onNavigate('corrente-do-bem');
                  } else {
                    onOpenDonationModal({ tab: 'material' });
                  }
                }}
                className="shrink-0 px-4 py-2.5 bg-white hover:bg-stone-50 text-[#073B91] border border-[#073B91]/40 rounded-xl text-xs font-semibold shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <span>Ver Lista de Itens Físicos</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
