import React from 'react';
import { Logo } from './Logo';
import { PageRoute } from '../../types';
import { INSTITUTION_INFO } from '../../data/institutionalData';
import { Phone, Mail, MapPin, Instagram, Heart, ArrowUpRight, ShieldCheck, Clock, Calendar } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: () => void;
  onOpenPrivacyModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenDonationModal,
  onOpenPrivacyModal,
}) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full bg-[#FAFBF9] text-[#27343B] border-t border-stone-200 font-body">
      {/* Top Institutional Strip in Welcoming Light Palette */}
      <div className="bg-gradient-to-r from-[#EFF6FF] via-[#F4F9EC] to-[#EFF6FF] border-b border-stone-200/80 py-7 px-4 sm:px-6 lg:px-8 text-[#27343B]">
        <div className="max-w-[1240px] mx-auto flex flex-col md:flex-row items-center justify-between gap-5 text-center md:text-left">
          <div className="flex items-center gap-3.5">
            <span className="p-2.5 bg-[#073B91]/10 text-[#073B91] rounded-2xl shrink-0">
              <Heart className="w-6 h-6 text-[#76A900] fill-[#76A900]/20" />
            </span>
            <div>
              <p className="font-heading text-base sm:text-lg font-bold text-[#073B91]">
                Participe da nossa rede de apoio e solidariedade
              </p>
              <p className="text-xs sm:text-sm text-[#4A5568] font-body mt-0.5">
                Sua ajuda transforma cuidado em acolhimento diário para dezenas de idosos residentes em Juiz de Fora.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenDonationModal}
            className="px-6 py-3 text-xs sm:text-sm font-bold text-white bg-[#76A900] hover:bg-[#689400] rounded-xl transition-all shadow-xs hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 whitespace-nowrap shrink-0 font-body cursor-pointer flex items-center gap-2"
          >
            <Heart className="w-4 h-4 fill-white" />
            <span>Faça sua contribuição</span>
          </button>
        </div>
      </div>

      {/* Main Footer Contents in Pure Light Mode */}
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Col 1: Institutional Presentation */}
          <div className="space-y-4">
            <Logo size="md" showUploadButton={true} />
            <p className="text-xs sm:text-sm text-[#4A5568] leading-relaxed pt-2">
              Instituição de Longa Permanência para Idosos (ILPI), de caráter filantrópico e sem fins lucrativos, sediada em Juiz de Fora - MG. Há mais de cinco décadas cuidando da pessoa idosa com dignidade, segurança e afeto.
            </p>
            <div className="inline-flex items-center gap-2 p-2.5 rounded-xl bg-white border border-stone-200/90 shadow-2xs text-xs text-[#073B91] font-medium">
              <ShieldCheck className="w-4 h-4 text-[#76A900] shrink-0" />
              <span>Entidade Beneficente Registrada · ILPI</span>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div>
            <h3 className="text-xs font-bold tracking-wider uppercase text-[#073B91] mb-4 font-heading">
              Navegação Institucional
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="text-[#4A5568] hover:text-[#073B91] font-medium transition-colors cursor-pointer text-left"
                >
                  Início
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('sobre')}
                  className="text-[#4A5568] hover:text-[#073B91] font-medium transition-colors cursor-pointer text-left"
                >
                  Sobre Nós
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('nossa-historia')}
                  className="text-[#4A5568] hover:text-[#073B91] font-medium transition-colors cursor-pointer text-left"
                >
                  Nossa História
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('corrente-do-bem')}
                  className="text-[#4A5568] hover:text-[#073B91] font-medium transition-colors cursor-pointer text-left"
                >
                  Corrente do Bem (Lista de Necessidades)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('transparencia')}
                  className="text-[#4A5568] hover:text-[#073B91] font-medium transition-colors cursor-pointer text-left"
                >
                  Transparência & Prestação de Contas
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contato')}
                  className="text-[#4A5568] hover:text-[#073B91] font-medium transition-colors cursor-pointer text-left"
                >
                  Fale Conosco & Localização
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact & Channels */}
          <div>
            <h3 className="text-xs font-bold tracking-wider uppercase text-[#073B91] mb-4 font-heading">
              Canais de Contato
            </h3>
            <ul className="space-y-3 text-sm text-[#4A5568]">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#76A900] shrink-0 mt-0.5" />
                <div>
                  <span className="font-medium text-[#27343B]">{INSTITUTION_INFO.address}</span>
                  <span className="text-xs text-[#66737A] block">
                    {INSTITUTION_INFO.addressComplement} · CEP {INSTITUTION_INFO.cep}
                  </span>
                  <span className="text-[11px] text-[#073B91] block font-medium mt-0.5">
                    Ônibus: Linhas {INSTITUTION_INFO.busLinesText}
                  </span>
                </div>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#76A900] shrink-0" />
                <a
                  href={`tel:${INSTITUTION_INFO.phoneClean}`}
                  className="hover:text-[#073B91] font-semibold text-[#27343B] transition-colors"
                >
                  {INSTITUTION_INFO.phone}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#76A900] shrink-0" />
                <a
                  href={`mailto:${INSTITUTION_INFO.email}`}
                  className="hover:text-[#073B91] transition-colors break-all"
                >
                  {INSTITUTION_INFO.email}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Instagram className="w-4 h-4 text-[#76A900] shrink-0" />
                <a
                  href={INSTITUTION_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#073B91] transition-colors inline-flex items-center gap-1 font-medium"
                >
                  <span>{INSTITUTION_INFO.instagram}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-stone-400" />
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Important Clarifications & Visits */}
          <div>
            <h3 className="text-xs font-bold tracking-wider uppercase text-[#073B91] mb-4 font-heading">
              Atendimento e Visitas
            </h3>
            <p className="text-xs text-[#4A5568] leading-relaxed mb-3">
              {INSTITUTION_INFO.hours}
            </p>
            <div className="p-4 rounded-xl bg-white border border-stone-200/90 shadow-2xs text-xs text-[#4A5568] space-y-1">
              <p className="font-semibold text-[#073B91] flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#76A900]" />
                <span>Acolhimento com responsabilidade:</span>
              </p>
              <p className="text-stone-600">{INSTITUTION_INFO.visitHours}.</p>
            </div>
            <div className="mt-4 pt-3 border-t border-stone-200">
              <button
                onClick={onOpenPrivacyModal}
                className="text-xs text-[#66737A] hover:text-[#073B91] transition-colors underline underline-offset-2 cursor-pointer"
              >
                Política de Privacidade & Proteção de Dados (LGPD)
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Credits and Copyright */}
        <div className="mt-12 pt-8 border-t border-stone-200/90 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#66737A]">
          <p>
            © {currentYear} {INSTITUTION_INFO.name}. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-4">
            <button
              onClick={onOpenPrivacyModal}
              className="hover:text-[#073B91] transition-colors cursor-pointer"
            >
              Termos de Privacidade
            </button>
            <span aria-hidden="true" className="text-stone-300">·</span>
            <span className="text-[#073B91] font-semibold">
              Instituição Filantrópica em Juiz de Fora - MG
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
