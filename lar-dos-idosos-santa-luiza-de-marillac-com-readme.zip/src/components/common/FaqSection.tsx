import React, { useState } from 'react';
import { ChevronDown, HelpCircle, Heart, Phone, Calendar, ArrowRight } from 'lucide-react';
import { INSTITUTION_INFO } from '../../data/institutionalData';
import { PageRoute } from '../../types';

export interface FaqItem {
  id: string;
  category: 'geral' | 'cuidados' | 'doacoes' | 'visitas';
  question: string;
  answer: string;
}

const FAQ_DATA: FaqItem[] = [
  {
    id: 'faq-ilpi',
    category: 'geral',
    question: 'Como funciona o acolhimento residencial no Lar Santa Luiza de Marillac?',
    answer:
      'O Lar é uma Instituição de Longa Permanência para Idosos (ILPI), filantrópica e sem fins lucrativos, sediada em Juiz de Fora. Oferecemos moradia protegida, alimentação nutritiva, assistência de enfermagem contínua e convivência fraterna para idosos que necessitam de acolhimento integral, especialmente em situações de vulnerabilidade social ou sem retaguarda familiar.',
  },
  {
    id: 'faq-clinica',
    category: 'geral',
    question: 'O Lar funciona como clínica médica aberta ao público ou hospital de passagem?',
    answer:
      'Não. O Lar Santa Luiza de Marillac é estritamente uma moradia coletiva e acolhedora para os idosos residentes. Não prestamos serviços ambulatoriais para pessoas de fora, nem pronto-socorro. Nosso foco é oferecer um ambiente familiar, tranquilo, seguro e privativo aos nossos moradores acolhidos.',
  },
  {
    id: 'faq-enfermagem',
    category: 'cuidados',
    question: 'Como são administrados os medicamentos e os cuidados de saúde diários?',
    answer:
      'Nossa equipe de enfermagem atua em regime de 24 horas ininterruptas. Todas as medicações são rigorosamente conferidas e administradas de acordo com as prescrições dos médicos responsáveis por cada residente. Além disso, realizamos o controle diário de sinais vitais (pressão arterial, glicemia, temperatura) e acompanhamento atencioso.',
  },
  {
    id: 'faq-visitas',
    category: 'visitas',
    question: 'Como e quando as famílias e a comunidade podem realizar visitas?',
    answer:
      'As visitas são muito bem-vindas, pois o carinho e a presença fazem bem ao coração dos nossos residentes. Para garantir a organização da casa e o repouso dos moradores, solicitamos que as visitas sejam agendadas previamente com nossa secretaria de segunda a sexta-feira, das 08h às 17h, preferencialmente nos turnos da manhã (09h às 11h) ou tarde (14h às 16h).',
  },
  {
    id: 'faq-doacoes-materiais',
    category: 'doacoes',
    question: 'Quais doações materiais o Lar mais necessita no dia a dia?',
    answer:
      'Nossas maiores demandas contínuas envolvem fraldas geriátricas descartáveis (tamanhos G e GG), leite integral pasteurizado ou UHT, produtos de higiene pessoal para peles sensíveis (como sabonetes líquidos hidratantes), além de produtos de limpeza e assepsia hospitalar para os quartos e áreas comuns. Você pode consultar os itens prioritários na nossa página "Corrente do Bem".',
  },
  {
    id: 'faq-transparencia',
    category: 'doacoes',
    question: 'Como a sociedade civil pode acompanhar a aplicação das doações?',
    answer:
      'A transparência é um compromisso inegociável da nossa diretoria. Disponibilizamos periodicamente no portal da instituição os balancetes contábeis, relatórios anuais de atividades e certificados de assistência social (CEBAS). Todas as contas são fiscalizadas e aprovadas pelo Conselho Fiscal da entidade.',
  },
  {
    id: 'faq-voluntariado',
    category: 'geral',
    question: 'Como posso participar como voluntário ou propor uma atividade fraterna?',
    answer:
      'Pessoas e grupos que desejam compartilhar música, leitura, artesanato, conversas ou apoio aos nossos idosos são sempre recebidos com gratidão. Basta entrar em contato com nossa coordenação através da página de Contato ou pelo WhatsApp para alinharmos os horários e o formato da atividade.',
  },
];

interface FaqSectionProps {
  onNavigate?: (page: PageRoute) => void;
  onOpenVisitModal?: () => void;
  onOpenDonationModal?: () => void;
}

export const FaqSection: React.FC<FaqSectionProps> = ({
  onNavigate,
  onOpenVisitModal,
  onOpenDonationModal,
}) => {
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({
    'faq-ilpi': true, // First item opened by default for immediate discoverability
  });
  const [activeCategory, setActiveCategory] = useState<string>('todos');

  const categories = [
    { id: 'todos', label: 'Todas as dúvidas' },
    { id: 'geral', label: 'Sobre a Instituição' },
    { id: 'cuidados', label: 'Cuidados & Saúde' },
    { id: 'visitas', label: 'Visitas & Família' },
    { id: 'doacoes', label: 'Doações & Transparência' },
  ];

  const toggleItem = (id: string) => {
    setOpenItems((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const filteredFaqs = FAQ_DATA.filter((item) => {
    if (activeCategory === 'todos') return true;
    return item.category === activeCategory;
  });

  return (
    <section
      aria-labelledby="faq-heading"
      className="py-20 lg:py-28 bg-gradient-to-b from-[#EFF5FD] via-[#FAFBF7] to-[#EFF5FD] border-b border-[#073B91]/15 font-body"
    >
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Cabeçalho da Seção */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F5F8F0] border border-stone-200/80 text-xs font-semibold text-[#073B91] tracking-wider uppercase">
            <HelpCircle className="w-3.5 h-3.5 text-[#073B91]" />
            <span>Perguntas Frequentes</span>
          </div>

          <h2 id="faq-heading" className="font-heading text-3xl sm:text-4xl font-bold text-[#27343B]">
            Dúvidas Comuns sobre o Lar
          </h2>

          <p className="text-base text-[#66737A] font-body">
            Reunimos as respostas para as principais questões institucionais, rotinas de cuidado, agendamento de visitas e formas de doação em Juiz de Fora.
          </p>

          {/* Abas de Categorias */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 text-xs font-semibold rounded-full transition-all cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#073B91] text-white shadow-xs'
                    : 'bg-[#F5F8F0] text-[#27343B] hover:bg-stone-200/70 border border-stone-200/60'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Lista Sanfona (Accordion) */}
        <div className="max-w-3xl mx-auto space-y-3.5">
          {filteredFaqs.map((faq) => {
            const isOpen = !!openItems[faq.id];
            return (
              <div
                key={faq.id}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'bg-[#F5F8F0]/40 border-[#073B91]/30 shadow-xs'
                    : 'bg-white border-stone-200 hover:border-stone-300'
                }`}
              >
                <button
                  type="button"
                  id={`faq-btn-${faq.id}`}
                  aria-expanded={isOpen}
                  aria-controls={`faq-answer-${faq.id}`}
                  onClick={() => toggleItem(faq.id)}
                  className="w-full py-4.5 px-5 sm:px-6 flex items-center justify-between text-left gap-4 transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-[#073B91] cursor-pointer"
                >
                  <span className="font-heading font-bold text-base sm:text-lg text-[#27343B]">
                    {faq.question}
                  </span>
                  <div
                    className={`p-1.5 rounded-full transition-transform duration-200 shrink-0 ${
                      isOpen
                        ? 'bg-[#073B91] text-white rotate-180'
                        : 'bg-stone-100 text-stone-600'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div
                    id={`faq-answer-${faq.id}`}
                    role="region"
                    aria-labelledby={`faq-btn-${faq.id}`}
                    className="px-5 pb-5 sm:px-6 sm:pb-6 text-sm text-[#66737A] font-body leading-relaxed border-t border-stone-200/50 pt-3 animate-in fade-in duration-150"
                  >
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bloco de Ajuda Complementar */}
        <div className="mt-14 max-w-3xl mx-auto p-6 sm:p-8 rounded-2xl bg-[#F5F8F0] border border-stone-200/80 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="font-heading font-bold text-base text-[#073B91]">
              Ainda tem alguma dúvida específica?
            </h4>
            <p className="text-xs sm:text-sm text-[#66737A]">
              Nossa equipe da secretaria e assistência social está à disposição para esclarecimentos.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {onOpenVisitModal && (
              <button
                type="button"
                onClick={onOpenVisitModal}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-[#073B91] bg-white hover:bg-stone-100 border border-stone-300 rounded-lg transition-colors cursor-pointer"
              >
                <Calendar className="w-3.5 h-3.5 text-[#073B91]" />
                <span>Agendar Visita</span>
              </button>
            )}

            {onNavigate && (
              <button
                type="button"
                onClick={() => onNavigate('contato')}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-colors cursor-pointer"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Fale Conosco</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
