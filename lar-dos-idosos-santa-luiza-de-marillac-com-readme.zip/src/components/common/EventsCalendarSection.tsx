import React, { useState, useId, useRef, useEffect, useCallback } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Users,
  ChevronLeft,
  ChevronRight,
  Filter,
  Search,
  Sparkles,
  Share2,
  Download,
  CalendarPlus,
  Volume2,
  VolumeX,
  X,
  Heart,
  CalendarCheck,
  Check,
  Info,
  ArrowRight,
  Sun,
  Activity,
  Smile,
  Music,
  Church,
  PartyPopper,
  LayoutGrid,
  List,
} from 'lucide-react';
import { INSTITUTION_INFO } from '../../data/institutionalData';
import { notifySuccess } from '../../utils/notifications';

export type EventCategory =
  | 'todos'
  | 'recreativo'
  | 'social'
  | 'comemorativo'
  | 'espiritual'
  | 'saude';

export interface CalendarEvent {
  id: string;
  title: string;
  year: number;
  month: number; // 0-indexed: 9 = Oct, 10 = Nov, 11 = Dec, 0 = Jan
  day: number;
  time: string;
  formattedDate: string;
  category: 'recreativo' | 'social' | 'comemorativo' | 'espiritual' | 'saude';
  categoryLabel: string;
  location: string;
  audienceType: 'aberto_comunidade' | 'voluntarios' | 'residentes_familias';
  audienceLabel: string;
  description: string;
  objective: string;
  volunteerRole?: string;
  highlight?: boolean;
}

export const CALENDAR_EVENTS: CalendarEvent[] = [
  // ==========================================
  // OUTUBRO 2026 (Mês 9)
  // ==========================================
  {
    id: 'evt-2026-10-01',
    title: 'Abertura do Outubro Prateado & Celebração do Dia da Pessoa Idosa',
    year: 2026,
    month: 9,
    day: 1,
    time: '14:00 às 16:30',
    formattedDate: '01 de Outubro de 2026 · Quinta-feira',
    category: 'comemorativo',
    categoryLabel: 'Datas Comemorativas',
    location: 'Pátio Central das Jabuticabeiras & Hall',
    audienceType: 'aberto_comunidade',
    audienceLabel: 'Aberto a Familiares & Comunidade',
    highlight: true,
    description:
      'Celebração solene e festiva marcando o Dia Internacional da Pessoa Idosa e abertura do Outubro Prateado. Tarde com café especial mineiro, exposição de pinturas e cartas produzidas pelos moradores, e apresentação musical de boas-vindas com voz e violão.',
    objective:
      'Valorização da biografia, protagonismo dos idosos na sociedade civil e fortalecimento dos laços com a comunidade de Juiz de Fora.',
    volunteerRole:
      'Apoio no acolhimento de visitantes, condução de idosos com mobilidade reduzida e distribuição de lembranças artesanais.',
  },
  {
    id: 'evt-2026-10-07',
    title: 'Roda de Canto Coletivo & Memória Musical com o Coral de Voluntários',
    year: 2026,
    month: 9,
    day: 7,
    time: '15:00 às 16:30',
    formattedDate: '07 de Outubro de 2026 · Quarta-feira',
    category: 'recreativo',
    categoryLabel: 'Recreativo & Lúdico',
    location: 'Salão Multiuso de Convivência',
    audienceType: 'voluntarios',
    audienceLabel: 'Atividade com Moradores e Voluntários',
    description:
      'Encontro musical com repertório de seresta, bossa nova e cantigas mineiras tradicionais. Residentes cantam juntos com acompanhamento de violão acústico e instrumentos percussivos suaves adaptados.',
    objective:
      'Estimulação neurocognitiva através da memória melódica, resgate de lembranças afetivas e prevenção do isolamento social.',
    volunteerRole:
      'Músicos voluntários e acompanhantes para incentivar a participação carinhosa de cada residente.',
  },
  {
    id: 'evt-2026-10-13',
    title: 'Circuito de Mobilidade Ativa & Fisioterapia Lúdica com a UFJF',
    year: 2026,
    month: 9,
    day: 13,
    time: '09:30 às 11:00',
    formattedDate: '13 de Outubro de 2026 · Terça-feira (Hoje)',
    category: 'saude',
    categoryLabel: 'Saúde & Movimento',
    location: 'Jardim Terapêutico e Pérgola do Lar',
    audienceType: 'residentes_familias',
    audienceLabel: 'Atividade Interna Assistida',
    highlight: true,
    description:
      'Exercícios prazerosos de alongamento, equilíbrio postural e coordenação motora com bolas macias, fitas e músicas suaves, conduzidos pela equipe de fisioterapia em parceria com estagiários da Faculdade de Fisioterapia da UFJF.',
    objective:
      'Prevenção de quedas, manutenção da autonomia motora diária e estímulo à circulação sanguínea de maneira leve e bem-humorada.',
    volunteerRole:
      'Estudantes e residentes da área de saúde apoiam o monitoramento postural individualizado.',
  },
  {
    id: 'evt-2026-10-14',
    title: 'Oficina de Jardinagem Terapêutica na Horta Suspensa Sensorial',
    year: 2026,
    month: 9,
    day: 14,
    time: '14:30 às 16:00',
    formattedDate: '14 de Outubro de 2026 · Quarta-feira',
    category: 'recreativo',
    categoryLabel: 'Recreativo & Lúdico',
    location: 'Horta Suspensa e Estufa do Lar',
    audienceType: 'voluntarios',
    audienceLabel: 'Moradores e Voluntários da Terra',
    description:
      'Plantio de mudas de ervas medicinais e temperos caseiros (hortelã, manjericão, alecrim e camomila) em bancadas elevadas acessíveis a cadeirantes. Residentes tocam na terra e preparam os vasinhos.',
    objective:
      'Estimulação tátil e olfativa, reconexão com a natureza e sensação de cuidado e utilidade ativa.',
    volunteerRole:
      'Auxílio no transporte de vasos, regadores leves e organização das ferramentas de jardinagem adaptadas.',
  },
  {
    id: 'evt-2026-10-18',
    title: 'Santa Missa Dominical da Fraternidade & Bênção dos Idosos',
    year: 2026,
    month: 9,
    day: 18,
    time: '10:00 às 11:15',
    formattedDate: '18 de Outubro de 2026 · Domingo',
    category: 'espiritual',
    categoryLabel: 'Espiritual & Reflexão',
    location: 'Capela Institucional Santa Luiza de Marillac',
    audienceType: 'aberto_comunidade',
    audienceLabel: 'Aberta a Familiares e Amigos do Lar',
    description:
      'Celebração litúrgica tradicional em ação de graças pelos 42 residentes do Lar, colaboradores e voluntários vicentinos de Juiz de Fora. Momento ecumênico de acolhimento e renovação da fé.',
    objective:
      'Conforto espiritual, paz interior e preservação das práticas religiosas que fazem parte da história de vida dos acolhidos.',
    volunteerRole:
      'Auxílio na condução dos moradores até a capela e organização das leituras comunitárias.',
  },
  {
    id: 'evt-2026-10-23',
    title: 'Baile e Chá da Tarde dos Aniversariantes de Outubro',
    year: 2026,
    month: 9,
    day: 23,
    time: '14:30 às 17:00',
    formattedDate: '23 de Outubro de 2026 · Sexta-feira',
    category: 'comemorativo',
    categoryLabel: 'Datas Comemorativas',
    location: 'Refeitório Comunitário e Pátio Externo',
    audienceType: 'residentes_familias',
    audienceLabel: 'Festa com Moradores e Famílias',
    highlight: true,
    description:
      'Comemoração alegre dos aniversários de Dona Lourdes, Seu Antônio e demais residentes nascidos em outubro. Bolo festivo balanceado preparado pela nutrição, docinhos típicos e pista de dança adaptada.',
    objective:
      'Celebração da vida, fortalecimento do sentimento de pertença e resgate do valor de cada história pessoal.',
    volunteerRole:
      'Decoração com balões coloridos, distribuição das fatias de bolo e acompanhamento carinhoso no baile.',
  },
  {
    id: 'evt-2026-10-28',
    title: 'Sessão Cine Retrô: Filmes de Época com Pipoca Saudável',
    year: 2026,
    month: 9,
    day: 28,
    time: '15:30 às 17:00',
    formattedDate: '28 de Outubro de 2026 · Quarta-feira',
    category: 'recreativo',
    categoryLabel: 'Recreativo & Lúdico',
    location: 'Sala de TV e Multimídia do Lar',
    audienceType: 'residentes_familias',
    audienceLabel: 'Atividade Interna de Lazer',
    description:
      'Exibição em telão de clássicos da comédia brasileira dos anos 1950 e 1960 (Mazzaropi e Carmen Miranda), acompanhada de pipoca sem gordura saturada e sucos naturais da horta.',
    objective:
      'Divertimento em grupo, estimulação da atenção sustentada e troca de conversas animadas sobre o cinema de antigamente.',
    volunteerRole:
      'Operação de áudio e vídeo e acompanhamento dos idosos durante a sessão.',
  },

  // ==========================================
  // NOVEMBRO 2026 (Mês 10)
  // ==========================================
  {
    id: 'evt-2026-11-04',
    title: 'Oficina Intergeracional de Pintura e Cartas com Estudantes de JF',
    year: 2026,
    month: 10,
    day: 4,
    time: '14:30 às 16:30',
    formattedDate: '04 de Novembro de 2026 · Quarta-feira',
    category: 'social',
    categoryLabel: 'Social & Comunitário',
    location: 'Salão Multiuso de Convivência',
    audienceType: 'aberto_comunidade',
    audienceLabel: 'Aberto a Escolas e Voluntários',
    highlight: true,
    description:
      'Jovens estudantes de escolas de Juiz de Fora visitam o Lar para uma tarde de criação de cartões artísticos em aquarela e troca de confidências sobre infância, livros e sonhos entre gerações.',
    objective:
      'Superação de estereótipos etários, estímulo cognitivo e combate à sensação de solidão na terceira idade.',
    volunteerRole:
      'Facilitação das mesas de pintura e apoio aos estudantes no primeiro contato fraterno.',
  },
  {
    id: 'evt-2026-11-11',
    title: 'Tarde do Bingo Festivo da Amizade com Prêmios Carinhosos',
    year: 2026,
    month: 10,
    day: 11,
    time: '15:00 às 16:30',
    formattedDate: '11 de Novembro de 2026 · Quarta-feira',
    category: 'recreativo',
    categoryLabel: 'Recreativo & Lúdico',
    location: 'Salão de Jogos e Refeitório',
    audienceType: 'voluntarios',
    audienceLabel: 'Residentes e Voluntários Auxiliares',
    description:
      'Tradicional bingo beneficente interno com cartelas em fontes ampliadas para facilitar a leitura. Os prêmios são mimos doados por voluntários: xales, sabonetes artesanais, hidratantes e chaveiros.',
    objective:
      'Atenção concentrada, acuidade visual lúdica e momentos de risada e torcida compartilhada entre os residentes.',
    volunteerRole:
      'Cantar as pedras com voz clara e pausada e auxiliar os idosos a conferirem suas cartelas.',
  },
  {
    id: 'evt-2026-11-15',
    title: 'Almoço da Família Vicentina no Jardim das Mangueiras',
    year: 2026,
    month: 10,
    day: 15,
    time: '11:30 às 14:30',
    formattedDate: '15 de Novembro de 2026 · Domingo (Feriado)',
    category: 'social',
    categoryLabel: 'Social & Comunitário',
    location: 'Área Externa e Pérgola dos Ipês',
    audienceType: 'residentes_familias',
    audienceLabel: 'Familiares e Benfeitores Cadastrados',
    highlight: true,
    description:
      'Encontro de confraternização reunindo familiares dos residentes e amigos vicentinos. Cardápio típico mineiro com feijão tropeiro adaptado, saladas frescas da horta e sobremesas sem adição de açúcar.',
    objective:
      'Manutenção e estreitamento dos vínculos familiares, mesmo para residentes cujas famílias residem em outras cidades.',
    volunteerRole:
      'Recepção aos familiares, apoio no buffet assistido e organização dos espaços de conversa ao ar livre.',
  },
  {
    id: 'evt-2026-11-20',
    title: 'Serenata e Modas de Viola: Tributo à Tradição Caipira Mineira',
    year: 2026,
    month: 10,
    day: 20,
    time: '14:30 às 16:30',
    formattedDate: '20 de Novembro de 2026 · Sexta-feira',
    category: 'recreativo',
    categoryLabel: 'Recreativo & Lúdico',
    location: 'Pátio Central das Jabuticabeiras',
    audienceType: 'aberto_comunidade',
    audienceLabel: 'Aberto à Comunidade e Visitantes',
    description:
      'Apresentação beneficente de violeiros da Zona da Mata com clássicos de Tião Carreiro, Tonico & Tinoco e Almir Sater, com cafezinho passado na hora e biscoitos de polvilho.',
    objective:
      'Reativação de memórias biográficas de quem viveu no interior de Minas e relaxamento emocional.',
    volunteerRole:
      'Acolhimento da plateia e auxílio no serviço do café colonial fraterno.',
  },
  {
    id: 'evt-2026-11-26',
    title: 'Dia de Gratidão e Ação de Graças: O Mural dos Agradecimentos',
    year: 2026,
    month: 10,
    day: 26,
    time: '14:00 às 16:00',
    formattedDate: '26 de Novembro de 2026 · Quinta-feira',
    category: 'espiritual',
    categoryLabel: 'Espiritual & Reflexão',
    location: 'Capela e Hall de Convivência',
    audienceType: 'residentes_familias',
    audienceLabel: 'Moradores, Funcionários e Voluntários',
    description:
      'Momento reflexivo e ecumênico em que cada morador, cuidador e visitante registra em folhas coloridas de papel semente motivos de gratidão vivenciados no Lar durante o ano.',
    objective:
      'Estímulo ao otimismo, psicologia positiva aplicada à geriatria e cultivo do afeto diário.',
    volunteerRole:
      'Escuta atenta para escrever mensagens para residentes que não conseguem grafar sozinhos.',
  },
  {
    id: 'evt-2026-11-27',
    title: 'Comemoração dos Aniversariantes do Mês de Novembro',
    year: 2026,
    month: 10,
    day: 27,
    time: '14:30 às 17:00',
    formattedDate: '27 de Novembro de 2026 · Sexta-feira',
    category: 'comemorativo',
    categoryLabel: 'Datas Comemorativas',
    location: 'Salão de Convivência Principal',
    audienceType: 'residentes_familias',
    audienceLabel: 'Festa com Residentes e Famílias',
    description:
      'Festa mensal com repertório instrumental de boleros dos anos 60, bolo comemorativo, entrega de fotografias emolduradas de cada aniversariante e parabéns caloroso.',
    objective:
      'Autoestima, celebração da biografia de cada aniversariante e sociabilidade ativa.',
    volunteerRole:
      'Distribuição dos presentes e auxílio na condução dos cadeirantes durante as danças de salão.',
  },

  // ==========================================
  // DEZEMBRO 2026 (Mês 11)
  // ==========================================
  {
    id: 'evt-2026-12-02',
    title: 'Oficina de Natal Sustentável & Montagem da Árvore dos Desejos',
    year: 2026,
    month: 11,
    day: 2,
    time: '14:00 às 16:30',
    formattedDate: '02 de Dezembro de 2026 · Quarta-feira',
    category: 'recreativo',
    categoryLabel: 'Recreativo & Lúdico',
    location: 'Salão Multiuso de Artesanato',
    audienceType: 'voluntarios',
    audienceLabel: 'Moradores e Voluntários Artísticos',
    description:
      'Residentes confeccionam estrelas de tecido, guirlandas com pinhas recolhidas no jardim e cartões natalinos para ornamentar o Lar. Cada morador pendura seu pedido simples na Árvore dos Desejos.',
    objective:
      'Estímulo motor fino, imaginação, sensação de autonomia e expectativa positiva pelas festas.',
    volunteerRole:
      'Apoio com materiais artesanais, recorte de feltro e fixação dos laços nas guirlandas.',
  },
  {
    id: 'evt-2026-12-08',
    title: 'Dia da Imaculada Conceição: Bênção do Presépio Histórico do Lar',
    year: 2026,
    month: 11,
    day: 8,
    time: '10:00 às 11:30',
    formattedDate: '08 de Dezembro de 2026 · Terça-feira',
    category: 'espiritual',
    categoryLabel: 'Espiritual & Reflexão',
    location: 'Capela Santa Luiza de Marillac',
    audienceType: 'aberto_comunidade',
    audienceLabel: 'Aberta a Visitantes e Familiares',
    description:
      'Inauguração do presépio artesanal de cerâmica que acompanha o Lar há mais de quarenta anos, com bênção sacerdotal e cânticos marianos entoados com o acompanhamento do harmônio da capela.',
    objective:
      'Tradição cultural vicentina, acolhimento da religiosidade dos acolhidos e serenidade interior.',
    volunteerRole:
      'Apoio aos idosos na oração e distribuição das estampas comemorativas.',
  },
  {
    id: 'evt-2026-12-13',
    title: 'Grande Festa de Natal dos Moradores: Chegada do Papai Noel & Presentes',
    year: 2026,
    month: 11,
    day: 13,
    time: '14:00 às 17:30',
    formattedDate: '13 de Dezembro de 2026 · Domingo',
    category: 'comemorativo',
    categoryLabel: 'Datas Comemorativas',
    location: 'Jardim Principal e Pátio das Jabuticabeiras',
    audienceType: 'aberto_comunidade',
    audienceLabel: 'Comunidade, Doadores e Famílias',
    highlight: true,
    description:
      'O momento mais festivo do ano no Lar! Entrega individualizada dos presentes adotados pela comunidade através da campanha solidária de Natal, com Papai Noel voluntário, mesa de frutas e risadas.',
    objective:
      'Garantir que nenhum idoso se sinta esquecido no Natal, resgatando a magia e a ternura das festas.',
    volunteerRole:
      'Recepção dos pacotes de presentes doados pela comunidade, organização da fila do Papai Noel e registros fotográficos para os familiares.',
  },
  {
    id: 'evt-2026-12-18',
    title: 'Cantata de Natal das Janelas Iluminadas do Lar Santa Luiza',
    year: 2026,
    month: 11,
    day: 18,
    time: '18:30 às 20:30',
    formattedDate: '18 de Dezembro de 2026 · Sexta-feira',
    category: 'social',
    categoryLabel: 'Social & Comunitário',
    location: 'Fachada Iluminada e Calçada da Rua Furtado de Menezes',
    audienceType: 'aberto_comunidade',
    audienceLabel: 'Aberto a toda Juiz de Fora',
    highlight: true,
    description:
      'Tradicional cantata com coral voluntário e instrumentistas se apresentando sob as janelas ornamentadas com luzes natalinas do casarão. Residentes assistem da varanda envidraçada protegida com seus cobertores e café quente.',
    objective:
      'Integração profunda do Lar com a vizinhança da Vila Furtado de Menezes e celebração ecumênica da fraternidade.',
    volunteerRole:
      'Orientação do público na calçada, distribuição de folhetos com as letras dos hinos e apoio aos moradores na varanda.',
  },
  {
    id: 'evt-2026-12-24',
    title: 'Ceia Afetiva de Véspera de Natal com Moradores e Cuidadores',
    year: 2026,
    month: 11,
    day: 24,
    time: '18:00 às 20:30',
    formattedDate: '24 de Dezembro de 2026 · Quinta-feira',
    category: 'comemorativo',
    categoryLabel: 'Datas Comemorativas',
    location: 'Refeitório Comunitário Festivo',
    audienceType: 'residentes_familias',
    audienceLabel: 'Exclusivo a Moradores e Famílias',
    description:
      'Ceia carinhosamente preparada pela nutricionista com pernil suculento e macio desfiado, purê de batata baroa, salpicão leve e sobremesas adequadas para dietas com restrição de açúcar.',
    objective:
      'Garantir aconchego, segurança e a sensação genuína de estar em família na noite de Natal.',
    volunteerRole:
      'Voluntários com disponibilidade ajudam a servir os pratos e fazem companhia a idosos sem parentes próximos.',
  },
  {
    id: 'evt-2026-12-31',
    title: 'Brinde Fraterno da Paz & Desejos para o Novo Ano de 2027',
    year: 2026,
    month: 11,
    day: 31,
    time: '17:00 às 19:30',
    formattedDate: '31 de Dezembro de 2026 · Quinta-feira',
    category: 'comemorativo',
    categoryLabel: 'Datas Comemorativas',
    location: 'Pátio Central das Jabuticabeiras',
    audienceType: 'residentes_familias',
    audienceLabel: 'Moradores, Equipe e Voluntários',
    description:
      'Brinde da tarde com taças de suco de uva integral e espumante sem álcool, frutas da época e momento de preces pelos dias de paz e saúde no ano que se inicia.',
    objective:
      'Renovação de esperança, valorização do tempo presente e gratidão pela convivência cotidiana.',
    volunteerRole:
      'Apoio no serviço dos brindes e acolhimento afetuoso dos moradores.',
  },

  // ==========================================
  // JANEIRO 2027 (Mês 0)
  // ==========================================
  {
    id: 'evt-2027-01-06',
    title: 'Folia de Reis: Cantoria Tradicional e Bênção dos Santos Reis',
    year: 2027,
    month: 0,
    day: 6,
    time: '15:00 às 17:00',
    formattedDate: '06 de Janeiro de 2027 · Quarta-feira',
    category: 'social',
    categoryLabel: 'Social & Comunitário',
    location: 'Pátio Externo do Lar',
    audienceType: 'aberto_comunidade',
    audienceLabel: 'Aberto à Comunidade e Moradores',
    highlight: true,
    description:
      'Visita do tradicional grupo de Folia de Reis de Juiz de Fora com vestimentas bordadas, palhaços mascarados, bandeiras devotas e versos rimados ao som de violas e pandeiros.',
    objective:
      'Preservação do patrimônio cultural mineiro e recordação das festas de Reis da infância rural dos moradores.',
    volunteerRole:
      'Acolhimento da trupe de reisados e serviço de lanche comunitário com broa de milho e café.',
  },
  {
    id: 'evt-2027-01-13',
    title: 'Sessão de Aromaterapia Sensorial & Relaxamento Terapêutico',
    year: 2027,
    month: 0,
    day: 13,
    time: '14:30 às 16:00',
    formattedDate: '13 de Janeiro de 2027 · Quarta-feira',
    category: 'saude',
    categoryLabel: 'Saúde & Movimento',
    location: 'Sala de Fisioterapia e Espaço Zen',
    audienceType: 'residentes_familias',
    audienceLabel: 'Atividade Terapêutica Assistida',
    description:
      'Técnicas de respiração profunda e relaxamento muscular com difusão de essências naturais de alfazema e bergamota, aliadas a toques terapêuticos e massagens suaves nas mãos.',
    objective:
      'Redução de sintomas ansiosos, melhora da percepção sensorial e conforto emocional.',
    volunteerRole:
      'Profissionais de fisioterapia e massoterapia voluntária auxiliam nos toques manuais suaves.',
  },
  {
    id: 'evt-2027-01-20',
    title: 'Torneio Amistoso de Dominó, Damas e Jogos de Mesa',
    year: 2027,
    month: 0,
    day: 20,
    time: '14:30 às 16:30',
    formattedDate: '20 de Janeiro de 2027 · Quarta-feira',
    category: 'recreativo',
    categoryLabel: 'Recreativo & Lúdico',
    location: 'Salão de Jogos e Refeitório',
    audienceType: 'voluntarios',
    audienceLabel: 'Residentes e Jovens Voluntários',
    description:
      'Competição lúdica em duplas onde moradores e voluntários disputam partidas de dominó com peças grandes, damas e memória. Todos os participantes recebem medalhas personalizadas.',
    objective:
      'Estímulo ao raciocínio lógico, agilidade mental e interação bem-humorada.',
    volunteerRole:
      'Jogar em parceria com idosos e incentivar a torcida e os momentos de brincadeira.',
  },
  {
    id: 'evt-2027-01-29',
    title: 'Baile e Comemoração dos Aniversariantes de Janeiro',
    year: 2027,
    month: 0,
    day: 29,
    time: '14:30 às 17:00',
    formattedDate: '29 de Janeiro de 2027 · Sexta-feira',
    category: 'comemorativo',
    categoryLabel: 'Datas Comemorativas',
    location: 'Refeitório Principal',
    audienceType: 'residentes_familias',
    audienceLabel: 'Moradores e Famílias',
    description:
      'Abertura festiva do novo ano para celebrar os aniversariantes do primeiro mês. Bolo temático, sanfona ao vivo e carinho redobrado de todos os voluntários.',
    objective:
      'Celebração da longevidade com respeito e alegria contagiante.',
    volunteerRole:
      'Apoio na mesa do bolo e animação carinhosa durante a tarde festiva.',
  },
];

interface EventsCalendarSectionProps {
  onOpenVisitModal: () => void;
  onOpenDonationModal: () => void;
}

export interface CategoryTheme {
  id: EventCategory;
  label: string;
  shortLabel: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  chipBg: string;
  chipBorder: string;
  chipHover: string;
  dotBg: string;
  accentBar: string;
  cardBorder: string;
  cardHoverBorder: string;
  activeBtnBg: string;
  textColor: string;
  icon: (cls?: string) => React.ReactNode;
}

export const CATEGORY_THEMES: Record<string, CategoryTheme> = {
  comemorativo: {
    id: 'comemorativo',
    label: 'Datas Comemorativas',
    shortLabel: 'Comemorativo',
    badgeBg: 'bg-purple-100 text-purple-800 border-purple-200',
    badgeText: 'text-purple-800',
    badgeBorder: 'border-purple-200',
    chipBg: 'bg-purple-50 text-purple-900 border-purple-200',
    chipBorder: 'border-purple-200',
    chipHover: 'hover:bg-purple-100 hover:border-purple-300',
    dotBg: 'bg-purple-500',
    accentBar: 'bg-purple-500',
    cardBorder: 'border-purple-200/80',
    cardHoverBorder: 'hover:border-purple-300 hover:shadow-purple-100/50',
    activeBtnBg: 'bg-purple-700 text-white shadow-2xs',
    textColor: 'text-purple-700',
    icon: (cls = 'w-3.5 h-3.5 text-purple-600') => <PartyPopper className={cls} />,
  },
  recreativo: {
    id: 'recreativo',
    label: 'Recreativo & Lúdico',
    shortLabel: 'Recreativo',
    badgeBg: 'bg-amber-100 text-amber-900 border-amber-200',
    badgeText: 'text-amber-900',
    badgeBorder: 'border-amber-200',
    chipBg: 'bg-amber-50 text-amber-950 border-amber-200',
    chipBorder: 'border-amber-200',
    chipHover: 'hover:bg-amber-100 hover:border-amber-300',
    dotBg: 'bg-amber-500',
    accentBar: 'bg-amber-500',
    cardBorder: 'border-amber-200/80',
    cardHoverBorder: 'hover:border-amber-300 hover:shadow-amber-100/50',
    activeBtnBg: 'bg-amber-600 text-white shadow-2xs',
    textColor: 'text-amber-800',
    icon: (cls = 'w-3.5 h-3.5 text-amber-600') => <Music className={cls} />,
  },
  social: {
    id: 'social',
    label: 'Social & Convivência',
    shortLabel: 'Social',
    badgeBg: 'bg-blue-100 text-blue-900 border-blue-200',
    badgeText: 'text-blue-900',
    badgeBorder: 'border-blue-200',
    chipBg: 'bg-blue-50 text-blue-950 border-blue-200',
    chipBorder: 'border-blue-200',
    chipHover: 'hover:bg-blue-100 hover:border-blue-300',
    dotBg: 'bg-blue-500',
    accentBar: 'bg-blue-500',
    cardBorder: 'border-blue-200/80',
    cardHoverBorder: 'hover:border-blue-300 hover:shadow-blue-100/50',
    activeBtnBg: 'bg-blue-600 text-white shadow-2xs',
    textColor: 'text-blue-700',
    icon: (cls = 'w-3.5 h-3.5 text-blue-600') => <Users className={cls} />,
  },
  espiritual: {
    id: 'espiritual',
    label: 'Espiritual & Reflexão',
    shortLabel: 'Espiritual',
    badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-200',
    badgeText: 'text-emerald-900',
    badgeBorder: 'border-emerald-200',
    chipBg: 'bg-emerald-50 text-emerald-950 border-emerald-200',
    chipBorder: 'border-emerald-200',
    chipHover: 'hover:bg-emerald-100 hover:border-emerald-300',
    dotBg: 'bg-emerald-500',
    accentBar: 'bg-emerald-500',
    cardBorder: 'border-emerald-200/80',
    cardHoverBorder: 'hover:border-emerald-300 hover:shadow-emerald-100/50',
    activeBtnBg: 'bg-emerald-700 text-white shadow-2xs',
    textColor: 'text-emerald-800',
    icon: (cls = 'w-3.5 h-3.5 text-emerald-600') => <Church className={cls} />,
  },
  saude: {
    id: 'saude',
    label: 'Saúde & Movimento',
    shortLabel: 'Saúde',
    badgeBg: 'bg-rose-100 text-rose-900 border-rose-200',
    badgeText: 'text-rose-900',
    badgeBorder: 'border-rose-200',
    chipBg: 'bg-rose-50 text-rose-950 border-rose-200',
    chipBorder: 'border-rose-200',
    chipHover: 'hover:bg-rose-100 hover:border-rose-300',
    dotBg: 'bg-rose-500',
    accentBar: 'bg-rose-500',
    cardBorder: 'border-rose-200/80',
    cardHoverBorder: 'hover:border-rose-300 hover:shadow-rose-100/50',
    activeBtnBg: 'bg-rose-600 text-white shadow-2xs',
    textColor: 'text-rose-700',
    icon: (cls = 'w-3.5 h-3.5 text-rose-600') => <Activity className={cls} />,
  },
};

const DEFAULT_THEME: CategoryTheme = {
  id: 'todos',
  label: 'Geral',
  shortLabel: 'Geral',
  badgeBg: 'bg-stone-100 text-stone-800 border-stone-200',
  badgeText: 'text-stone-800',
  badgeBorder: 'border-stone-200',
  chipBg: 'bg-stone-50 text-stone-900 border-stone-200',
  chipBorder: 'border-stone-200',
  chipHover: 'hover:bg-stone-100',
  dotBg: 'bg-stone-500',
  accentBar: 'bg-stone-400',
  cardBorder: 'border-stone-200',
  cardHoverBorder: 'hover:border-stone-300',
  activeBtnBg: 'bg-[#073B91] text-white shadow-2xs',
  textColor: 'text-stone-700',
  icon: (cls = 'w-3.5 h-3.5 text-stone-600') => <Sparkles className={cls} />,
};

export const getCategoryTheme = (category: string): CategoryTheme => {
  return CATEGORY_THEMES[category] || DEFAULT_THEME;
};

const MONTH_NAMES = [
  'Janeiro',
  'Fevereiro',
  'Março',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
];

const WEEKDAY_NAMES_SHORT = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

export const EventsCalendarSection: React.FC<EventsCalendarSectionProps> = ({
  onOpenVisitModal,
  onOpenDonationModal,
}) => {
  // Current view reference: October 2026 (Month 9) by default
  const [currentYear, setCurrentYear] = useState<number>(2026);
  const [currentMonth, setCurrentMonth] = useState<number>(9); // 9 = Outubro
  const [viewMode, setViewMode] = useState<'grid' | 'agenda'>('grid');
  const [selectedCategory, setSelectedCategory] = useState<EventCategory>('todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [activeModalEvent, setActiveModalEvent] = useState<CalendarEvent | null>(null);

  // Audio / Speech state
  const [isReadingEvent, setIsReadingEvent] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  const searchInputId = useId();

  // Navigation between months
  const handlePrevMonth = () => {
    setSelectedDay(null);
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((prev) => prev - 1);
    } else {
      setCurrentMonth((prev) => prev - 1);
    }
  };

  const handleNextMonth = () => {
    setSelectedDay(null);
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((prev) => prev + 1);
    } else {
      setCurrentMonth((prev) => prev + 1);
    }
  };

  const handleSelectQuickMonth = (year: number, month: number) => {
    setCurrentYear(year);
    setCurrentMonth(month);
    setSelectedDay(null);
  };

  // Filter events by selected month & year
  const monthEvents = CALENDAR_EVENTS.filter(
    (e) => e.year === currentYear && e.month === currentMonth
  );

  // Apply category and search filter
  const filteredEvents = monthEvents.filter((event) => {
    const matchesCategory =
      selectedCategory === 'todos' || event.category === selectedCategory;

    const matchesSearch =
      searchQuery.trim() === '' ||
      event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDay = selectedDay === null || event.day === selectedDay;

    return matchesCategory && matchesSearch && matchesDay;
  });

  const activitiesScrollRef = useRef<HTMLDivElement>(null);
  const [canScrollActLeft, setCanScrollActLeft] = useState(false);
  const [canScrollActRight, setCanScrollActRight] = useState(true);

  const checkActScroll = useCallback(() => {
    const el = activitiesScrollRef.current;
    if (!el) return;
    setCanScrollActLeft(el.scrollLeft > 10);
    setCanScrollActRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 10);
  }, []);

  useEffect(() => {
    const el = activitiesScrollRef.current;
    if (!el) return;
    checkActScroll();
    el.addEventListener('scroll', checkActScroll, { passive: true });
    window.addEventListener('resize', checkActScroll);
    return () => {
      el.removeEventListener('scroll', checkActScroll);
      window.removeEventListener('resize', checkActScroll);
    };
  }, [checkActScroll, filteredEvents]);

  const handleScrollActivities = (direction: 'left' | 'right') => {
    const el = activitiesScrollRef.current;
    if (!el) return;
    const scrollAmount = el.clientWidth > 640 ? 320 : 280;
    el.scrollBy({ left: direction === 'left' ? -scrollAmount : scrollAmount, behavior: 'smooth' });
  };

  // Events count by category in current month for filter badges
  const getCategoryCount = (cat: EventCategory) => {
    if (cat === 'todos') return monthEvents.length;
    return monthEvents.filter((e) => e.category === cat).length;
  };

  // Days calculation for the calendar grid
  const daysInCurrentMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayWeekday = new Date(currentYear, currentMonth, 1).getDay(); // 0 = Sun
  const daysInPrevMonth = new Date(currentYear, currentMonth, 0).getDate();

  // Total grid cells (leading days + current days)
  const calendarCells: Array<{
    dayNumber: number;
    isCurrentMonth: boolean;
    events: CalendarEvent[];
    isToday: boolean;
  }> = [];

  // Previous month trailing days
  for (let i = firstDayWeekday - 1; i >= 0; i--) {
    calendarCells.push({
      dayNumber: daysInPrevMonth - i,
      isCurrentMonth: false,
      events: [],
      isToday: false,
    });
  }

  // Current month days
  for (let d = 1; d <= daysInCurrentMonth; d++) {
    const dayEvts = monthEvents.filter((e) => e.day === d);
    const isToday = currentYear === 2026 && currentMonth === 9 && d === 13;
    calendarCells.push({
      dayNumber: d,
      isCurrentMonth: true,
      events: dayEvts,
      isToday,
    });
  }

  // Next month leading days to complete full rows (multiple of 7)
  const remainingCells = (7 - (calendarCells.length % 7)) % 7;
  for (let n = 1; n <= remainingCells; n++) {
    calendarCells.push({
      dayNumber: n,
      isCurrentMonth: false,
      events: [],
      isToday: false,
    });
  }

  // Generate Google Calendar Link
  const getGoogleCalendarUrl = (evt: CalendarEvent) => {
    const pad = (n: number) => n.toString().padStart(2, '0');
    const m = pad(evt.month + 1);
    const d = pad(evt.day);
    const startIso = `${evt.year}${m}${d}T140000Z`;
    const endIso = `${evt.year}${m}${d}T170000Z`;
    const text = encodeURIComponent(`${evt.title} - ${INSTITUTION_INFO.shortName}`);
    const details = encodeURIComponent(
      `${evt.description}\n\nLocal: ${evt.location}\nEndereço: ${INSTITUTION_INFO.address}, Juiz de Fora - MG\nTelefone: ${INSTITUTION_INFO.phone}\n${INSTITUTION_INFO.visitHours}`
    );
    const location = encodeURIComponent(
      `${evt.location}, ${INSTITUTION_INFO.name}, Juiz de Fora - MG`
    );
    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${text}&dates=${startIso}/${endIso}&details=${details}&location=${location}`;
  };

  // Generate and download .ICS file
  const handleDownloadIcs = (evt: CalendarEvent) => {
    const pad = (n: number) => n.toString().padStart(2, '0');
    const m = pad(evt.month + 1);
    const d = pad(evt.day);
    const startStr = `${evt.year}${m}${d}T140000Z`;
    const endStr = `${evt.year}${m}${d}T170000Z`;

    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Lar dos Idosos Santa Luiza de Marillac//Eventos//PT',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
      'BEGIN:VEVENT',
      `UID:${evt.id}@larluizademarillac.gmail.com`,
      `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0]}Z`,
      `DTSTART:${startStr}`,
      `DTEND:${endStr}`,
      `SUMMARY:${evt.title}`,
      `DESCRIPTION:${evt.description.replace(/\n/g, '\\n')} - Benefício: ${evt.objective}`,
      `LOCATION:${evt.location}\\, ${INSTITUTION_INFO.name}\\, Juiz de Fora - MG`,
      'STATUS:CONFIRMED',
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `${evt.id}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    notifySuccess(`Arquivo de calendário (.ics) baixado para "${evt.title}"!`);
  };

  // WhatsApp share
  const handleShareWhatsApp = (evt: CalendarEvent) => {
    const text = encodeURIComponent(
      `Confira esta atividade no Lar dos Idosos Santa Luiza de Marillac (Juiz de Fora - MG):\n\n📅 *${evt.title}*\n🗓️ Data: ${evt.formattedDate}\n⏰ Horário: ${evt.time}\n📍 Local: ${evt.location}\n\n${evt.description}\n\nSaiba mais no site institucional do Lar!`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  // Copy link
  const handleCopyLink = () => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(window.location.href);
      setCopySuccess(true);
      notifySuccess('Link do calendário de eventos copiado com sucesso!');
      setTimeout(() => setCopySuccess(false), 2500);
    }
  };

  // Read event narrative aloud via SpeechSynthesis
  const handleReadAloud = (evt: CalendarEvent) => {
    if (!('speechSynthesis' in window)) return;

    if (isReadingEvent) {
      window.speechSynthesis.cancel();
      setIsReadingEvent(false);
      return;
    }

    window.speechSynthesis.cancel();
    const text = `Atividade no Lar Santa Luiza de Marillac: ${evt.title}. Data: ${evt.formattedDate}. Horário: ${evt.time}. Local: ${evt.location}. Categoria: ${evt.categoryLabel}. Sobre o evento: ${evt.description}. Objetivo com os residentes: ${evt.objective}.`;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'pt-BR';
    utterance.rate = 0.95;

    utterance.onend = () => setIsReadingEvent(false);
    utterance.onerror = () => setIsReadingEvent(false);

    setIsReadingEvent(true);
    window.speechSynthesis.speak(utterance);
  };

  const stopReading = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsReadingEvent(false);
    }
  };

  // Quick navigation preset buttons
  const quickMonths = [
    { label: 'Outubro 2026', year: 2026, month: 9 },
    { label: 'Novembro 2026', year: 2026, month: 10 },
    { label: 'Dezembro 2026', year: 2026, month: 11 },
    { label: 'Janeiro 2027', year: 2027, month: 0 },
  ];

  return (
    <section
      id="calendario-eventos"
      className="py-16 sm:py-20 bg-gradient-to-b from-[#F4F8EE] via-white to-[#F4F8EE] border-t border-stone-200/80 scroll-mt-20"
      aria-label="Calendário de Atividades e Eventos do Lar"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* =========================================================================
            HEADER DA SEÇÃO: INSTITUCIONAL, COLORIDO & ACOLHEDOR
            ========================================================================= */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 pb-6 border-b border-stone-200">
          <div className="space-y-2.5 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/80 text-xs font-semibold text-[#073B91] font-body">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Programação & Convivência Comunitária</span>
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-[#27343B] tracking-tight leading-tight">
              Calendário de Atividades, Oficinas e Celebrações
            </h2>
            <p className="text-xs sm:text-sm text-[#66737A] font-body leading-relaxed max-w-2xl">
              Acompanhe as datas comemorativas, oficinas recreativas, vivências espirituais e projetos sociais que transformam o dia a dia dos nossos moradores em Juiz de Fora.
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={onOpenVisitModal}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-all shadow-2xs font-body cursor-pointer"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Agendar Visita / Participar</span>
            </button>
            <button
              type="button"
              onClick={onOpenDonationModal}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#27343B] bg-white border border-stone-200 hover:bg-stone-50 rounded-lg transition-all font-body cursor-pointer"
            >
              <Heart className="w-4 h-4 text-[#76A900]" />
              <span>Apoiar Atividades</span>
            </button>
          </div>
        </div>

        {/* =========================================================================
            BARRA DE CONTROLES: NAVEGAÇÃO DE MESES, FILTROS & MODOS DE VISUALIZAÇÃO
            ========================================================================= */}
        <div className="mt-6 space-y-4">
          {/* Quick Month Switcher Bar */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 p-2.5 bg-white rounded-2xl border border-stone-200/90 shadow-2xs">
            {/* Month Stepper */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrevMonth}
                aria-label="Mês anterior"
                className="p-1.5 text-stone-600 hover:text-[#073B91] hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <div className="px-3 py-0.5 text-center min-w-[150px]">
                <span className="font-heading font-bold text-base sm:text-lg text-[#27343B] block">
                  {MONTH_NAMES[currentMonth]} {currentYear}
                </span>
                <span className="text-[11px] text-stone-500 font-body">
                  {monthEvents.length} {monthEvents.length === 1 ? 'atividade' : 'atividades'}
                </span>
              </div>

              <button
                type="button"
                onClick={handleNextMonth}
                aria-label="Próximo mês"
                className="p-1.5 text-stone-600 hover:text-[#073B91] hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Presets */}
            <div className="hidden md:flex items-center gap-1.5 p-1 bg-stone-100/90 rounded-xl">
              {quickMonths.map((qm) => {
                const isActive = currentYear === qm.year && currentMonth === qm.month;
                return (
                  <button
                    key={`${qm.year}-${qm.month}`}
                    type="button"
                    onClick={() => handleSelectQuickMonth(qm.year, qm.month)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                      isActive
                        ? 'bg-white text-[#073B91] shadow-2xs font-semibold'
                        : 'text-stone-600 hover:text-stone-900 hover:bg-white/60'
                    }`}
                  >
                    {qm.label}
                  </button>
                );
              })}
            </div>

            {/* Mode Toggle: Grid vs Agenda */}
            <div className="flex items-center justify-between lg:justify-end gap-3 pt-2 lg:pt-0 border-t lg:border-t-0 border-stone-100">
              <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setViewMode('grid')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                    viewMode === 'grid'
                      ? 'bg-white text-[#073B91] shadow-2xs font-semibold'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                  <span>Grade Mensal</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('agenda')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                    viewMode === 'agenda'
                      ? 'bg-white text-[#073B91] shadow-2xs font-semibold'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <List className="w-3.5 h-3.5" />
                  <span>Lista Cronológica</span>
                </button>
              </div>

              {selectedDay !== null && (
                <button
                  type="button"
                  onClick={() => setSelectedDay(null)}
                  className="px-2.5 py-1 text-xs text-[#073B91] hover:underline font-medium cursor-pointer"
                >
                  Ver todos os dias
                </button>
              )}
            </div>
          </div>

          {/* Category Tabs & Quick Search */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Category Segmented Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {(
                [
                  { id: 'todos', label: 'Todos os Eventos' },
                  { id: 'comemorativo', label: 'Datas Comemorativas' },
                  { id: 'recreativo', label: 'Recreativo & Lúdico' },
                  { id: 'social', label: 'Social & Convivência' },
                  { id: 'espiritual', label: 'Espiritual & Reflexão' },
                  { id: 'saude', label: 'Saúde & Movimento' },
                ] as Array<{ id: EventCategory; label: string }>
              ).map((cat) => {
                const count = getCategoryCount(cat.id);
                const isActive = selectedCategory === cat.id;
                const catTheme = CATEGORY_THEMES[cat.id];

                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setSelectedCategory(cat.id);
                      setSelectedDay(null);
                    }}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                      isActive
                        ? catTheme ? catTheme.activeBtnBg : 'bg-[#073B91] text-white shadow-2xs'
                        : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    {!isActive && catTheme && (
                      <span className={`w-2 h-2 rounded-full ${catTheme.dotBg}`} />
                    )}
                    <span>{cat.label}</span>
                    <span
                      className={`text-[11px] px-1.5 py-0.2 rounded font-mono ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-stone-100 text-stone-500'
                      }`}
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* In-section Search Bar */}
            <div className="relative min-w-[210px]">
              <label htmlFor={searchInputId} className="sr-only">
                Buscar atividades no calendário
              </label>
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id={searchInputId}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por termo ou local..."
                className="w-full pl-9 pr-8 py-1.5 bg-white border border-stone-200 rounded-lg text-xs text-[#27343B] placeholder-stone-400 focus:outline-hidden focus:border-[#073B91] focus:ring-1 focus:ring-[#073B91] transition-all font-body"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  aria-label="Limpar busca"
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* =========================================================================
              LEGENDA DE CORES DO CALENDÁRIO (VIBRANTE & INTUITIVA)
              ========================================================================= */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-4 py-2 px-3.5 bg-white rounded-xl border border-stone-200/80 text-xs shadow-2xs">
            <span className="font-semibold text-stone-700 flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Categorias:
            </span>
            {Object.values(CATEGORY_THEMES).map((cat) => (
              <div
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(selectedCategory === cat.id ? 'todos' : cat.id);
                  setSelectedDay(null);
                }}
                className={`flex items-center gap-1.5 text-[11px] font-medium px-2 py-0.5 rounded-md cursor-pointer transition-colors ${
                  selectedCategory === cat.id
                    ? `${cat.badgeBg} font-semibold ring-1 ring-inset`
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50'
                }`}
                title={`Filtrar por ${cat.label}`}
              >
                <span className={`w-2.5 h-2.5 rounded-full ${cat.dotBg} shadow-2xs shrink-0`} />
                <span>{cat.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* =========================================================================
            AVISO DE DIA SELECIONADO (FILTRO ATIVO)
            ========================================================================= */}
        {selectedDay !== null && (
          <div className="mt-4 p-3 bg-blue-50/90 border border-blue-200 rounded-xl flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-[#073B91] font-body">
              <Info className="w-4 h-4 text-[#073B91] shrink-0" />
              <span>
                Exibindo atividades agendadas para o dia{' '}
                <strong className="font-semibold">
                  {selectedDay} de {MONTH_NAMES[currentMonth]} de {currentYear}
                </strong>
                .
              </span>
            </div>
            <button
              type="button"
              onClick={() => setSelectedDay(null)}
              className="text-xs font-semibold text-[#073B91] hover:underline whitespace-nowrap cursor-pointer"
            >
              Limpar filtro de dia
            </button>
          </div>
        )}

        {/* =========================================================================
            VISÃO 1: GRADE MENSAL INTERATIVA COLORIDA (GRID VIEW)
            ========================================================================= */}
        {viewMode === 'grid' && (
          <div className="mt-5 bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden">
            {/* Weekday headers com cores suaves */}
            <div className="grid grid-cols-7 border-b border-stone-200 text-center font-heading">
              {WEEKDAY_NAMES_SHORT.map((wd, idx) => {
                const isWeekend = idx === 0 || idx === 6;
                return (
                  <div
                    key={wd}
                    className={`py-2 text-xs font-semibold tracking-wide ${
                      isWeekend
                        ? 'bg-amber-50/80 text-amber-800'
                        : 'bg-stone-50/90 text-stone-700'
                    }`}
                  >
                    {wd}
                  </div>
                );
              })}
            </div>

            {/* Days cells grid com estilização colorida e dinâmica */}
            <div className="grid grid-cols-7 auto-rows-fr divide-x divide-y divide-stone-100">
              {calendarCells.map((cell, idx) => {
                const hasEvents = cell.events.length > 0;
                const isSelected = selectedDay === cell.dayNumber && cell.isCurrentMonth;

                // Unique categories in this cell for color dot badges
                const cellCategories = Array.from(
                  new Set(cell.events.map((e) => e.category))
                );

                return (
                  <div
                    key={`${cell.dayNumber}-${idx}`}
                    onClick={() => {
                      if (cell.isCurrentMonth && hasEvents) {
                        setSelectedDay(selectedDay === cell.dayNumber ? null : cell.dayNumber);
                      }
                    }}
                    className={`min-h-[92px] sm:min-h-[112px] p-1.5 transition-all flex flex-col justify-between ${
                      !cell.isCurrentMonth
                        ? 'bg-stone-50/40 text-stone-300'
                        : isSelected
                        ? 'bg-blue-50/80 ring-2 ring-[#073B91] ring-inset'
                        : cell.isToday
                        ? 'bg-blue-50/30 border-blue-200 ring-1 ring-blue-300/60'
                        : hasEvents
                        ? 'bg-white hover:bg-stone-50/70'
                        : 'bg-white hover:bg-stone-50/40'
                    } ${
                      cell.isCurrentMonth && hasEvents
                        ? 'cursor-pointer hover:shadow-inner'
                        : 'cursor-default'
                    }`}
                  >
                    {/* Day number & category indicator dots */}
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-xs font-semibold font-mono ${
                            !cell.isCurrentMonth
                              ? 'text-stone-300'
                              : cell.isToday
                              ? 'px-2 py-0.5 rounded-full bg-gradient-to-r from-[#073B91] to-blue-600 text-white font-bold text-[11px] shadow-2xs'
                              : isSelected
                              ? 'text-[#073B91] font-bold text-sm'
                              : 'text-stone-700'
                          }`}
                        >
                          {cell.dayNumber}
                        </span>

                        {/* Category dots on active days */}
                        {cell.isCurrentMonth && cellCategories.length > 0 && !cell.isToday && (
                          <div className="flex items-center gap-0.5">
                            {cellCategories.map((catKey) => {
                              const theme = CATEGORY_THEMES[catKey];
                              return theme ? (
                                <span
                                  key={catKey}
                                  className={`w-1.5 h-1.5 rounded-full ${theme.dotBg}`}
                                  title={theme.label}
                                />
                              ) : null;
                            })}
                          </div>
                        )}
                      </div>

                      {cell.isToday && (
                        <span className="hidden sm:inline-block text-[9px] text-[#073B91] font-bold uppercase tracking-wider bg-blue-100/90 px-1.5 py-0.2 rounded">
                          Hoje
                        </span>
                      )}
                    </div>

                    {/* Events indicators inside the cell with category colors */}
                    {cell.isCurrentMonth && hasEvents && (
                      <div className="space-y-1 my-0.5">
                        {cell.events.slice(0, 2).map((evt) => {
                          const catTheme = getCategoryTheme(evt.category);
                          return (
                            <button
                              key={evt.id}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveModalEvent(evt);
                              }}
                              className={`w-full text-left p-1 sm:p-1.5 rounded-md border text-xs transition-all cursor-pointer group shadow-2xs ${catTheme.chipBg} ${catTheme.chipBorder} ${catTheme.chipHover}`}
                            >
                              <div className="flex items-center gap-1">
                                <span className="shrink-0">{catTheme.icon('w-3 h-3 ' + catTheme.textColor)}</span>
                                <span className="text-[11px] font-semibold truncate block leading-tight text-stone-900 group-hover:underline">
                                  {evt.title}
                                </span>
                              </div>
                              <div className="flex items-center justify-between mt-0.5 text-[10px] text-stone-500 font-mono">
                                <span>{evt.time.split(' ')[0]}</span>
                                <span className={`hidden sm:inline-block font-sans text-[9px] font-semibold px-1 py-0.2 rounded-xs ${catTheme.badgeBg}`}>
                                  {catTheme.shortLabel}
                                </span>
                              </div>
                            </button>
                          );
                        })}

                        {cell.events.length > 2 && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedDay(cell.dayNumber);
                            }}
                            className="w-full text-[10px] text-[#073B91] font-semibold hover:underline block text-center py-0.5 bg-blue-50/70 rounded border border-blue-100"
                          >
                            +{cell.events.length - 2} mais
                          </button>
                        )}
                      </div>
                    )}

                    {/* Empty cell spacer */}
                    {!hasEvents && <div />}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================================
            VISÃO 2: LISTA CRONOLÓGICA COMPACTA (QUANDO viewMode === 'agenda')
            ========================================================================= */}
        {viewMode === 'agenda' && (
          <div className="mt-5 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-stone-200">
              <h3 className="font-heading text-base sm:text-lg font-bold text-[#27343B]">
                {selectedDay !== null
                  ? `Atividades para ${selectedDay} de ${MONTH_NAMES[currentMonth]}`
                  : `Agenda Cronológica de ${MONTH_NAMES[currentMonth]} de ${currentYear}`}
              </h3>
              <span className="text-xs text-stone-500 font-body">
                {filteredEvents.length} {filteredEvents.length === 1 ? 'evento encontrado' : 'eventos encontrados'}
              </span>
            </div>

            {filteredEvents.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-xl border border-stone-200 space-y-3">
                <CalendarIcon className="w-8 h-8 text-stone-300 mx-auto" />
                <p className="text-sm font-semibold text-[#27343B]">Nenhum evento com os filtros selecionados</p>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('todos');
                    setSearchQuery('');
                    setSelectedDay(null);
                  }}
                  className="px-3.5 py-1.5 text-xs font-semibold text-[#073B91] bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
                >
                  Limpar todos os filtros
                </button>
              </div>
            ) : (
              /* AGENDA CRONOLÓGICA: CARDS MENORES E COMPACTOS */
              <div className="space-y-2">
                {filteredEvents.map((evt) => {
                  const catTheme = getCategoryTheme(evt.category);
                  return (
                    <div
                      key={evt.id}
                      className={`bg-white rounded-xl border p-2.5 sm:p-3 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 hover:shadow-xs ${catTheme.cardBorder} hover:border-[#073B91]/40 relative overflow-hidden group`}
                    >
                      {/* Left category accent bar (3px) */}
                      <div className={`hidden sm:block w-1 self-stretch rounded-full ${catTheme.accentBar}`} />

                      {/* Date Badge & Main Info */}
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        {/* Compact Date Box */}
                        <div className="w-10 h-10 rounded-lg bg-stone-50 border border-stone-200/80 flex flex-col items-center justify-center text-center shrink-0">
                          <span className="text-[9px] font-bold text-stone-500 uppercase tracking-wider font-body leading-none">
                            {evt.formattedDate.split('·')[1]?.trim().slice(0, 3) || 'Dia'}
                          </span>
                          <span className="text-sm font-bold text-[#073B91] font-mono leading-tight">
                            {evt.day}
                          </span>
                        </div>

                        {/* Event Details */}
                        <div className="min-w-0 flex-1 space-y-0.5">
                          <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
                            <span className={`inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full font-semibold ${catTheme.badgeBg}`}>
                              {catTheme.icon('w-2.5 h-2.5')}
                              <span>{evt.categoryLabel}</span>
                            </span>
                            <span className="flex items-center gap-1 text-stone-600 font-mono">
                              <Clock className="w-2.5 h-2.5 text-stone-400" />
                              {evt.time.split(' ')[0]}
                            </span>
                            <span className="hidden md:flex items-center gap-1 text-stone-500 truncate">
                              <MapPin className="w-2.5 h-2.5 text-stone-400 shrink-0" />
                              <span className="truncate max-w-[180px]">{evt.location}</span>
                            </span>
                          </div>

                          <h4
                            onClick={() => setActiveModalEvent(evt)}
                            className="font-heading font-bold text-xs sm:text-sm text-stone-900 truncate group-hover:text-[#073B91] transition-colors cursor-pointer"
                          >
                            {evt.title}
                          </h4>

                          <p className="text-[11px] text-[#66737A] font-body truncate leading-tight">
                            {evt.description}
                          </p>
                        </div>
                      </div>

                      {/* Compact Quick Actions */}
                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center pt-1.5 sm:pt-0 border-t sm:border-t-0 border-stone-100 w-full sm:w-auto justify-between sm:justify-end">
                        <button
                          type="button"
                          onClick={() => setActiveModalEvent(evt)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-[#073B91] bg-blue-50 hover:bg-blue-100 rounded-md transition-colors cursor-pointer"
                        >
                          <span>Detalhes</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>

                        <div className="flex items-center gap-0.5">
                          <button
                            type="button"
                            onClick={() => handleDownloadIcs(evt)}
                            title="Baixar evento (.ics)"
                            className="p-1 text-stone-400 hover:text-[#073B91] hover:bg-stone-100 rounded transition-colors cursor-pointer"
                          >
                            <CalendarPlus className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleShareWhatsApp(evt)}
                            title="Compartilhar no WhatsApp"
                            className="p-1 text-stone-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
            VISÃO EM CARDS: FILEIRA ÚNICA COM SETINHAS LADO A LADO (SEM DESESTRUTURAR)
            ========================================================================= */}
        {viewMode === 'grid' && (
          <div className="mt-8 space-y-3">
            {/* Header com Controles de Navegação (Setinhas) */}
            <div className="flex items-center justify-between pb-2 border-b border-stone-200">
              <div>
                <h3 className="font-heading text-base sm:text-lg font-bold text-[#27343B]">
                  {selectedDay !== null
                    ? `Atividades para ${selectedDay} de ${MONTH_NAMES[currentMonth]}`
                    : `Atividades em Destaque de ${MONTH_NAMES[currentMonth]}`}
                </h3>
                <p className="text-[11px] text-[#66737A] font-body">
                  Fileira única · Use as setinhas para navegar entre todas as atividades
                </p>
              </div>

              {/* Setinhas de Navegação no Cabeçalho */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-stone-500 font-body hidden sm:inline mr-1">
                  {filteredEvents.length} {filteredEvents.length === 1 ? 'atividade' : 'atividades'}
                </span>
                <button
                  type="button"
                  onClick={() => handleScrollActivities('left')}
                  disabled={!canScrollActLeft}
                  className="p-2 rounded-full bg-white border border-stone-200 text-stone-700 hover:text-[#073B91] hover:border-[#073B91] hover:shadow-xs disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer shadow-2xs active:scale-95"
                  aria-label="Atividades anteriores à esquerda"
                  title="Atividades anteriores"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleScrollActivities('right')}
                  disabled={!canScrollActRight}
                  className="p-2 rounded-full bg-white border border-stone-200 text-stone-700 hover:text-[#073B91] hover:border-[#073B91] hover:shadow-xs disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer shadow-2xs active:scale-95"
                  aria-label="Próximas atividades à direita"
                  title="Próximas atividades"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {filteredEvents.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-xl border border-stone-200 space-y-2">
                <CalendarIcon className="w-8 h-8 text-stone-300 mx-auto" />
                <p className="font-heading font-semibold text-sm text-[#27343B]">
                  Nenhum evento com os filtros selecionados
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('todos');
                    setSearchQuery('');
                    setSelectedDay(null);
                  }}
                  className="px-3.5 py-1.5 text-xs font-semibold text-[#073B91] bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
                >
                  Limpar todos os filtros
                </button>
              </div>
            ) : (
              /* FILEIRA ÚNICA COM SETINHAS LADO A LADO E SNAP SCROLL */
              <div className="relative group/activities">
                {/* Botão Flutuante Esquerdo (Desktop) */}
                {canScrollActLeft && (
                  <button
                    type="button"
                    onClick={() => handleScrollActivities('left')}
                    className="hidden lg:flex absolute -left-3.5 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/95 border border-stone-200 text-[#073B91] shadow-md items-center justify-center hover:bg-white hover:scale-105 active:scale-95 transition-all cursor-pointer"
                    aria-label="Rolar para esquerda"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                )}

                {/* Botão Flutuante Direito (Desktop) */}
                {canScrollActRight && (
                  <button
                    type="button"
                    onClick={() => handleScrollActivities('right')}
                    className="hidden lg:flex absolute -right-3.5 top-1/2 -translate-y-1/2 z-20 w-9 h-9 rounded-full bg-white/95 border border-stone-200 text-[#073B91] shadow-md items-center justify-center hover:bg-white hover:scale-105 active:scale-95 transition-all cursor-pointer"
                    aria-label="Rolar para direita"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}

                <div
                  ref={activitiesScrollRef}
                  className="flex gap-3.5 overflow-x-auto scroll-smooth snap-x snap-mandatory py-2 px-1 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
                >
                  {filteredEvents.map((evt) => {
                    const catTheme = getCategoryTheme(evt.category);
                    return (
                      <div
                        key={evt.id}
                        className={`w-[260px] sm:w-[285px] md:w-[305px] shrink-0 snap-start bg-white rounded-xl border transition-all p-3 sm:p-3.5 flex flex-col justify-between hover:shadow-md hover:-translate-y-0.5 relative overflow-hidden group ${catTheme.cardBorder} ${catTheme.cardHoverBorder}`}
                      >
                        {/* Top colored category bar (3px) */}
                        <div className={`h-1 w-full absolute top-0 left-0 ${catTheme.accentBar}`} />

                        <div className="space-y-2 pt-0.5">
                          {/* Header: Category Badge + Time Badge */}
                          <div className="flex items-center justify-between gap-1.5">
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${catTheme.badgeBg}`}>
                              {catTheme.icon('w-3 h-3')}
                              <span>{evt.categoryLabel}</span>
                            </span>

                            <span className="inline-flex items-center gap-1 text-[10px] font-mono font-medium text-stone-600 bg-stone-100/90 px-1.5 py-0.5 rounded">
                              <Clock className="w-3 h-3 text-stone-400" />
                              {evt.time.split(' ')[0]}
                            </span>
                          </div>

                          {/* Date line */}
                          <div className="text-[11px] font-semibold text-stone-700 flex items-center gap-1 font-body">
                            <CalendarIcon className="w-3 h-3 text-[#073B91] shrink-0" />
                            <span>{evt.formattedDate.split('·')[0]}</span>
                          </div>

                          {/* Title */}
                          <h4
                            onClick={() => setActiveModalEvent(evt)}
                            className="font-heading font-bold text-xs sm:text-sm text-stone-900 leading-snug line-clamp-2 group-hover:text-[#073B91] transition-colors cursor-pointer"
                          >
                            {evt.title}
                          </h4>

                          {/* Location */}
                          <div className="flex items-center gap-1 text-[11px] text-stone-500 truncate font-body">
                            <MapPin className="w-3 h-3 text-stone-400 shrink-0" />
                            <span className="truncate">{evt.location}</span>
                          </div>

                          {/* Short Description */}
                          <p className="text-[11px] text-[#66737A] font-body leading-relaxed line-clamp-2">
                            {evt.description}
                          </p>

                          {/* Compact Objective Tag */}
                          <div className="text-[10px] text-stone-600 bg-stone-50/90 px-2 py-1 rounded-md border border-stone-200/60 truncate font-body">
                            <span className="font-semibold text-stone-800">Objetivo:</span> {evt.objective}
                          </div>
                        </div>

                        {/* Card Compact Footer Actions */}
                        <div className="pt-2 mt-2 border-t border-stone-100 flex items-center justify-between gap-1">
                          <button
                            type="button"
                            onClick={() => setActiveModalEvent(evt)}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-[#073B91] hover:text-[#052c6e] hover:underline cursor-pointer"
                          >
                            <span>Ver detalhes</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>

                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleDownloadIcs(evt)}
                              title="Baixar evento (.ics)"
                              className="p-1 text-stone-400 hover:text-[#073B91] hover:bg-stone-100 rounded transition-colors cursor-pointer"
                            >
                              <CalendarPlus className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleShareWhatsApp(evt)}
                              title="Compartilhar no WhatsApp"
                              className="p-1 text-stone-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                            >
                              <Share2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
            BANNER INFORMATIVO INSTITUCIONAL: VISITAS E VOLUNTARIADO
            ========================================================================= */}
        <div className="mt-10 bg-white rounded-2xl border border-stone-200 p-5 sm:p-6 shadow-2xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
            <div className="lg:col-span-8 space-y-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#073B91] font-body block">
                Participação Consciente & Cuidado Gerontológico
              </span>
              <h3 className="font-heading font-bold text-lg sm:text-xl text-[#27343B]">
                Quer realizar uma atividade voluntária ou levar música ao Lar?
              </h3>
              <p className="text-xs text-[#66737A] font-body leading-relaxed">
                Toda atividade externa em conjunto com os residentes é previamente alinhada com nossa equipe técnica de assistência social, psicologia e enfermagem, preservando o repouso dos 42 idosos e a segurança do Lar.
              </p>
            </div>

            <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-2.5 justify-center">
              <button
                type="button"
                onClick={onOpenVisitModal}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-colors shadow-2xs font-body cursor-pointer"
              >
                <CalendarCheck className="w-4 h-4" />
                <span>Propor Atividade / Agendar</span>
              </button>
              <button
                type="button"
                onClick={onOpenDonationModal}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#27343B] bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors font-body cursor-pointer"
              >
                <Heart className="w-4 h-4 text-[#76A900]" />
                <span>Doar Materiais para as Oficinas</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          MODAL DE DETALHES COMPLETOS DO EVENTO SELECIONADO
          ========================================================================= */}
      {activeModalEvent && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-event-title"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => {
            stopReading();
            setActiveModalEvent(null);
          }}
        >
          <div
            className="bg-white rounded-3xl max-w-2xl w-full border border-stone-200 shadow-2xl p-6 sm:p-8 space-y-6 relative my-8"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={() => {
                stopReading();
                setActiveModalEvent(null);
              }}
              aria-label="Fechar modal de detalhes do evento"
              className="absolute top-5 right-5 p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header & Category */}
            <div className="space-y-3 pr-10">
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#66737A] font-body">
                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-semibold ${getCategoryTheme(activeModalEvent.category).badgeBg}`}>
                  {getCategoryTheme(activeModalEvent.category).icon('w-3.5 h-3.5')}
                  <span>{activeModalEvent.categoryLabel}</span>
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-stone-700 font-medium">
                  {activeModalEvent.time}
                </span>
                <span aria-hidden="true">·</span>
                <span>{activeModalEvent.formattedDate}</span>
              </div>

              <h3
                id="modal-event-title"
                className="font-heading font-bold text-xl sm:text-2xl text-[#27343B] leading-snug"
              >
                {activeModalEvent.title}
              </h3>

              {/* TTS Listen Button */}
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => handleReadAloud(activeModalEvent)}
                  className={`inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    isReadingEvent
                      ? 'bg-amber-100 text-amber-900 ring-1 ring-amber-300'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                  }`}
                >
                  {isReadingEvent ? (
                    <>
                      <VolumeX className="w-4 h-4 text-amber-800" />
                      <span>Parar Audiodescrição</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4 text-stone-600" />
                      <span>Ouvir resumo em áudio</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Event Key Coordinates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 bg-stone-50 rounded-2xl border border-stone-200/80 text-xs text-stone-700 font-body">
              <div className="space-y-1">
                <span className="text-[11px] text-stone-500 font-medium block">
                  Local no Lar:
                </span>
                <div className="flex items-center gap-1.5 font-semibold text-[#27343B]">
                  <MapPin className="w-4 h-4 text-[#073B91] shrink-0" />
                  <span>{activeModalEvent.location}</span>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[11px] text-stone-500 font-medium block">
                  Público Participante:
                </span>
                <div className="flex items-center gap-1.5 font-semibold text-[#27343B]">
                  <Users className="w-4 h-4 text-[#073B91] shrink-0" />
                  <span>{activeModalEvent.audienceLabel}</span>
                </div>
              </div>
            </div>

            {/* Detailed Description */}
            <div className="space-y-4 text-sm text-[#27343B] font-body leading-relaxed">
              <div>
                <h4 className="font-semibold text-xs uppercase tracking-wider text-stone-500 mb-1.5">
                  Sobre a Atividade
                </h4>
                <p className="text-stone-700">{activeModalEvent.description}</p>
              </div>

              <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100 space-y-1.5">
                <h4 className="font-semibold text-xs text-[#073B91] uppercase tracking-wider">
                  Benefício Gerontológico & Social
                </h4>
                <p className="text-xs text-stone-700 leading-relaxed">
                  {activeModalEvent.objective}
                </p>
              </div>

              {activeModalEvent.volunteerRole && (
                <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-100 space-y-1.5">
                  <h4 className="font-semibold text-xs text-amber-900 uppercase tracking-wider">
                    Como o Voluntário Pode Atuar Nesta Atividade
                  </h4>
                  <p className="text-xs text-stone-700 leading-relaxed">
                    {activeModalEvent.volunteerRole}
                  </p>
                </div>
              )}
            </div>

            {/* Export & Calendar Integration */}
            <div className="pt-2 flex flex-wrap items-center gap-2 border-t border-stone-200">
              <a
                href={getGoogleCalendarUrl(activeModalEvent)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#073B91] bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors font-body"
              >
                <CalendarPlus className="w-3.5 h-3.5" />
                <span>Salvar no Google Agenda</span>
              </a>

              <button
                type="button"
                onClick={() => handleDownloadIcs(activeModalEvent)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors font-body cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Baixar arquivo .ICS</span>
              </button>

              <button
                type="button"
                onClick={() => handleShareWhatsApp(activeModalEvent)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors font-body cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Compartilhar</span>
              </button>

              <button
                type="button"
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 rounded-lg transition-colors font-body cursor-pointer ml-auto"
              >
                {copySuccess ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700">Link copiado!</span>
                  </>
                ) : (
                  <span>Copiar link</span>
                )}
              </button>
            </div>

            {/* Primary Action Buttons */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  setActiveModalEvent(null);
                  onOpenVisitModal();
                }}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-xl transition-colors shadow-2xs font-body cursor-pointer"
              >
                <CalendarCheck className="w-4 h-4" />
                <span>Agendar Presença neste Evento</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveModalEvent(null);
                  onOpenDonationModal();
                }}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold text-[#27343B] bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors font-body cursor-pointer"
              >
                <Heart className="w-4 h-4 text-[#76A900]" />
                <span>Fazer Doação para esta Atividade</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
