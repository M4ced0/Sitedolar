import React, { useEffect } from 'react';
import { X, ShieldCheck, Lock, FileText } from 'lucide-react';
import { INSTITUTION_INFO } from '../../data/institutionalData';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="privacy-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-[#F5F8F0]">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-[#76A900]/20 rounded-lg text-[#073B91]">
              <ShieldCheck className="w-5 h-5 text-[#073B91]" />
            </span>
            <div>
              <h2 id="privacy-modal-title" className="text-base sm:text-lg font-heading font-bold text-[#073B91]">
                Política de Privacidade & Proteção de Dados
              </h2>
              <p className="text-xs text-stone-500">
                Conformidade com a Lei Geral de Proteção de Dados (LGPD - Lei nº 13.709/2018)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-500 hover:text-stone-800 hover:bg-stone-200/50 transition-colors"
            aria-label="Fechar janela de política de privacidade"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed">
          <section className="space-y-2">
            <h3 className="font-semibold text-stone-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#76A900]" />
              1. Compromisso Institucional
            </h3>
            <p>
              O <strong>{INSTITUTION_INFO.name}</strong>, como Instituição de Longa Permanência para Idosos (ILPI) filantrópica em Juiz de Fora - MG, assume o compromisso de proteger a privacidade e os dados pessoais de todos os cidadãos, doadores, voluntários e visitantes que utilizam este portal institucional.
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="font-semibold text-stone-900 flex items-center gap-2">
              <Lock className="w-4 h-4 text-[#76A900]" />
              2. Coleta e Finalidade dos Dados
            </h3>
            <p>
              Os dados solicitados nos formulários institucionais (como nome, e-mail e telefone) são coletados exclusivamente para as seguintes finalidades legítimas:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-stone-600">
              <li>Responder a solicitações de informações, dúvidas e mensagens enviadas pelo canal Fale Conosco.</li>
              <li>Coordenar a logística de recebimento de doações registradas na iniciativa Corrente do Bem.</li>
              <li>Agendar previamente visitas e atender aos protocolos de acolhimento e segurança dos residentes.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h3 className="font-semibold text-stone-900">3. Não Compartilhamento com Terceiros</h3>
            <p>
              O Lar Santa Luiza de Marillac <strong>nunca comercializa, aluga ou compartilha</strong> informações pessoais fornecidas com empresas ou terceiros para fins de marketing comercial. Todos os dados permanecem sob sigilo institucional estrito.
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="font-semibold text-stone-900">4. Direitos do Titular de Dados</h3>
            <p>
              Em conformidade com a LGPD, todo titular de dados tem o direito de solicitar a qualquer momento a confirmação, o acesso, a correção ou a exclusão dos seus dados mantidos em nossos registros de contato, através do e-mail <strong>{INSTITUTION_INFO.email}</strong>.
            </p>
          </section>

          <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 text-xs text-stone-500">
            Última atualização: Outubro de 2026. Documento em conformidade com as diretrizes do Conselho Nacional de Assistência Social e LGPD.
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-stone-50 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs sm:text-sm font-medium text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-colors"
          >
            Entendi e concordo
          </button>
        </div>
      </div>
    </div>
  );
};
