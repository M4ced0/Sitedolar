import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Search, X, ArrowRight, FileText, Heart, Calendar, HelpCircle, Building } from 'lucide-react';
import { PageRoute } from '../../types';
import { DEMO_NEEDS, TRANSPARENCY_DOCUMENTS, SERVICE_DIFFERENTIALS, INSTITUTION_INFO } from '../../data/institutionalData';

interface SearchResultItem {
  id: string;
  title: string;
  description: string;
  page: PageRoute;
  category: 'Página' | 'Cuidado e Rotina' | 'Corrente do Bem' | 'Transparência' | 'Informação';
  iconType: 'page' | 'care' | 'need' | 'doc' | 'info';
}

interface CentralSearchBarProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: () => void;
  onOpenVisitModal: () => void;
}

export const CentralSearchBar: React.FC<CentralSearchBarProps> = ({
  onNavigate,
  onOpenDonationModal,
  onOpenVisitModal,
}) => {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Keyboard shortcut Ctrl+K / Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
      } else if (e.key === 'Escape') {
        setQuery('');
        inputRef.current?.blur();
        setIsFocused(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Click outside to close results dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Institutional Search Index
  const searchIndex: SearchResultItem[] = useMemo(() => {
    const items: SearchResultItem[] = [
      // Main Pages
      {
        id: 'page-home',
        title: 'Início (Página Inicial)',
        description: 'Apresentação geral do Lar, acolhimento humanizado, diferenciais e destaques.',
        page: 'home',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'page-sobre',
        title: 'Sobre Nós & Princípios da ILPI',
        description: 'Missão, visão, valores, esclarecimento sobre acolhimento residencial e estrutura.',
        page: 'sobre',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'page-historia',
        title: 'Nossa História (Mais de 50 Anos)',
        description: 'Trajetória histórica, fundação vicentina em Juiz de Fora e linha do tempo de dedicação.',
        page: 'nossa-historia',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'page-corrente',
        title: 'Corrente do Bem & Como Doar',
        description: 'Doações via PIX, lista de necessidades em tempo real, itens prioritários e voluntariado.',
        page: 'corrente-do-bem',
        category: 'Corrente do Bem',
        iconType: 'need',
      },
      {
        id: 'page-transparencia',
        title: 'Transparência & Prestação de Contas',
        description: 'Balanços anuais auditados, certificados do Lar (CEBAS, CMAS) e relatórios oficiais.',
        page: 'transparencia',
        category: 'Transparência',
        iconType: 'doc',
      },
      {
        id: 'transparencia-impacto-graficos',
        title: 'Transparência de Impacto (Gráficos de Pizza & Barras)',
        description: 'Distribuição visual dos investimentos e gastos da instituição com gráficos interativos de saúde, alimentação e enfermagem.',
        page: 'transparencia',
        category: 'Transparência',
        iconType: 'doc',
      },
      {
        id: 'page-contato',
        title: 'Contato & Localização em Juiz de Fora',
        description: 'Endereço, telefones, agendamento de visitas, canais de atendimento e mapa.',
        page: 'contato',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'home-depoimentos-familiares',
        title: 'Depoimentos de Familiares dos Residentes',
        description: 'Carrossel interativo com relatos reais, fotos e nomes de filhas, filhos e netos de moradores.',
        page: 'home',
        category: 'Página',
        iconType: 'page',
      },
      // Services and Care
      ...SERVICE_DIFFERENTIALS.map((diff) => ({
        id: `care-${diff.id}`,
        title: diff.title,
        description: diff.description,
        page: 'sobre' as PageRoute,
        category: 'Cuidado e Rotina' as const,
        iconType: 'care' as const,
      })),
      // Needs items
      ...DEMO_NEEDS.map((need) => ({
        id: `need-${need.id}`,
        title: need.name,
        description: `${need.description} (Categoria: ${need.categoryLabel} · Meta: ${need.quantityNeeded} ${need.unit})`,
        page: 'corrente-do-bem' as PageRoute,
        category: 'Corrente do Bem' as const,
        iconType: 'need' as const,
      })),
      // Transparency Documents
      ...TRANSPARENCY_DOCUMENTS.map((doc) => ({
        id: `doc-${doc.id}`,
        title: doc.title,
        description: `${doc.summary} (Exercício: ${doc.year} · ${doc.fileSize})`,
        page: 'transparencia' as PageRoute,
        category: 'Transparência' as const,
        iconType: 'doc' as const,
      })),
      // Direct Information
      {
        id: 'info-visitas',
        title: 'Agendamento de Visitas ao Lar',
        description: 'Horários para visitantes de 2ª a 6ª e regras de segurança para os moradores.',
        page: 'contato',
        category: 'Informação',
        iconType: 'info',
      },
      {
        id: 'info-pix',
        title: 'Chave PIX e Doações Financeiras',
        description: 'Orientações para transferências e emissão de recibo de doação filantrópica.',
        page: 'corrente-do-bem',
        category: 'Informação',
        iconType: 'need',
      },
      {
        id: 'info-endereco',
        title: 'Endereço e Como Chegar em Juiz de Fora',
        description: `${INSTITUTION_INFO.address}, ${INSTITUTION_INFO.addressComplement}.`,
        page: 'contato',
        category: 'Informação',
        iconType: 'info',
      },
      {
        id: 'info-mapa',
        title: 'Mapa Interativo e Localização em Juiz de Fora',
        description: `Mapa com marcador no Lar Santa Luiza de Marillac (${INSTITUTION_INFO.neighborhood}), transporte público (linhas ${INSTITUTION_INFO.busLinesText}), rampa acessível e rotas no Google Maps e Waze.`,
        page: 'contato',
        category: 'Informação',
        iconType: 'info',
      },
      {
        id: 'info-historias-vida',
        title: 'Histórias de Vida e Biografias dos Residentes',
        description: 'Depoimentos, fotos e memórias de Dona Lourdinha, Seu Zé da Gaita, Dona Geraldinha e Seu Benedito.',
        page: 'home',
        category: 'Informação',
        iconType: 'care',
      },
      {
        id: 'info-noticias-recentes',
        title: 'Notícias Recentes, Eventos e Projetos do Lar',
        description: 'Acompanhe as últimas novidades: musicoterapia, horta sensorial, campanhas solidárias e melhorias de fisioterapia.',
        page: 'home',
        category: 'Informação',
        iconType: 'info',
      },
      {
        id: 'info-calendario-eventos',
        title: 'Calendário de Eventos, Atividades e Festas do Lar',
        description: 'Programação de datas comemorativas, oficinas de jardinagem, musicoterapia, missas, bingo recreativo e cantata de Natal nos próximos meses.',
        page: 'home',
        category: 'Cuidado e Rotina',
        iconType: 'care',
      },
      {
        id: 'info-instagram',
        title: 'Galeria do Instagram e Fotos Recentes da Rotina',
        description: 'Fotos do dia a dia, café da tarde, oficinas de crochê, dominó, horta sensorial e momentos de afeto dos moradores.',
        page: 'home',
        category: 'Cuidado e Rotina',
        iconType: 'care',
      },
      {
        id: 'info-calculadora-impacto',
        title: 'Calculadora de Impacto de Doação (Cestas e Kits)',
        description: 'Descubra o que sua doação proporciona em cestas básicas nutricionais, kits de higiene sênior, fraldas geriátricas e dias de alimentação.',
        page: 'home',
        category: 'Corrente do Bem',
        iconType: 'need',
      },
      {
        id: 'info-tema-escuro',
        title: 'Modo Escuro / Noturno (Acessibilidade Visual)',
        description: 'Alterne as cores para melhorar o conforto visual e visibilidade noturna no cabeçalho.',
        page: 'home',
        category: 'Informação',
        iconType: 'info',
      },
      // FAQ Items
      {
        id: 'faq-ilpi',
        title: 'Como funciona o acolhimento residencial no Lar?',
        description: 'ILPI filantrópica com moradia protegida, nutrição supervisionada e enfermagem 24h em Juiz de Fora.',
        page: 'home',
        category: 'Informação',
        iconType: 'info',
      },
      {
        id: 'faq-clinica',
        title: 'O Lar funciona como hospital ou clínica aberta?',
        description: 'Não. É exclusivamente moradia e acolhimento contínuo para idosos residentes.',
        page: 'home',
        category: 'Informação',
        iconType: 'info',
      },
      {
        id: 'faq-voluntariado',
        title: 'Como participar como voluntário no Lar?',
        description: 'Atividades fraternas, música, conversas e oficinas comunitárias.',
        page: 'contato',
        category: 'Informação',
        iconType: 'info',
      },
      {
        id: 'faq-enfermagem',
        title: 'Cuidados de enfermagem e administração de medicações',
        description: 'Plantão 24h, aferição diária de sinais vitais e rigor nas receitas médicas.',
        page: 'home',
        category: 'Cuidado e Rotina',
        iconType: 'care',
      },
      // Accessibility Voice Control Item
      {
        id: 'info-acessibilidade-voz',
        title: 'Audiodescrição e Comandos de Voz para Idosos',
        description: 'Recurso com leitura pausada da tela, comandos por microfone, ampliação de letra e alto contraste.',
        page: 'home',
        category: 'Informação',
        iconType: 'info',
      },
      // Photo Gallery / Infraestrutura
      {
        id: 'info-galeria-fotos',
        title: 'Galeria de Fotos da Infraestrutura (Lightbox)',
        description: 'Fotos em alta resolução dos dormitórios, jardins, refeitório, posto de enfermagem e sala de fisioterapia.',
        page: 'sobre',
        category: 'Cuidado e Rotina',
        iconType: 'care',
      },
    ];
    return items;
  }, []);

  // Filtered Results
  const results = useMemo(() => {
    if (!query.trim()) return [];
    const cleanQuery = query.toLowerCase().trim();
    return searchIndex.filter(
      (item) =>
        item.title.toLowerCase().includes(cleanQuery) ||
        item.description.toLowerCase().includes(cleanQuery) ||
        item.category.toLowerCase().includes(cleanQuery)
    ).slice(0, 6);
  }, [query, searchIndex]);

  const handleSelectResult = (item: SearchResultItem) => {
    onNavigate(item.page);
    setIsFocused(false);
    setQuery('');

    if (item.id === 'info-visitas') {
      setTimeout(() => onOpenVisitModal(), 300);
    } else if (item.id === 'info-pix') {
      setTimeout(() => onOpenDonationModal(), 300);
    } else if (item.id === 'info-calendario-eventos') {
      setTimeout(() => {
        const el = document.getElementById('calendario-eventos');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 350);
    } else if (item.id === 'info-instagram') {
      setTimeout(() => {
        const el = document.getElementById('galeria-instagram');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 350);
    } else if (item.id === 'info-calculadora-impacto') {
      setTimeout(() => {
        const el = document.getElementById('calculadora-impacto');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 350);
    } else if (item.id === 'info-tema-escuro') {
      const isDark = document.documentElement.classList.contains('dark');
      if (isDark) {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      } else {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      }
    }
  };

  const getResultIcon = (iconType: string) => {
    switch (iconType) {
      case 'page':
        return <Building className="w-4 h-4 text-[#073B91]" />;
      case 'care':
        return <Heart className="w-4 h-4 text-[#073B91]" />;
      case 'need':
        return <Heart className="w-4 h-4 text-[#76A900]" />;
      case 'doc':
        return <FileText className="w-4 h-4 text-[#073B91]" />;
      default:
        return <HelpCircle className="w-4 h-4 text-[#76A900]" />;
    }
  };

  return (
    <div
      ref={containerRef}
      className="w-full bg-[#FAFBF9] border-b border-stone-200/80 py-2.5 px-4 sm:px-6 relative z-30 transition-all"
    >
      <div className="max-w-[760px] mx-auto relative">
        {/* Input Container - Centralized Bar */}
        <div
          className={`flex items-center gap-3 px-4 py-2 bg-white rounded-full border transition-all shadow-2xs ${
            isFocused
              ? 'border-[#073B91] ring-2 ring-[#073B91]/15 shadow-sm'
              : 'border-stone-300 hover:border-stone-400'
          }`}
        >
          <Search className="w-4 h-4 text-[#073B91] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            placeholder="Pesquisar páginas, necessidades da Corrente do Bem, cuidados ou documentos..."
            className="flex-1 bg-transparent text-sm text-[#27343B] placeholder-stone-400 focus:outline-hidden font-body"
            aria-label="Pesquisar no site"
          />

          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                inputRef.current?.focus();
              }}
              className="p-1 text-stone-400 hover:text-stone-600 rounded-full hover:bg-stone-100 transition-colors"
              aria-label="Limpar pesquisa"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          <kbd className="hidden sm:inline-flex items-center gap-0.5 text-[11px] font-mono text-stone-400 bg-stone-100 px-2 py-0.5 rounded-md border border-stone-200 shrink-0">
            ⌘K
          </kbd>
        </div>

        {/* Dropdown Results Box */}
        {isFocused && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl border border-stone-200 shadow-xl overflow-hidden z-50 animate-in fade-in duration-150">
            {query.trim() === '' ? (
              <div className="p-4 bg-stone-50/70 border-b border-stone-100">
                <span className="text-[11px] font-semibold text-[#66737A] uppercase tracking-wider block mb-2 font-mono">
                  Sugestões de Pesquisa:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { label: 'Como Ajudar (PIX)', page: 'corrente-do-bem' as PageRoute },
                    { label: 'Agendar Visita', page: 'contato' as PageRoute },
                    { label: 'Galeria de Fotos', page: 'sobre' as PageRoute },
                    { label: 'História do Lar', page: 'nossa-historia' as PageRoute },
                    { label: 'Perguntas Frequentes', page: 'sobre' as PageRoute },
                    { label: 'Transparência Financeira', page: 'transparencia' as PageRoute },
                  ].map((sug, sIdx) => (
                    <button
                      key={sIdx}
                      type="button"
                      onMouseDown={(e) => {
                        e.preventDefault();
                        onNavigate(sug.page);
                        setIsFocused(false);
                      }}
                      className="px-2.5 py-1 bg-white hover:bg-[#F5F8F0] hover:text-[#073B91] text-stone-600 rounded-md text-xs border border-stone-200 transition-colors cursor-pointer"
                    >
                      {sug.label}
                    </button>
                  ))}
                </div>
              </div>
            ) : results.length > 0 ? (
              <div className="divide-y divide-stone-100 max-h-[380px] overflow-y-auto">
                <div className="px-4 py-2 bg-stone-50 flex items-center justify-between text-[11px] text-[#66737A] font-medium font-mono">
                  <span>{results.length} resultado(s) encontrado(s)</span>
                  <span>Pressione Esc para fechar</span>
                </div>
                {results.map((result) => (
                  <button
                    key={result.id}
                    type="button"
                    onMouseDown={(e) => {
                      e.preventDefault();
                      handleSelectResult(result);
                    }}
                    className="w-full text-left p-3.5 hover:bg-[#F5F8F0] flex items-start gap-3 transition-colors group cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-lg bg-stone-100 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-white group-hover:shadow-2xs transition-all">
                      {getResultIcon(result.iconType)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-heading font-semibold text-sm text-[#27343B] group-hover:text-[#073B91] truncate">
                          {result.title}
                        </span>
                        <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-stone-100 text-[#66737A] shrink-0 font-mono">
                          {result.category}
                        </span>
                      </div>
                      <p className="text-xs text-[#66737A] mt-1 line-clamp-1 font-body">
                        {result.description}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-stone-300 group-hover:text-[#073B91] group-hover:translate-x-1 shrink-0 mt-2 transition-all" />
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center space-y-2">
                <HelpCircle className="w-7 h-7 text-stone-400 mx-auto" />
                <p className="text-sm font-semibold text-[#27343B]">
                  Nenhum resultado encontrado para &quot;{query}&quot;
                </p>
                <p className="text-xs text-[#66737A] max-w-sm mx-auto">
                  Tente buscar por termos como &quot;doação&quot;, &quot;visitas&quot;, &quot;enfermagem&quot;, &quot;fotos&quot; ou &quot;endereço&quot;.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
