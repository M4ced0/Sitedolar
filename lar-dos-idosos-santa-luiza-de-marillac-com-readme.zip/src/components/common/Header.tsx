import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { HeaderSearch } from './HeaderSearch';
import { PageRoute } from '../../types';
import {
  Heart,
  Phone,
  Calendar,
  Home,
  Users,
  History,
  Gift,
  FileCheck2,
  Mail,
} from 'lucide-react';
import { INSTITUTION_INFO } from '../../data/institutionalData';

interface HeaderProps {
  currentPage: PageRoute;
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: () => void;
  onOpenVisitModal: () => void;
  onOpenVoiceAccessibility?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  onOpenDonationModal,
  onOpenVisitModal,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);

  // Guarantee Light Mode is strictly enforced
  useEffect(() => {
    document.documentElement.classList.remove('dark');
    localStorage.setItem('theme', 'light');
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks: { id: PageRoute; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Início', icon: <Home className="w-3.5 h-3.5" /> },
    { id: 'sobre', label: 'Sobre Nós', icon: <Users className="w-3.5 h-3.5" /> },
    { id: 'nossa-historia', label: 'Nossa História', icon: <History className="w-3.5 h-3.5" /> },
    { id: 'corrente-do-bem', label: 'Corrente do Bem', icon: <Gift className="w-3.5 h-3.5" /> },
    { id: 'transparencia', label: 'Transparência', icon: <FileCheck2 className="w-3.5 h-3.5" /> },
    { id: 'contato', label: 'Contato', icon: <Mail className="w-3.5 h-3.5" /> },
  ];

  const handleNavClick = (page: PageRoute) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 w-full font-body bg-white shadow-xs">
      {/* 1. BARRA PRINCIPAL (Espaço pra Logo + Barra de Pesquisa Maior + Ações Rápidas) */}
      <div className="w-full bg-white border-b border-stone-200/80">
        <div className="max-w-[1280px] mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3 flex items-center justify-between gap-3 sm:gap-4 md:gap-6">
          {/* ESQUERDA: EXCLUSIVAMENTE 'Espaço pra logo' solicitado pelo usuário */}
          <div className="shrink-0 flex items-center">
            <button
              onClick={() => handleNavClick('home')}
              className="flex items-center text-left focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-[#073B91] rounded-xl cursor-pointer"
              aria-label="Ir para a página inicial"
            >
              <Logo placeholderOnly={true} size="md" />
            </button>
          </div>

          {/* CENTRO: BARRA DE PESQUISA MAIOR E PROMINENTE */}
          <div className="flex-1 flex justify-center max-w-[280px] sm:max-w-[380px] md:max-w-[480px] lg:max-w-[560px]">
            <HeaderSearch
              onNavigate={onNavigate}
              onOpenDonationModal={onOpenDonationModal}
              onOpenVisitModal={onOpenVisitModal}
              className="w-full"
            />
          </div>

          {/* DIREITA: Telefone, Agendar Visita e Botão de Doação */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Telefone Direto em Destaque */}
            <a
              href={`tel:${INSTITUTION_INFO.phoneClean}`}
              className="hidden lg:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-50 hover:bg-stone-100 border border-stone-200 text-xs font-semibold text-[#073B91] transition-colors"
              title="Ligar para o Lar"
            >
              <Phone className="w-3.5 h-3.5 text-[#073B91]" />
              <span>{INSTITUTION_INFO.phone}</span>
            </a>

            {/* Botão Agendar Visita */}
            <button
              type="button"
              onClick={onOpenVisitModal}
              className="hidden md:inline-flex items-center gap-1.5 px-3 sm:px-3.5 py-2 text-xs font-semibold text-[#073B91] hover:text-[#052c6e] bg-[#F5F8F0] hover:bg-[#EBF2DE] border border-stone-200/90 rounded-xl transition-all shadow-2xs hover:shadow-xs whitespace-nowrap cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5 text-[#76A900]" />
              <span>Agendar Visita</span>
            </button>

            {/* Botão de Doação em Destaque */}
            <button
              type="button"
              onClick={onOpenDonationModal}
              className="group inline-flex items-center justify-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold text-white bg-[#76A900] hover:bg-[#689400] rounded-xl shadow-xs hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 transition-all whitespace-nowrap cursor-pointer"
            >
              <Heart className="w-3.5 h-3.5 fill-white" />
              <span>Faça uma doação</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. BARRA DE TÓPICOS 100% VISÍVEL (Sem precisar de scroll para ver as opções) */}
      <nav
        aria-label="Tópicos de navegação principal"
        className="w-full bg-[#FAFBF7] border-b border-stone-200"
      >
        <div className="max-w-[1280px] mx-auto px-2 sm:px-6 lg:px-8">
          {/* Versão Desktop & Tablet (Horizontal contínua e 100% visível sem scroll) */}
          <div className="hidden md:flex items-center justify-between gap-1 lg:gap-2 py-1.5">
            <div className="flex items-center gap-1 sm:gap-2 lg:gap-3 flex-wrap">
              {navLinks.map((link) => {
                const isActive = currentPage === link.id;
                return (
                  <button
                    key={link.id}
                    onClick={() => handleNavClick(link.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-[13px] lg:text-[14px] font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                      isActive
                        ? 'bg-[#073B91] text-white shadow-2xs'
                        : 'text-[#27343B] hover:text-[#073B91] hover:bg-white/80'
                    }`}
                    aria-current={isActive ? 'page' : undefined}
                  >
                    <span className={isActive ? 'text-[#9FE000]' : 'text-stone-400'}>
                      {link.icon}
                    </span>
                    <span>{link.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Selo Institucional discreto à direita */}
            <div className="hidden xl:flex items-center gap-2 text-[11px] font-semibold text-[#073B91]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#76A900]" />
              <span>ILPI Filantrópica · Juiz de Fora - MG</span>
            </div>
          </div>

          {/* Versão Mobile (Grid 3x2: Todos os 6 tópicos visíveis simultaneamente sem scroll) */}
          <div className="md:hidden py-1.5 grid grid-cols-3 gap-1">
            {navLinks.map((link) => {
              const isActive = currentPage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`flex flex-col items-center justify-center p-1.5 rounded-lg text-center transition-all cursor-pointer leading-tight ${
                    isActive
                      ? 'bg-[#073B91] text-white shadow-2xs font-bold'
                      : 'bg-white hover:bg-stone-100 text-[#27343B] border border-stone-200/70 font-medium'
                  }`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <span className={`text-[12px] mb-0.5 ${isActive ? 'text-[#9FE000]' : 'text-[#073B91]'}`}>
                    {link.icon}
                  </span>
                  <span className="text-[11px] truncate w-full px-0.5">
                    {link.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    </header>
  );
};
