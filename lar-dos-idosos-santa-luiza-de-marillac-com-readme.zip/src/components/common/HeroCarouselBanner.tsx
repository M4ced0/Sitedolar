import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Heart,
  Calendar,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Clock,
  UtensilsCrossed,
  HeartHandshake,
  Users,
  Pause,
  Play,
  Sparkles,
  MapPin,
  Camera,
  Image as ImageIcon,
} from 'lucide-react';
import { PageRoute } from '../../types';
import { INSTITUTION_INFO } from '../../data/institutionalData';

interface HeroCarouselBannerProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: (options?: any) => void;
  onOpenVisitModal: () => void;
}

interface SlideItem {
  id: number;
  kicker: string;
  title: string;
  highlightWord?: string;
  description: string;
  imageUrl: string;
  imageAlt: string;
  tabLabel: string;
  tabSubtitle: string;
  stats: { label: string; value: string }[];
  primaryCta: {
    label: string;
    action: 'donate' | 'visit' | 'navigate';
    targetPage?: PageRoute;
    icon: 'heart' | 'calendar' | 'arrow';
  };
  secondaryCta: {
    label: string;
    action: 'donate' | 'visit' | 'navigate';
    targetPage?: PageRoute;
    icon: 'heart' | 'calendar' | 'arrow';
  };
}

const SLIDES: SlideItem[] = [
  {
    id: 0,
    kicker: 'Tradição e Filantropia em Juiz de Fora · Desde 1970',
    title: 'Mais de 50 Anos Dedicados ao Amor, Respeito e Dignidade',
    description:
      'Um lar verdadeiro onde cada residente é acolhido com afeto incondicional, segurança e assistência ininterrupta 24 horas por dia.',
    imageUrl: '', // Wireframe: Inserir banner slide 1 (1920x850px)
    imageAlt: 'Momento de carinho e acolhimento humanizado entre cuidador e idoso no Lar Santa Luiza de Marillac',
    tabLabel: '01 · Acolhimento & Amor',
    tabSubtitle: '50+ anos em Juiz de Fora',
    stats: [
      { label: 'História em JF', value: '50+ Anos' },
      { label: 'Idosos Acolhidos', value: '40 Residentes' },
      { label: 'Assistência', value: '100% Filantrópico' },
    ],
    primaryCta: {
      label: 'Fazer uma Doação',
      action: 'donate',
      icon: 'heart',
    },
    secondaryCta: {
      label: 'Agendar Visita ao Lar',
      action: 'visit',
      icon: 'calendar',
    },
  },
  {
    id: 1,
    kicker: 'Assistência de Saúde Ininterrupta · Plantão 24h',
    title: 'Cuidados Contínuos de Enfermagem com Presença e Zelo',
    description:
      'Equipe de enfermagem sempre presente administrando medicações prescritas, aferindo sinais vitais e proporcionando conforto integral.',
    imageUrl: '', // Wireframe: Inserir banner slide 2 (1920x850px)
    imageAlt: 'Profissional de saúde segurando a mão de idosa com zelo e atenção no leito',
    tabLabel: '02 · Enfermagem 24 Horas',
    tabSubtitle: 'Assistência ininterrupta',
    stats: [
      { label: 'Plantão de Saúde', value: '24 Horas / Dia' },
      { label: 'Horas Anuais', value: '8.760 h de Cuidado' },
      { label: 'Medicação', value: 'Controle Rigoroso' },
    ],
    primaryCta: {
      label: 'Apoiar os Cuidados Médicos',
      action: 'donate',
      icon: 'heart',
    },
    secondaryCta: {
      label: 'Conhecer Nossos Serviços',
      action: 'navigate',
      targetPage: 'sobre',
      icon: 'arrow',
    },
  },
  {
    id: 2,
    kicker: 'Cozinha Própria · Cardápios Balanceados por Nutricionista',
    title: '6 Refeições Diárias Preparadas com Afeto de Família',
    description:
      'Alimentação saudável adaptada a cada morador — opções específicas para hipertensos, diabéticos e residentes com restrição alimentar.',
    imageUrl: '', // Wireframe: Inserir banner slide 3 (1920x850px)
    imageAlt: 'Mesa farta e acolhedora com refeição fresca e nutritiva no refeitório',
    tabLabel: '03 · Nutrição & Alimentação',
    tabSubtitle: '6 refeições ao dia',
    stats: [
      { label: 'Refeições / Ano', value: '87.000+' },
      { label: 'Frequência', value: '6x ao Dia' },
      { label: 'Cardápio', value: '100% Supervisionado' },
    ],
    primaryCta: {
      label: 'Doar Alimentos ou Recursos',
      action: 'donate',
      icon: 'heart',
    },
    secondaryCta: {
      label: 'Ver Lista de Necessidades',
      action: 'navigate',
      targetPage: 'corrente-do-bem',
      icon: 'arrow',
    },
  },
  {
    id: 3,
    kicker: 'Espaços Arborizados · Convivência Comunitária Viva',
    title: 'A Alegria de Envelhecer Cercado de Música, Sol e Amizade',
    description:
      'Jardins abertos para banho de sol, celebrações comunitárias, rodas de conversa e visitas voluntárias que aquecem o coração.',
    imageUrl: '', // Wireframe: Inserir banner slide 4 (1920x850px)
    imageAlt: 'Idosos em convivência ensolarada nos jardins floridos e pátios arborizados da instituição',
    tabLabel: '04 · Vida & Convivência',
    tabSubtitle: 'Socialização ativa',
    stats: [
      { label: 'Ambiente', value: 'Pátios Arborizados' },
      { label: 'Atividades', value: 'Música & Memória' },
      { label: 'Comunidade', value: 'Visitas Fraternas' },
    ],
    primaryCta: {
      label: 'Agendar uma Visita Fraterna',
      action: 'visit',
      icon: 'calendar',
    },
    secondaryCta: {
      label: 'Conhecer Nossa História',
      action: 'navigate',
      targetPage: 'nossa-historia',
      icon: 'arrow',
    },
  },
];

const SLIDE_DURATION = 6500; // 6.5s per slide

export const HeroCarouselBanner: React.FC<HeroCarouselBannerProps> = ({
  onNavigate,
  onOpenDonationModal,
  onOpenVisitModal,
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const nextSlide = useCallback(() => {
    setCurrentSlideIndex((prev) => (prev + 1) % SLIDES.length);
    setProgress(0);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentSlideIndex((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
    setProgress(0);
  }, []);

  const goToSlide = (idx: number) => {
    setCurrentSlideIndex(idx);
    setProgress(0);
  };

  // Autoplay timer with progressive indicator
  useEffect(() => {
    if (isPaused) {
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
      return;
    }

    const intervalTime = 50; // update progress every 50ms
    const step = (intervalTime / SLIDE_DURATION) * 100;

    progressIntervalRef.current = setInterval(() => {
      setProgress((old) => {
        if (old >= 100) {
          nextSlide();
          return 0;
        }
        return old + step;
      });
    }, intervalTime);

    return () => {
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    };
  }, [isPaused, nextSlide]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  const activeSlide = SLIDES[currentSlideIndex];

  const handleAction = (cta: SlideItem['primaryCta']) => {
    if (cta.action === 'donate') onOpenDonationModal();
    else if (cta.action === 'visit') onOpenVisitModal();
    else if (cta.action === 'navigate' && cta.targetPage) onNavigate(cta.targetPage);
  };

  return (
    <section
      aria-label="Destaques Institucionais do Lar dos Idosos Santa Luiza de Marillac"
      className="relative w-full overflow-hidden bg-stone-900 font-body select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Background Image Carousel with Smooth Fade & Ken Burns subtle motion */}
      <div className="relative w-full h-[580px] sm:h-[620px] lg:h-[680px]">
        {SLIDES.map((slide, idx) => {
          const isActive = idx === currentSlideIndex;
          return (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
              }`}
            >
              {/* Wireframe Placeholder for Hero Carousel Slide */}
              <div className="w-full h-full bg-slate-900 relative overflow-hidden flex items-center justify-center">
                {/* Blueprint grid background */}
                <div
                  className="absolute inset-0 opacity-20 pointer-events-none"
                  style={{
                    backgroundImage: 'radial-gradient(circle, #38bdf8 1.5px, transparent 1.5px)',
                    backgroundSize: '24px 24px',
                  }}
                />
                <div
                  className="absolute inset-0 opacity-15 pointer-events-none"
                  style={{
                    backgroundImage:
                      'linear-gradient(to right, #475569 1px, transparent 1px), linear-gradient(to bottom, #475569 1px, transparent 1px)',
                    backgroundSize: '80px 80px',
                  }}
                />

                {/* Photographic curation indicator in top right */}
                <div className="absolute top-20 right-6 sm:right-12 z-10 max-w-sm p-4 rounded-2xl bg-stone-900/80 border border-stone-700/70 backdrop-blur-md shadow-xl text-left hidden md:block">
                  <div className="flex items-center gap-2 text-[#9FE000] font-mono text-xs font-semibold uppercase tracking-wider mb-1">
                    <Camera className="w-4 h-4 text-[#9FE000]" />
                    <span>Registro Fotográfico · Slide 0{idx + 1}</span>
                  </div>
                  <p className="text-white text-xs font-medium line-clamp-2">
                    {slide.imageAlt}
                  </p>
                  <p className="text-[11px] text-stone-400 font-mono mt-1">
                    Dimensão recomendada: 1920 × 850 px
                  </p>
                </div>
              </div>

              {/* High-End Scrim: Multi-stop gradient for razor-sharp typography contrast */}
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/95 via-stone-900/60 to-stone-950/50" />
              <div className="absolute inset-0 bg-gradient-to-r from-stone-950/90 via-stone-950/60 to-transparent lg:w-3/4" />
            </div>
          );
        })}

        {/* Foreground Content Container - Perfectly Aligned and Centralized */}
        <div className="relative z-20 h-full max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-between pt-12 pb-24 sm:pb-28 lg:pb-32">
          {/* Top Row: Institutional Editorial Kicker & Autoplay Controls */}
          <div className="flex items-center justify-between gap-4">
            <div className="text-xs uppercase tracking-wider font-bold text-[#9FE000] drop-shadow-xs">
              {activeSlide.kicker}
            </div>

            {/* Play/Pause & Slide Counter Badge */}
            <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/15 text-white/90 text-xs">
              <button
                type="button"
                onClick={() => setIsPaused((p) => !p)}
                className="hover:text-white transition-colors cursor-pointer p-0.5"
                title={isPaused ? 'Continuar carrossel' : 'Pausar carrossel'}
                aria-label={isPaused ? 'Continuar carrossel' : 'Pausar carrossel'}
              >
                {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
              </button>
              <span className="text-white/40">|</span>
              <span className="font-mono font-medium">
                0{currentSlideIndex + 1} / 0{SLIDES.length}
              </span>
            </div>
          </div>

          {/* Central Stage: Main Headline, Description, Metrics & Animated CTA Buttons */}
          <div className="max-w-3xl my-auto space-y-6 pt-4">
            <h1 className="font-heading text-3xl sm:text-4xl md:text-5xl lg:text-[54px] font-extrabold text-white leading-[1.12] tracking-tight drop-shadow-md text-balance">
              {activeSlide.title}
            </h1>

            <p className="text-base sm:text-lg md:text-xl text-stone-200 leading-relaxed font-body max-w-2xl text-pretty drop-shadow-sm">
              {activeSlide.description}
            </p>

            {/* Micro Metrics Strip */}
            <div className="flex flex-wrap items-center gap-3 sm:gap-6 pt-1 text-white/90 text-xs sm:text-sm font-body">
              {activeSlide.stats.map((st, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-[#9FE000] font-bold">·</span>
                  <span className="font-semibold text-white">{st.value}</span>
                  <span className="text-stone-300 font-light">({st.label})</span>
                </div>
              ))}
            </div>

            {/* Botões Intuitivos e Animados */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-3">
              {/* Botão Primário com Brilho e Pulso de Coração */}
              <button
                type="button"
                onClick={() => handleAction(activeSlide.primaryCta)}
                className="group relative inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-xl text-white font-bold text-sm sm:text-base bg-[#073B91] hover:bg-[#052c6e] shadow-lg hover:shadow-xl hover:shadow-[#073B91]/35 hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all duration-200 cursor-pointer overflow-hidden"
              >
                {/* Efeito de brilho sweep animado ao passar o mouse */}
                <span className="absolute inset-0 w-1/2 h-full bg-white/15 skew-x-12 -translate-x-full group-hover:translate-x-[300%] transition-transform duration-1000 ease-out pointer-events-none" />

                {activeSlide.primaryCta.icon === 'heart' && (
                  <Heart className="w-5 h-5 fill-current text-white animate-pulse" />
                )}
                {activeSlide.primaryCta.icon === 'calendar' && (
                  <Calendar className="w-5 h-5 text-white" />
                )}
                {activeSlide.primaryCta.icon === 'arrow' && (
                  <ArrowRight className="w-5 h-5 text-white group-hover:translate-x-1 transition-transform" />
                )}
                <span>{activeSlide.primaryCta.label}</span>
              </button>

              {/* Botão Secundário com Borda Elegante e Transição Tátil */}
              <button
                type="button"
                onClick={() => handleAction(activeSlide.secondaryCta)}
                className="group inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl text-white font-semibold text-sm sm:text-base bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 hover:border-white/60 hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all duration-200 cursor-pointer"
              >
                {activeSlide.secondaryCta.icon === 'heart' && (
                  <Heart className="w-4 h-4 fill-white/20 text-white" />
                )}
                {activeSlide.secondaryCta.icon === 'calendar' && (
                  <Calendar className="w-4 h-4 text-[#9FE000]" />
                )}
                <span>{activeSlide.secondaryCta.label}</span>
                {activeSlide.secondaryCta.icon === 'arrow' && (
                  <ArrowRight className="w-4 h-4 text-white group-hover:translate-x-1 transition-transform" />
                )}
              </button>
            </div>
          </div>

          {/* Quick Sub-ribbon with Direct Visiting and Address Link */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/15 text-xs text-stone-300">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 text-stone-300">
                <MapPin className="w-3.5 h-3.5 text-[#9FE000]" />
                <span>{INSTITUTION_INFO.street} · {INSTITUTION_INFO.neighborhood}</span>
              </span>
              <span className="hidden sm:inline text-white/30">·</span>
              <span className="hidden sm:inline flex items-center gap-1.5 text-stone-300">
                <Clock className="w-3.5 h-3.5 text-[#9FE000]" />
                <span>Visitas com agendamento prévio</span>
              </span>
            </div>

            <button
              type="button"
              onClick={onOpenVisitModal}
              className="hover:text-white text-[#9FE000] font-semibold underline underline-offset-4 cursor-pointer flex items-center gap-1 transition-colors"
            >
              <span>Deseja conhecer de perto? Agende uma visita guiada</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Setas Laterais de Navegação (Esquerda e Direita) com Hover Animado */}
        <button
          type="button"
          onClick={prevSlide}
          className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-30 p-3 sm:p-3.5 rounded-full bg-black/35 hover:bg-[#073B91] text-white/80 hover:text-white backdrop-blur-md border border-white/20 shadow-xl hover:scale-110 active:scale-95 transition-all duration-200 cursor-pointer hidden md:flex items-center justify-center"
          aria-label="Slide anterior"
        >
          <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>

        <button
          type="button"
          onClick={nextSlide}
          className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-30 p-3 sm:p-3.5 rounded-full bg-black/35 hover:bg-[#073B91] text-white/80 hover:text-white backdrop-blur-md border border-white/20 shadow-xl hover:scale-110 active:scale-95 transition-all duration-200 cursor-pointer hidden md:flex items-center justify-center"
          aria-label="Próximo slide"
        >
          <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>
      </div>

      {/* Faixa Inferior de Abas / Indicadores com Barra de Progresso Animada */}
      <div className="relative z-30 w-full bg-white border-t border-stone-200 shadow-xs">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4 py-3 sm:py-4">
            {SLIDES.map((slide, idx) => {
              const isCurrent = idx === currentSlideIndex;
              return (
                <button
                  key={slide.id}
                  type="button"
                  onClick={() => goToSlide(idx)}
                  className={`text-left p-3 rounded-xl transition-all cursor-pointer relative overflow-hidden group ${
                    isCurrent
                      ? 'bg-[#F5F8F0] border border-[#073B91]/30 shadow-xs'
                      : 'hover:bg-stone-50 border border-transparent'
                  }`}
                >
                  {/* Barra de Progresso do Slide Ativo */}
                  {isCurrent && (
                    <div
                      className="absolute top-0 left-0 bottom-0 bg-[#073B91]/10 pointer-events-none transition-all duration-75 ease-linear"
                      style={{ width: `${progress}%` }}
                    />
                  )}

                  <div className="relative z-10 flex items-center justify-between mb-0.5">
                    <span
                      className={`text-xs font-bold font-heading truncate ${
                        isCurrent ? 'text-[#073B91]' : 'text-stone-700 group-hover:text-stone-900'
                      }`}
                    >
                      {slide.tabLabel}
                    </span>
                    <span
                      className={`w-2 h-2 rounded-full shrink-0 transition-colors ${
                        isCurrent ? 'bg-[#76A900]' : 'bg-stone-300'
                      }`}
                    />
                  </div>

                  <p className="relative z-10 text-[11px] text-stone-500 font-body truncate">
                    {slide.tabSubtitle}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
