import React from 'react';

interface IllustrationFrameProps {
  scene: 'hero' | 'garden' | 'facilities' | 'care' | 'nursing' | 'community';
  alt: string;
  className?: string;
  aspect?: '16:9' | '4:3' | '1:1';
}

export const IllustrationFrame: React.FC<IllustrationFrameProps> = ({
  scene,
  alt,
  className = '',
  aspect = '16:9',
}) => {
  const aspectClass =
    aspect === '16:9' ? 'aspect-video' : aspect === '4:3' ? 'aspect-4/3' : 'aspect-square';

  return (
    <div
      role="img"
      aria-label={alt}
      className={`relative overflow-hidden rounded-xl bg-gradient-to-br from-stone-100 to-[#F5F8F0] border border-stone-200/80 shadow-xs ${aspectClass} ${className}`}
    >
      {scene === 'hero' && (
        <svg
          viewBox="0 0 800 450"
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="skyHero" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#E2EBF5" />
              <stop offset="65%" stopColor="#F5F8F0" />
              <stop offset="100%" stopColor="#EBF3DC" />
            </linearGradient>
            <linearGradient id="roofHero" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#C46849" />
              <stop offset="100%" stopColor="#A44D32" />
            </linearGradient>
            <linearGradient id="wallHero" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFDF9" />
              <stop offset="100%" stopColor="#F4EDE2" />
            </linearGradient>
          </defs>

          {/* Sky background */}
          <rect width="800" height="450" fill="url(#skyHero)" />

          {/* Distant Juiz de Fora rolling hills */}
          <path d="M 0 240 Q 180 180, 420 220 T 800 210 L 800 450 L 0 450 Z" fill="#D3E2C4" opacity="0.6" />
          <path d="M 0 260 Q 220 230, 480 250 T 800 240 L 800 450 L 0 450 Z" fill="#BCD4A7" opacity="0.7" />

          {/* Gentle sun warm glow */}
          <circle cx="680" cy="90" r="75" fill="#FFEBB3" opacity="0.5" />
          <circle cx="680" cy="90" r="45" fill="#FFF3D4" opacity="0.8" />

          {/* Institution Architecture / Colonial Veranda */}
          {/* Main Residence Building */}
          <path d="M 70 190 L 450 145 L 450 340 L 70 340 Z" fill="url(#wallHero)" stroke="#E5DCD0" strokeWidth="1" />
          {/* Terracotta tiled roof */}
          <polygon points="50,195 470,140 450,115 70,165" fill="url(#roofHero)" />

          {/* Colonial Windows & Archways */}
          <rect x="110" y="210" width="45" height="75" rx="22" fill="#073B91" opacity="0.12" stroke="#073B91" strokeWidth="2" />
          <rect x="180" y="210" width="45" height="75" rx="22" fill="#073B91" opacity="0.12" stroke="#073B91" strokeWidth="2" />
          <rect x="250" y="210" width="45" height="75" rx="22" fill="#073B91" opacity="0.12" stroke="#073B91" strokeWidth="2" />
          <path d="M 320 220 L 375 220 L 375 340 L 320 340 Z" fill="#073B91" opacity="0.18" />

          {/* Pillars of the Veranda */}
          <rect x="65" y="190" width="12" height="150" fill="#EADBC8" />
          <rect x="145" y="190" width="12" height="150" fill="#EADBC8" />
          <rect x="225" y="190" width="12" height="150" fill="#EADBC8" />
          <rect x="305" y="190" width="12" height="150" fill="#EADBC8" />
          <rect x="385" y="190" width="12" height="150" fill="#EADBC8" />

          {/* Veranda Wooden Bench of Peaceful Rest */}
          <rect x="130" y="295" width="80" height="8" rx="2" fill="#7C4B28" />
          <rect x="135" y="280" width="70" height="6" rx="2" fill="#7C4B28" />
          <rect x="135" y="270" width="70" height="6" rx="2" fill="#7C4B28" />
          <rect x="134" y="265" width="4" height="40" fill="#4A2C14" />
          <rect x="200" y="265" width="4" height="40" fill="#4A2C14" />

          {/* Garden Terrace Courtyard */}
          <path d="M 0 330 L 800 330 L 800 450 L 0 450 Z" fill="#88B834" />
          <path d="M 0 350 Q 200 340, 400 365 T 800 360 L 800 450 L 0 450 Z" fill="#76A900" />

          {/* Cobblestone walkway */}
          <path d="M 330 340 C 370 380, 420 400, 480 450 L 390 450 C 340 410, 310 380, 290 340 Z" fill="#E4DDD3" stroke="#D3C9BE" strokeWidth="1" />

          {/* Lush Minas Bougainvillea & Garden Shrubs */}
          <circle cx="560" cy="310" r="60" fill="#588500" />
          <circle cx="610" cy="290" r="45" fill="#76A900" />
          <circle cx="530" cy="290" r="40" fill="#699B00" />
          {/* Bougainvillea flowers */}
          <circle cx="550" cy="300" r="8" fill="#C53A68" />
          <circle cx="580" cy="285" r="9" fill="#D84E7B" />
          <circle cx="565" cy="275" r="7" fill="#C53A68" />
          <circle cx="605" cy="305" r="8" fill="#E86B93" />
          <circle cx="535" cy="315" r="7" fill="#D84E7B" />

          {/* Left garden tree */}
          <rect x="30" y="260" width="16" height="100" fill="#654321" />
          <circle cx="38" cy="230" r="55" fill="#486D04" />
          <circle cx="60" cy="210" r="45" fill="#69990A" />

          {/* Warm Institutional Overlay Badge */}
          <g transform="translate(480, 60)">
            <rect width="280" height="90" rx="8" fill="#FFFFFF" opacity="0.94" stroke="#E2E8F0" strokeWidth="1" />
            <text x="24" y="32" fontFamily="serif" fontSize="15" fontWeight="bold" fill="#073B91">Lar Santa Luiza de Marillac</text>
            <text x="24" y="52" fontFamily="sans-serif" fontSize="11" fill="#66737A">Mais de 50 anos de carinho e acolhimento</text>
            <text x="24" y="70" fontFamily="sans-serif" fontSize="11" fontWeight="600" fill="#76A900">Juiz de Fora · Minas Gerais</text>
          </g>
        </svg>
      )}

      {scene === 'garden' && (
        <svg
          viewBox="0 0 600 450"
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="450" fill="#F0F5E8" />
          {/* Pátio arborizado de convivência */}
          <circle cx="120" cy="120" r="80" fill="#FFEAA7" opacity="0.4" />
          {/* Árvores e pergolado */}
          <path d="M 0 280 Q 200 240, 400 270 T 600 260 L 600 450 L 0 450 Z" fill="#8BB737" />
          <path d="M 0 310 Q 300 290, 600 320 L 600 450 L 0 450 Z" fill="#76A900" />

          {/* Caminho acessível com corrimão */}
          <path d="M 120 450 C 220 370, 310 330, 420 300 L 460 300 C 340 340, 260 380, 180 450 Z" fill="#EAE4DA" />
          
          {/* Pergolado de madeira com flores */}
          <rect x="250" y="160" width="10" height="160" fill="#6B4423" />
          <rect x="370" y="160" width="10" height="160" fill="#6B4423" />
          <rect x="230" y="150" width="170" height="12" rx="2" fill="#85572E" />
          <rect x="250" y="140" width="14" height="20" fill="#85572E" />
          <rect x="290" y="140" width="14" height="20" fill="#85572E" />
          <rect x="330" y="140" width="14" height="20" fill="#85572E" />
          <rect x="370" y="140" width="14" height="20" fill="#85572E" />

          {/* Flores trepadeiras no pergolado */}
          <circle cx="280" cy="155" r="16" fill="#F472B6" opacity="0.9" />
          <circle cx="340" cy="150" r="18" fill="#EC4899" opacity="0.9" />
          <circle cx="305" cy="165" r="14" fill="#DB2777" opacity="0.9" />

          {/* Banco de madeira sob sombra */}
          <rect x="275" y="270" width="80" height="6" fill="#543317" />
          <rect x="280" y="255" width="70" height="5" fill="#543317" />
          <rect x="280" y="276" width="5" height="24" fill="#3D220E" />
          <rect x="345" y="276" width="5" height="24" fill="#3D220E" />

          <text x="30" y="45" fontFamily="serif" fontSize="18" fontWeight="bold" fill="#073B91">Jardim & Pátio de Convivência</text>
          <text x="30" y="68" fontFamily="sans-serif" fontSize="12" fill="#506673">Espaço aberto para banho de sol, ar puro e contemplação segura</text>
        </svg>
      )}

      {scene === 'facilities' && (
        <svg
          viewBox="0 0 600 450"
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="450" fill="#FAF8F5" />
          {/* Sala de convivência e refeitório limpo e acolhedor */}
          <rect x="40" y="60" width="140" height="190" fill="#E2EDF8" stroke="#073B91" strokeWidth="2" strokeDasharray="3 3" opacity="0.4" />
          {/* Janelão com vista para as árvores */}
          <rect x="50" y="70" width="120" height="170" fill="#E8F4E5" />
          <circle cx="100" cy="130" r="45" fill="#84B830" opacity="0.7" />
          <circle cx="130" cy="160" r="40" fill="#699E1B" opacity="0.7" />

          {/* Paredes e rodapés */}
          <line x1="0" y1="280" x2="600" y2="280" stroke="#E2DDD5" strokeWidth="2" />
          <rect x="0" y="280" width="600" height="170" fill="#F1ECE2" />

          {/* Mesas de refeição e socialização em madeira clara */}
          <ellipse cx="360" cy="330" rx="140" ry="45" fill="#CBB69D" stroke="#AA9276" strokeWidth="2" />
          {/* Cadeiras com encosto confortável */}
          <rect x="250" y="260" width="30" height="40" rx="3" fill="#073B91" opacity="0.8" />
          <rect x="440" y="260" width="30" height="40" rx="3" fill="#073B91" opacity="0.8" />
          <rect x="345" y="250" width="30" height="40" rx="3" fill="#073B91" opacity="0.8" />

          {/* Vaso com flores na mesa */}
          <rect x="350" y="305" width="20" height="25" rx="3" fill="#FFFFFF" stroke="#073B91" strokeWidth="1" />
          <circle cx="360" cy="295" r="10" fill="#76A900" />
          <circle cx="355" cy="290" r="6" fill="#F59E0B" />
          <circle cx="365" cy="290" r="6" fill="#EF4444" />

          <text x="30" y="45" fontFamily="serif" fontSize="18" fontWeight="bold" fill="#073B91">Refeitório & Convivência</text>
          <text x="30" y="68" fontFamily="sans-serif" fontSize="12" fill="#506673">Refeições diárias preparadas com carinho e espaços amplos</text>
        </svg>
      )}

      {scene === 'care' && (
        <svg
          viewBox="0 0 600 450"
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="450" fill="#F9FBF6" />
          {/* Cesta de doações e itens de carinho na Corrente do Bem */}
          <circle cx="300" cy="225" r="180" fill="#EAF3DA" opacity="0.6" />

          {/* Mesa rústica de apoio */}
          <rect x="60" y="310" width="480" height="20" rx="2" fill="#A8815C" />
          <rect x="80" y="330" width="15" height="100" fill="#785536" />
          <rect x="505" y="330" width="15" height="100" fill="#785536" />

          {/* Cesta de alimentos saudáveis */}
          <path d="M 140 250 L 260 250 L 245 310 L 155 310 Z" fill="#D29961" stroke="#A76D38" strokeWidth="2" />
          {/* Frutas na cesta */}
          <circle cx="175" cy="240" r="18" fill="#EF4444" /> {/* Maçã */}
          <circle cx="205" cy="235" r="20" fill="#F59E0B" /> {/* Laranja */}
          <circle cx="230" cy="245" r="16" fill="#84CC16" /> {/* Maçã verde */}
          <circle cx="185" cy="220" r="12" fill="#EAB308" /> {/* Banana/Fruta */}

          {/* Pilha de toalhas e lençóis brancos higienizados */}
          <rect x="290" y="270" width="90" height="16" rx="4" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1" />
          <rect x="292" y="252" width="86" height="16" rx="4" fill="#F8FAFC" stroke="#CBD5E1" strokeWidth="1" />
          <rect x="295" y="234" width="80" height="16" rx="4" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1" />

          {/* Frascos de sabonete e itens de higiene */}
          <rect x="410" y="230" width="30" height="80" rx="5" fill="#073B91" opacity="0.8" />
          <rect x="420" y="215" width="10" height="15" rx="2" fill="#76A900" />
          <rect x="450" y="245" width="35" height="65" rx="5" fill="#76A900" opacity="0.8" />
          <rect x="462" y="233" width="12" height="12" rx="2" fill="#073B91" />

          {/* Coração / Laço de solidariedade */}
          <path d="M 300 130 C 285 110, 255 115, 250 135 C 245 155, 270 175, 300 195 C 330 175, 355 155, 350 135 C 345 115, 315 110, 300 130 Z" fill="#76A900" />

          <text x="30" y="45" fontFamily="serif" fontSize="18" fontWeight="bold" fill="#073B91">Corrente do Bem</text>
          <text x="30" y="68" fontFamily="sans-serif" fontSize="12" fill="#506673">Cada doação se transforma em nutrição, dignidade e carinho</text>
        </svg>
      )}

      {scene === 'nursing' && (
        <svg
          viewBox="0 0 600 450"
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="450" fill="#F7FAFC" />
          {/* Posto e acompanhamento de cuidados contínuos */}
          <circle cx="300" cy="225" r="160" fill="#E6EEF8" opacity="0.6" />

          {/* Símbolo do cuidado de enfermagem e saúde */}
          <circle cx="300" cy="200" r="60" fill="#073B91" opacity="0.1" stroke="#073B91" strokeWidth="2" />
          {/* Cruz humanizada */}
          <rect x="290" y="165" width="20" height="70" rx="3" fill="#073B91" />
          <rect x="265" y="190" width="70" height="20" rx="3" fill="#073B91" />
          {/* Folha de vida verde */}
          <path d="M 320 160 C 340 165, 350 185, 340 205 C 330 190, 325 175, 320 160 Z" fill="#76A900" />

          {/* Prancheta de controle e acompanhamento de medicação */}
          <rect x="180" y="270" width="80" height="110" rx="6" fill="#FFFFFF" stroke="#073B91" strokeWidth="2" />
          <rect x="205" y="260" width="30" height="15" rx="3" fill="#76A900" />
          <line x1="195" y1="290" x2="245" y2="290" stroke="#94A3B8" strokeWidth="2" />
          <line x1="195" y1="310" x2="245" y2="310" stroke="#94A3B8" strokeWidth="2" />
          <line x1="195" y1="330" x2="235" y2="330" stroke="#94A3B8" strokeWidth="2" />
          <line x1="195" y1="350" x2="245" y2="350" stroke="#94A3B8" strokeWidth="2" />

          {/* Estetoscópio e cuidado atencioso */}
          <path d="M 360 280 C 370 330, 420 340, 430 300 L 430 270" fill="none" stroke="#76A900" strokeWidth="4" strokeLinecap="round" />
          <circle cx="430" cy="300" r="10" fill="#073B91" />

          <text x="30" y="45" fontFamily="serif" fontSize="18" fontWeight="bold" fill="#073B91">Cuidados de Enfermagem</text>
          <text x="30" y="68" fontFamily="sans-serif" fontSize="12" fill="#506673">Administração criteriosa de prescrições e monitoramento diário</text>
        </svg>
      )}

      {scene === 'community' && (
        <svg
          viewBox="0 0 600 450"
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect width="600" height="450" fill="#F4F8F0" />
          {/* Abraço e convivência fraterna */}
          <circle cx="300" cy="200" r="120" fill="#DCECC4" opacity="0.6" />
          <circle cx="260" cy="180" r="35" fill="#073B91" opacity="0.85" />
          <circle cx="340" cy="180" r="35" fill="#76A900" opacity="0.85" />
          
          <path d="M 210 280 C 210 230, 310 230, 310 280 Z" fill="#073B91" opacity="0.85" />
          <path d="M 290 280 C 290 230, 390 230, 390 280 Z" fill="#76A900" opacity="0.85" />

          <text x="30" y="45" fontFamily="serif" fontSize="18" fontWeight="bold" fill="#073B91">Convivência & Vínculos</text>
          <text x="30" y="68" fontFamily="sans-serif" fontSize="12" fill="#506673">Celebração da vida, respeito à história e carinho constante</text>
        </svg>
      )}
    </div>
  );
};
