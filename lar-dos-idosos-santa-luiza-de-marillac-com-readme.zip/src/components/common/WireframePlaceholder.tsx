import React from 'react';
import { Image as ImageIcon, Camera, User } from 'lucide-react';

interface WireframePlaceholderProps {
  label: string;
  suggestedDimensions?: string;
  aspectRatio?: string; // e.g. 'aspect-video', 'aspect-square', 'aspect-[4/3]', etc.
  type?: 'banner' | 'card' | 'avatar' | 'gallery' | 'portrait';
  className?: string;
  slotId?: string;
  notes?: string;
}

export const WireframePlaceholder: React.FC<WireframePlaceholderProps> = ({
  label,
  suggestedDimensions = '1200 × 800 px',
  aspectRatio = 'aspect-video',
  type = 'card',
  className = '',
  slotId,
  notes,
}) => {
  if (type === 'avatar') {
    return (
      <div
        className={`relative flex flex-col items-center justify-center bg-[#F5F8F0] border-2 border-dashed border-stone-300 rounded-full text-stone-400 select-none overflow-hidden group hover:border-[#76A900] hover:bg-white transition-colors ${className}`}
        title={`Registro do Residente: ${label} (${suggestedDimensions})`}
        data-slot={slotId}
      >
        <User className="w-1/2 h-1/2 text-stone-400 group-hover:text-[#073B91] transition-colors" />
        <span className="sr-only">{label}</span>
      </div>
    );
  }

  return (
    <div
      className={`relative flex flex-col items-center justify-center p-6 bg-[#FAFBF7] border border-stone-200/90 rounded-2xl text-stone-600 select-none overflow-hidden transition-all duration-300 hover:border-[#073B91]/40 hover:bg-white shadow-2xs group ${aspectRatio} ${className}`}
      data-slot={slotId}
    >
      {/* Subtle fine weave watermark */}
      <div
        className="absolute inset-0 opacity-[0.18] pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle, #073B91 0.75px, transparent 0.75px)',
          backgroundSize: '20px 20px',
        }}
      />

      <div className="relative z-10 flex flex-col items-center justify-center text-center max-w-[92%] space-y-2.5">
        {/* Curated Photography Tag */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-stone-200 shadow-2xs text-[10px] font-semibold tracking-wider uppercase text-[#073B91] group-hover:border-[#76A900]/50 transition-colors">
          <Camera className="w-3 h-3 text-[#76A900]" />
          <span>Curadoria Fotográfica Institucional</span>
        </div>

        {/* Icon & Label */}
        <div className="flex flex-col items-center gap-1.5">
          <div className="w-11 h-11 rounded-xl bg-white border border-stone-200 flex items-center justify-center text-[#073B91] shadow-2xs group-hover:scale-105 group-hover:border-[#073B91]/30 transition-all">
            <ImageIcon className="w-5 h-5 text-[#073B91]" />
          </div>
          <p className="font-heading text-xs sm:text-sm font-bold text-[#27343B] line-clamp-2 px-1">
            {label}
          </p>
        </div>

        {/* Dimensions & Notes */}
        <div className="flex flex-wrap items-center justify-center gap-2 text-[10px] sm:text-[11px] text-stone-500 font-mono">
          <span className="bg-white px-2.5 py-0.5 rounded-md border border-stone-200 font-medium">
            {suggestedDimensions}
          </span>
          {slotId && (
            <span className="text-stone-400 hidden sm:inline">
              Ref: {slotId}
            </span>
          )}
        </div>

        {notes && (
          <p className="text-[11px] text-stone-500 max-w-sm italic line-clamp-2 pt-0.5">
            {notes}
          </p>
        )}
      </div>

      {/* Readiness Badge */}
      <div className="absolute bottom-2.5 right-2.5 opacity-0 group-hover:opacity-100 transition-opacity bg-white/95 text-[10px] font-semibold text-[#4E7300] px-2.5 py-0.5 rounded-md shadow-2xs border border-[#76A900]/30">
        Pronto para receber fotografia
      </div>
    </div>
  );
};
