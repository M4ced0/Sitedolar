import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  MapPin,
  Navigation,
  Plus,
  Minus,
  RotateCcw,
  Compass,
  Maximize2,
  Minimize2,
  Copy,
  Check,
  ExternalLink,
  Layers,
  Bus,
  Car,
  Clock,
  Calendar,
  Sparkles,
  Accessibility,
} from 'lucide-react';
import { INSTITUTION_INFO } from '../../data/institutionalData';

type MapViewMode = 'standard' | 'transit' | 'aerial' | 'google';

interface Landmark {
  id: string;
  name: string;
  category: 'primary' | 'bus' | 'church' | 'avenue' | 'health';
  x: number;
  y: number;
  description: string;
  badge: string;
}

const LANDMARKS: Landmark[] = [
  {
    id: 'lar-santa-luiza',
    name: 'Lar dos Idosos Santa Luiza de Marillac',
    category: 'primary',
    x: 490,
    y: 290,
    description: 'Sede Própria & ILPI Filantrópica. R. Furtado de Menezes - Vila Furtado de Menezes, CEP 36020-410. Portaria com rampa acessível.',
    badge: 'Destino Principal',
  },
  {
    id: 'bus-furtado-de-menezes',
    name: 'Parada de Ônibus (Linhas 322, 325, 399)',
    category: 'bus',
    x: 420,
    y: 270,
    description: 'Parada com abrigo e calçada acessível atendida diretamente pelas linhas municipais 322, 325 e 399.',
    badge: 'Transporte Público',
  },
  {
    id: 'rua-furtado-de-menezes',
    name: 'R. Furtado de Menezes',
    category: 'avenue',
    x: 310,
    y: 210,
    description: 'Via de acesso principal na Vila Furtado de Menezes conectando à sede do Lar.',
    badge: 'Acesso Principal',
  },
  {
    id: 'praca-furtado-de-menezes',
    name: 'Praça Vila Furtado de Menezes',
    category: 'church',
    x: 230,
    y: 410,
    description: 'Ponto de referência e convivência comunitária do bairro Vila Furtado de Menezes.',
    badge: 'Referência Local',
  },
  {
    id: 'apoio-saude',
    name: 'Unidade de Apoio e Comércio Vicinal',
    category: 'health',
    x: 640,
    y: 330,
    description: 'Serviços vicinais e conveniência para suporte a visitantes e residentes.',
    badge: 'Serviços Vicinais',
  },
];

interface InteractiveMapSectionProps {
  onOpenVisitModal?: () => void;
}

export const InteractiveMapSection: React.FC<InteractiveMapSectionProps> = ({
  onOpenVisitModal,
}) => {
  // Map navigation state (zoom & pan offsets)
  const [zoom, setZoom] = useState<number>(1.1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: -40, y: -20 });
  const [viewMode, setViewMode] = useState<MapViewMode>('standard');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [activeLandmark, setActiveLandmark] = useState<Landmark>(LANDMARKS[0]);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [showPopup, setShowPopup] = useState<boolean>(true);

  // Drag state
  const isDraggingRef = useRef<boolean>(false);
  const startDragPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const mapContainerRef = useRef<HTMLDivElement>(null);

  // Zoom limits
  const minZoom = 0.85;
  const maxZoom = 2.4;

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(Number((prev + 0.25).toFixed(2)), maxZoom));
  };

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(Number((prev - 0.25).toFixed(2)), minZoom));
  };

  const handleReset = () => {
    setZoom(1.1);
    setPan({ x: -40, y: -20 });
    setActiveLandmark(LANDMARKS[0]);
    setShowPopup(true);
  };

  const handleCenterOnPrimary = () => {
    setZoom(1.35);
    setPan({ x: -60, y: -45 });
    setActiveLandmark(LANDMARKS[0]);
    setShowPopup(true);
  };

  // Mouse pan handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, a')) return;
    isDraggingRef.current = true;
    startDragPosRef.current = {
      x: e.clientX - pan.x,
      y: e.clientY - pan.y,
    };
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDraggingRef.current) return;
    const newX = e.clientX - startDragPosRef.current.x;
    const newY = e.clientY - startDragPosRef.current.y;
    // Bound drag
    setPan({
      x: Math.max(-280, Math.min(280, newX)),
      y: Math.max(-220, Math.min(220, newY)),
    });
  }, []);

  const handleMouseUp = useCallback(() => {
    isDraggingRef.current = false;
  }, []);

  useEffect(() => {
    const onUp = () => handleMouseUp();
    const onMove = (e: MouseEvent) => handleMouseMove(e);
    window.addEventListener('mouseup', onUp);
    window.addEventListener('mousemove', onMove);
    return () => {
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('mousemove', onMove);
    };
  }, [handleMouseMove, handleMouseUp]);

  // Touch drag support
  const handleTouchStart = (e: React.TouchEvent) => {
    if ((e.target as HTMLElement).closest('button, a')) return;
    if (e.touches.length === 1) {
      isDraggingRef.current = true;
      startDragPosRef.current = {
        x: e.touches[0].clientX - pan.x,
        y: e.touches[0].clientY - pan.y,
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDraggingRef.current || e.touches.length !== 1) return;
    const newX = e.touches[0].clientX - startDragPosRef.current.x;
    const newY = e.touches[0].clientY - startDragPosRef.current.y;
    setPan({
      x: Math.max(-280, Math.min(280, newX)),
      y: Math.max(-220, Math.min(220, newY)),
    });
  };

  const handleTouchEnd = () => {
    isDraggingRef.current = false;
  };

  const handleCopyAddress = async () => {
    const fullAddress = `${INSTITUTION_INFO.name}, ${INSTITUTION_INFO.address}, ${INSTITUTION_INFO.addressComplement}, CEP ${INSTITUTION_INFO.cep}`;
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(fullAddress);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2500);
      }
    } catch {
      // fallback
    }
  };

  // Google Maps and Waze URLs
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${INSTITUTION_INFO.googleMapsQuery}`;
  const wazeUrl = `https://waze.com/ul?q=Rua+Furtado+de+Menezes+Vila+Furtado+de+Menezes+Juiz+de+Fora`;

  return (
    <section id="mapa-interativo" className="py-20 lg:py-28 bg-[#F5F8F0]/40 border-t border-stone-200/70 font-body">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#76A900]/15 text-[#5e8700] text-xs font-semibold uppercase tracking-wider">
              <Compass className="w-3.5 h-3.5" />
              <span>Localização & Mapa Interativo</span>
            </div>
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-[#27343B] tracking-tight">
              Como Chegar ao Lar Santa Luiza de Marillac
            </h2>
            <p className="text-sm sm:text-base text-[#66737A] leading-relaxed">
              Estamos situados na <strong>R. Furtado de Menezes - Vila Furtado de Menezes</strong>, Juiz de Fora (MG), CEP 36020-410. Navegue pelo mapa interativo, consulte as linhas de ônibus (<strong>322, 325 e 399</strong>) e trace sua rota até nós.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleCopyAddress}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium bg-white text-[#27343B] border border-stone-300 hover:border-[#073B91] hover:text-[#073B91] rounded-xl shadow-2xs transition-colors"
            >
              {isCopied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">Endereço Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-stone-500" />
                  <span>Copiar Endereço</span>
                </>
              )}
            </button>

            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-xl shadow-2xs transition-colors"
            >
              <Navigation className="w-4 h-4" />
              <span>Abrir no Google Maps</span>
              <ExternalLink className="w-3.5 h-3.5 text-blue-200" />
            </a>
          </div>
        </div>

        {/* Interactive Map Card Wrapper */}
        <div
          ref={mapContainerRef}
          className={`relative rounded-3xl overflow-hidden border border-stone-200 bg-stone-100 shadow-md transition-all duration-300 ${
            isFullscreen
              ? 'fixed inset-4 z-50 shadow-2xl border-stone-400 bg-white'
              : 'w-full h-[540px] sm:h-[600px] lg:h-[640px]'
          }`}
        >
          {/* Top Floating Control Bar */}
          <div className="absolute top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
            {/* View Mode Switcher */}
            <div className="pointer-events-auto flex items-center p-1 bg-white/95 backdrop-blur-md rounded-2xl border border-stone-200/90 shadow-sm">
              <button
                type="button"
                onClick={() => setViewMode('standard')}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                  viewMode === 'standard'
                    ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                    : 'text-[#27343B] hover:text-[#073B91] hover:bg-stone-100'
                }`}
              >
                Mapa do Bairro
              </button>
              <button
                type="button"
                onClick={() => setViewMode('transit')}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                  viewMode === 'transit'
                    ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                    : 'text-[#27343B] hover:text-[#073B91] hover:bg-stone-100'
                }`}
              >
                <Bus className="w-3 h-3" />
                <span>Ônibus (322, 325, 399)</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('aerial')}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                  viewMode === 'aerial'
                    ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                    : 'text-[#27343B] hover:text-[#073B91] hover:bg-stone-100'
                }`}
              >
                <Layers className="w-3 h-3" />
                <span>Topografia Verde</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('google')}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                  viewMode === 'google'
                    ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                    : 'text-[#27343B] hover:text-[#073B91] hover:bg-stone-100'
                }`}
              >
                <Compass className="w-3 h-3" />
                <span>Google Maps GPS</span>
              </button>
            </div>

            {/* Quick Status / City Pin Badge */}
            <div className="hidden sm:flex pointer-events-auto items-center gap-2 px-3.5 py-1.5 bg-white/95 backdrop-blur-md rounded-2xl border border-stone-200/90 shadow-sm text-xs font-medium text-[#27343B]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#76A900] animate-pulse" />
              <span>Juiz de Fora · {INSTITUTION_INFO.neighborhood}</span>
            </div>
          </div>

          {/* Interactive Canvas or Real Google Maps Embed */}
          {viewMode === 'google' ? (
            <div className="w-full h-full relative">
              <iframe
                title="Google Maps - Lar dos Idosos Santa Luiza de Marillac (Vila Furtado de Menezes)"
                src={INSTITUTION_INFO.googleMapsEmbedUrl}
                className="w-full h-full border-0"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          ) : (
            <div
              onMouseDown={handleMouseDown}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className="w-full h-full select-none cursor-grab active:cursor-grabbing overflow-hidden relative flex items-center justify-center"
              style={{
                backgroundColor:
                  viewMode === 'aerial'
                    ? '#35453A'
                    : viewMode === 'transit'
                    ? '#EEF3F8'
                    : '#F6F5EE',
              }}
            >
            {/* The SVG Cartography Viewport */}
            <div
              className="origin-center transition-transform duration-75 ease-out"
              style={{
                transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                width: '1000px',
                height: '700px',
              }}
            >
              <svg
                viewBox="0 0 1000 700"
                className="w-full h-full"
                xmlns="http://www.w3.org/2000/svg"
              >
                <defs>
                  {/* Subtle Grid Pattern */}
                  <pattern id="street-grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path
                      d="M 40 0 L 0 0 0 40"
                      fill="none"
                      stroke={viewMode === 'aerial' ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.03)'}
                      strokeWidth="1"
                    />
                  </pattern>

                  {/* Institution Campus Pattern */}
                  <pattern id="campus-texture" width="16" height="16" patternUnits="userSpaceOnUse">
                    <circle cx="8" cy="8" r="1.5" fill="#76A900" opacity="0.3" />
                  </pattern>

                  {/* Marker Pulse Glow Filter */}
                  <filter id="marker-glow" x="-30%" y="-30%" width="160%" height="160%">
                    <feDropShadow dx="0" dy="4" stdDeviation="6" floodColor="#073B91" floodOpacity="0.4" />
                  </filter>
                </defs>

                {/* Base Land Fill */}
                <rect
                  width="1000"
                  height="700"
                  fill={
                    viewMode === 'aerial'
                      ? '#2A3B30'
                      : viewMode === 'transit'
                      ? '#EDF2F7'
                      : '#F5F4ED'
                  }
                />
                <rect width="1000" height="700" fill="url(#street-grid)" />

                {/* Urban Green Spaces / Parks in Juiz de Fora */}
                {/* Parque Halfeld / Morro do Cristo regional greenery */}
                <path
                  d="M 60,40 C 140,50 180,120 160,200 C 130,270 50,250 40,160 Z"
                  fill={viewMode === 'aerial' ? '#1E2D22' : '#E2EBD8'}
                  stroke={viewMode === 'aerial' ? '#2A4030' : '#D1DEBF'}
                  strokeWidth="2"
                />
                <text
                  x="100"
                  y="140"
                  fontSize="11"
                  fill={viewMode === 'aerial' ? '#8CA890' : '#6F8C64'}
                  fontWeight="600"
                  fontFamily="sans-serif"
                >
                  Área Verde Preservada
                </text>

                {/* Praça Vila Furtado de Menezes */}
                <rect
                  x="290"
                  y="260"
                  width="70"
                  height="60"
                  rx="10"
                  fill={viewMode === 'aerial' ? '#24382A' : '#DDE9D0'}
                  stroke={viewMode === 'aerial' ? '#33503C' : '#C7DCB4'}
                  strokeWidth="2"
                />
                <text
                  x="300"
                  y="295"
                  fontSize="10"
                  fill={viewMode === 'aerial' ? '#8CA890' : '#557548'}
                  fontWeight="600"
                  fontFamily="sans-serif"
                >
                  Praça
                </text>

                {/* Secondary greenery block */}
                <path
                  d="M 750,80 C 840,90 920,150 890,240 C 840,310 740,260 720,180 Z"
                  fill={viewMode === 'aerial' ? '#223326' : '#E5EEDA'}
                />

                {/* River / Paraibuna Regional Water Body Accent */}
                <path
                  d="M -20,620 Q 250,580 500,640 T 1020,590"
                  fill="none"
                  stroke={viewMode === 'aerial' ? '#1D2E38' : '#C8DEEB'}
                  strokeWidth="36"
                  strokeLinecap="round"
                />
                <text
                  x="600"
                  y="625"
                  fontSize="12"
                  fill={viewMode === 'aerial' ? '#4D7896' : '#6293B3'}
                  fontWeight="600"
                  fontFamily="sans-serif"
                  letterSpacing="2"
                >
                  RIO PARAIBUNA (EIXO REGIONAL)
                </text>

                {/* Road System - Secondary / Residential Streets */}
                <g stroke={viewMode === 'aerial' ? '#3F4F46' : '#FFFFFF'} strokeWidth="16" strokeLinecap="round" strokeLinejoin="round">
                  {/* Rua Padre Café */}
                  <line x1="180" y1="120" x2="260" y2="520" />
                  {/* Rua Dr. Romualdo */}
                  <line x1="360" y1="100" x2="430" y2="540" />
                  {/* Rua Morais e Castro */}
                  <line x1="560" y1="120" x2="610" y2="530" />
                  {/* Rua Chanceler Oswaldo Aranha */}
                  <line x1="720" y1="140" x2="770" y2="550" />
                  {/* Transversals */}
                  <line x1="120" y1="210" x2="880" y2="240" />
                  <line x1="100" y1="360" x2="890" y2="390" />
                  <line x1="130" y1="480" x2="880" y2="510" />
                </g>

                {/* Main Arterial Avenues */}
                {/* Av. Presidente Itamar Franco */}
                <g>
                  <line
                    x1="80"
                    y1="490"
                    x2="920"
                    y2="340"
                    stroke={viewMode === 'aerial' ? '#586A5E' : '#E2E5D8'}
                    strokeWidth="32"
                    strokeLinecap="round"
                  />
                  <line
                    x1="80"
                    y1="490"
                    x2="920"
                    y2="340"
                    stroke={viewMode === 'transit' ? '#073B91' : viewMode === 'aerial' ? '#D6AD60' : '#F2C94C'}
                    strokeWidth="4"
                    strokeDasharray="16, 12"
                  />
                  <text
                    x="210"
                    y="455"
                    transform="rotate(-10, 210, 455)"
                    fontSize="12"
                    fontWeight="700"
                    fill={viewMode === 'aerial' ? '#FFFFFF' : '#45525B'}
                    fontFamily="sans-serif"
                    letterSpacing="1"
                  >
                    AV. PRESIDENTE ITAMAR FRANCO
                  </text>
                </g>

                {/* Primary Street: R. FURTADO DE MENEZES (Where the institution is located) */}
                <g>
                  <line
                    x1="120"
                    y1="310"
                    x2="910"
                    y2="260"
                    stroke={viewMode === 'aerial' ? '#6C7F72' : '#FFF9D6'}
                    strokeWidth="28"
                    strokeLinecap="round"
                  />
                  <line
                    x1="120"
                    y1="310"
                    x2="910"
                    y2="260"
                    stroke={viewMode === 'aerial' ? '#9DB3A3' : '#E5C973'}
                    strokeWidth="2"
                    strokeDasharray="8, 8"
                  />
                  <text
                    x="560"
                    y="275"
                    transform="rotate(-3, 560, 275)"
                    fontSize="13"
                    fontWeight="800"
                    fill={viewMode === 'aerial' ? '#FFFFFF' : '#073B91'}
                    fontFamily="sans-serif"
                    letterSpacing="1"
                  >
                    R. FURTADO DE MENEZES
                  </text>
                </g>

                {/* Public Transit Line Overlay (Visible in transit view) */}
                {viewMode === 'transit' && (
                  <g>
                    {/* Bus Line Corridor Glow */}
                    <line
                      x1="120"
                      y1="310"
                      x2="910"
                      y2="260"
                      stroke="#073B91"
                      strokeWidth="8"
                      strokeOpacity="0.4"
                      strokeLinecap="round"
                    />
                    <line
                      x1="80"
                      y1="490"
                      x2="920"
                      y2="340"
                      stroke="#76A900"
                      strokeWidth="8"
                      strokeOpacity="0.5"
                      strokeLinecap="round"
                    />
                    <text
                      x="380"
                      y="245"
                      fontSize="10"
                      fontWeight="bold"
                      fill="#073B91"
                      fontFamily="sans-serif"
                    >
                      🚌 Parada de Ônibus (Linhas 322 / 325 / 399)
                    </text>
                  </g>
                )}

                {/* INSTITUTION CAMPUS GROUNDS (Lar Santa Luiza de Marillac) */}
                <g>
                  {/* Property boundary with garden polygon */}
                  <rect
                    x="450"
                    y="240"
                    width="140"
                    height="100"
                    rx="14"
                    fill={viewMode === 'aerial' ? '#2A4634' : '#E8F2D5'}
                    stroke="#76A900"
                    strokeWidth="3"
                    strokeDasharray="6, 4"
                  />
                  <rect
                    x="452"
                    y="242"
                    width="136"
                    height="96"
                    rx="12"
                    fill="url(#campus-texture)"
                  />

                  {/* Main Building Structure */}
                  <rect
                    x="475"
                    y="265"
                    width="90"
                    height="55"
                    rx="6"
                    fill={viewMode === 'aerial' ? '#4F6355' : '#073B91'}
                    stroke="#FFFFFF"
                    strokeWidth="2"
                    filter="url(#marker-glow)"
                  />

                  {/* Accessible Entry Ramp marker path */}
                  <path
                    d="M 460,300 L 475,300"
                    stroke="#76A900"
                    strokeWidth="4"
                    strokeLinecap="round"
                  />

                  {/* Building Label */}
                  <text
                    x="485"
                    y="297"
                    fontSize="11"
                    fontWeight="bold"
                    fill="#FFFFFF"
                    fontFamily="sans-serif"
                  >
                    LAR SANTA LUIZA
                  </text>
                  <text
                    x="493"
                    y="310"
                    fontSize="8.5"
                    fontWeight="500"
                    fill="#A5C6F0"
                    fontFamily="sans-serif"
                  >
                    SEDE & MORADIA
                  </text>
                </g>

                {/* OTHER LANDMARK ICONS ON MAP */}
                {LANDMARKS.filter((l) => l.id !== 'lar-santa-luiza').map((landmark) => {
                  const isSelected = activeLandmark.id === landmark.id;
                  return (
                    <g
                      key={landmark.id}
                      onClick={() => {
                        setActiveLandmark(landmark);
                        setShowPopup(true);
                      }}
                      className="cursor-pointer group"
                    >
                      <circle
                        cx={landmark.x}
                        cy={landmark.y}
                        r={isSelected ? '14' : '10'}
                        fill={
                          landmark.category === 'bus'
                            ? '#073B91'
                            : landmark.category === 'church'
                            ? '#B8860B'
                            : landmark.category === 'health'
                            ? '#D9534F'
                            : '#556B2F'
                        }
                        stroke="#FFFFFF"
                        strokeWidth="2"
                        className="transition-all duration-200 group-hover:scale-125"
                      />
                      <circle
                        cx={landmark.x}
                        cy={landmark.y}
                        r="4"
                        fill="#FFFFFF"
                      />
                      <text
                        x={landmark.x + 14}
                        y={landmark.y + 4}
                        fontSize="10"
                        fontWeight="600"
                        fill={viewMode === 'aerial' ? '#E1E9E3' : '#27343B'}
                        fontFamily="sans-serif"
                        className="pointer-events-none drop-shadow-xs"
                      >
                        {landmark.name.split('(')[0]}
                      </text>
                    </g>
                  );
                })}

                {/* PRIMARY DESTINATION PIN: Lar dos Idosos Santa Luiza de Marillac */}
                <g
                  onClick={() => {
                    setActiveLandmark(LANDMARKS[0]);
                    setShowPopup(true);
                  }}
                  className="cursor-pointer"
                >
                  {/* Animated Beacon Ring */}
                  <circle
                    cx="490"
                    cy="290"
                    r="28"
                    fill="#76A900"
                    opacity="0.25"
                    className="animate-ping origin-center"
                    style={{ transformOrigin: '490px 290px' }}
                  />
                  <circle
                    cx="490"
                    cy="290"
                    r="16"
                    fill="#76A900"
                    opacity="0.35"
                  />

                  {/* Marker Pin Base Shadow */}
                  <ellipse cx="490" cy="290" rx="10" ry="5" fill="rgba(0,0,0,0.3)" />

                  {/* Custom Pin SVG */}
                  <path
                    d="M 490,250 C 476,250 465,261 465,275 C 465,286 490,305 490,305 C 490,305 515,286 515,275 C 515,261 504,250 490,250 Z"
                    fill="#073B91"
                    stroke="#FFFFFF"
                    strokeWidth="2.5"
                    filter="url(#marker-glow)"
                  />
                  {/* Pin Center White Dot */}
                  <circle cx="490" cy="275" r="7" fill="#FFFFFF" />
                  <circle cx="490" cy="275" r="4.5" fill="#76A900" />
                </g>
              </svg>
            </div>

            {/* Pinned Info Popup Overlay over the active Landmark */}
            {showPopup && (
              <div
                className="absolute z-30 pointer-events-auto max-w-sm sm:max-w-md bg-white/98 backdrop-blur-md p-4 sm:p-5 rounded-2xl border border-stone-200/90 shadow-xl transition-all font-body text-left animate-in fade-in duration-200"
                style={{
                  bottom: isFullscreen ? '40px' : '24px',
                  left: isFullscreen ? '40px' : '24px',
                }}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#76A900]/15 text-[#5e8700]">
                      <Sparkles className="w-3 h-3" />
                      {activeLandmark.badge}
                    </span>
                    <span className="text-[11px] text-[#66737A]">Juiz de Fora - MG</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowPopup(false)}
                    className="text-stone-400 hover:text-stone-600 p-1 rounded-lg text-xs"
                    aria-label="Fechar pop-up informativo"
                  >
                    ✕
                  </button>
                </div>

                <h4 className="font-heading font-bold text-base sm:text-lg text-[#27343B] leading-snug">
                  {activeLandmark.name}
                </h4>

                <p className="text-xs sm:text-sm text-[#66737A] mt-1 leading-relaxed">
                  {activeLandmark.description}
                </p>

                {activeLandmark.id === 'lar-santa-luiza' && (
                  <div className="mt-3 p-3 bg-[#F5F8F0] rounded-xl border border-stone-200/80 space-y-1.5 text-xs text-[#27343B]">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-[#073B91] shrink-0" />
                      <span className="font-semibold">{INSTITUTION_INFO.address}</span>
                    </div>
                    <div className="flex items-center gap-2 text-stone-600">
                      <Accessibility className="w-4 h-4 text-[#76A900] shrink-0" />
                      <span>Entrada com rampa acessível e embarque nivelado</span>
                    </div>
                    <div className="flex items-center gap-2 text-stone-600">
                      <Clock className="w-4 h-4 text-[#073B91] shrink-0" />
                      <span>{INSTITUTION_INFO.hours}</span>
                    </div>
                  </div>
                )}

                <div className="flex flex-wrap items-center gap-2 pt-3 mt-3 border-t border-stone-200">
                  <a
                    href={googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#073B91] hover:bg-[#052c6e] text-white text-xs font-semibold shadow-2xs transition-colors"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Traçar Rota no Google Maps</span>
                  </a>

                  <a
                    href={wazeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#33CCFF] hover:bg-[#20b5e6] text-[#003B54] text-xs font-bold shadow-2xs transition-colors"
                  >
                    <Car className="w-3.5 h-3.5" />
                    <span>Abrir no Waze</span>
                  </a>

                  {onOpenVisitModal && activeLandmark.id === 'lar-santa-luiza' && (
                    <button
                      type="button"
                      onClick={onOpenVisitModal}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#76A900] hover:bg-[#648f00] text-white text-xs font-semibold shadow-2xs transition-colors"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Agendar Visita</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

          {/* Right Bottom Navigation / Zoom Controls */}
          <div className="absolute right-4 bottom-4 z-20 flex flex-col items-center gap-2 pointer-events-none">
            <div className="pointer-events-auto flex flex-col bg-white/95 backdrop-blur-md rounded-2xl border border-stone-200/90 shadow-md p-1">
              <button
                type="button"
                onClick={handleZoomIn}
                disabled={zoom >= maxZoom}
                className="p-2.5 text-[#27343B] hover:text-[#073B91] hover:bg-stone-100 rounded-xl transition-colors disabled:opacity-40"
                aria-label="Aumentar zoom"
                title="Aumentar zoom (+)"
              >
                <Plus className="w-4 h-4" />
              </button>
              <div className="w-full h-px bg-stone-200" />
              <button
                type="button"
                onClick={handleZoomOut}
                disabled={zoom <= minZoom}
                className="p-2.5 text-[#27343B] hover:text-[#073B91] hover:bg-stone-100 rounded-xl transition-colors disabled:opacity-40"
                aria-label="Diminuir zoom"
                title="Diminuir zoom (-)"
              >
                <Minus className="w-4 h-4" />
              </button>
              <div className="w-full h-px bg-stone-200" />
              <button
                type="button"
                onClick={handleCenterOnPrimary}
                className="p-2.5 text-[#27343B] hover:text-[#76A900] hover:bg-stone-100 rounded-xl transition-colors"
                aria-label="Centralizar no Lar Santa Luiza"
                title="Centralizar no Lar Santa Luiza"
              >
                <MapPin className="w-4 h-4 text-[#76A900]" />
              </button>
              <div className="w-full h-px bg-stone-200" />
              <button
                type="button"
                onClick={handleReset}
                className="p-2.5 text-[#27343B] hover:text-[#073B91] hover:bg-stone-100 rounded-xl transition-colors"
                aria-label="Restaurar visão original"
                title="Restaurar visão original"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            {/* Toggle Fullscreen / Expand button */}
            <button
              type="button"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="pointer-events-auto p-2.5 bg-white/95 backdrop-blur-md text-[#27343B] hover:text-[#073B91] hover:bg-stone-100 rounded-2xl border border-stone-200/90 shadow-md transition-colors"
              aria-label={isFullscreen ? 'Reduzir tela do mapa' : 'Expandir mapa'}
              title={isFullscreen ? 'Reduzir' : 'Expandir em tela inteira'}
            >
              {isFullscreen ? (
                <Minimize2 className="w-4 h-4" />
              ) : (
                <Maximize2 className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Bottom subtle drag tip */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 pointer-events-none hidden sm:block">
            <span className="px-3 py-1 rounded-full bg-stone-900/60 backdrop-blur-sm text-[11px] font-medium text-white/90 shadow-xs">
              🖱️ Clique e arraste para explorar o mapa de Juiz de Fora
            </span>
          </div>
        </div>

        {/* 3 Complementary Information Cards for Visitors */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8 font-body">
          {/* Card 1: Endereço e Acesso */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#073B91]/10 text-[#073B91] flex items-center justify-center">
              <MapPin className="w-5 h-5" />
            </div>
            <h3 className="font-heading font-bold text-lg text-[#27343B]">
              Endereço Físico
            </h3>
            <p className="text-sm text-[#66737A] leading-relaxed">
              <strong>{INSTITUTION_INFO.address}</strong>
              <br />
              {INSTITUTION_INFO.addressComplement} · CEP {INSTITUTION_INFO.cep}
            </p>
            <div className="pt-2 text-xs text-[#073B91] font-semibold flex items-center gap-1">
              <span>{INSTITUTION_INFO.neighborhood} · Juiz de Fora (MG)</span>
            </div>
          </div>

          {/* Card 2: Transporte Público */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#76A900]/15 text-[#76A900] flex items-center justify-center">
              <Bus className="w-5 h-5" />
            </div>
            <h3 className="font-heading font-bold text-lg text-[#27343B]">
              Transporte Público (Ônibus)
            </h3>
            <p className="text-sm text-[#66737A] leading-relaxed">
              Linhas municipais de ônibus que atendem o local: <strong>322</strong>, <strong>325</strong> e <strong>399</strong> (Vila Furtado de Menezes / Centro).
            </p>
            <div className="pt-2 text-xs text-[#76A900] font-semibold flex items-center gap-1">
              <span>Parada com calçada acessível próxima à portaria</span>
            </div>
          </div>

          {/* Card 3: Acessibilidade e Estacionamento */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-700 flex items-center justify-center">
              <Accessibility className="w-5 h-5" />
            </div>
            <h3 className="font-heading font-bold text-lg text-[#27343B]">
              Acessibilidade & Visitas
            </h3>
            <p className="text-sm text-[#66737A] leading-relaxed">
              Portaria adaptada com rampa nos parâmetros NBR 9050, área coberta para embarque/desembarque de pessoas idosas e vagas de suporte.
            </p>
            {onOpenVisitModal && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={onOpenVisitModal}
                  className="text-xs font-bold text-[#073B91] hover:underline inline-flex items-center gap-1"
                >
                  <span>Agendar visita guiada com a equipe →</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
