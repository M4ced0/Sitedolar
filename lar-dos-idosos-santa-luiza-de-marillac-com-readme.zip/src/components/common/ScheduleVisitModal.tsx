import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { X, Calendar, Clock, CheckCircle2, MessageSquare, Users, Heart } from 'lucide-react';
import { INSTITUTION_INFO } from '../../data/institutionalData';
import { notifySuccess } from '../../utils/notifications';

const visitSchema = z.object({
  fullName: z.string().min(3, 'Informe seu nome completo'),
  phone: z.string().min(10, 'Informe seu telefone ou WhatsApp com DDD'),
  email: z.string().email('Informe um e-mail válido'),
  preferredDate: z.string().min(1, 'Selecione uma data para a visita'),
  period: z.enum(['manha', 'tarde'] as const),
  visitorCount: z.string().min(1, 'Informe o número de pessoas'),
  notes: z.string().optional(),
  consent: z.boolean().refine((val) => val === true, {
    message: 'Concorde com os protocolos de acolhimento e visita',
  }),
});

type VisitFormData = z.infer<typeof visitSchema>;

interface ScheduleVisitModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ScheduleVisitModal: React.FC<ScheduleVisitModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [isSuccess, setIsSuccess] = useState(false);
  const [submittedData, setSubmittedData] = useState<VisitFormData | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<VisitFormData>({
    resolver: zodResolver(visitSchema),
    defaultValues: {
      fullName: '',
      phone: '',
      email: '',
      preferredDate: '',
      period: 'tarde',
      visitorCount: '1',
      notes: '',
      consent: false,
    },
  });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleClose = () => {
    setIsSuccess(false);
    setSubmittedData(null);
    reset();
    onClose();
  };

  const onSubmit = (data: VisitFormData) => {
    setSubmittedData(data);
    setIsSuccess(true);
    notifySuccess(`Visita solicitada com sucesso para ${data.preferredDate}! Nossa equipe entrará em contato.`);
  };

  const handleOpenWhatsAppConfirmation = () => {
    if (!submittedData) return;
    const text = encodeURIComponent(
      `Olá! Meu nome é ${submittedData.fullName}. Gostaria de confirmar o agendamento de uma visita ao Lar dos Idosos Santa Luiza de Marillac:\n` +
      `• Data pretendida: ${submittedData.preferredDate}\n` +
      `• Turno: ${submittedData.period === 'manha' ? 'Manhã (09h - 11h)' : 'Tarde (14h - 16h)'}\n` +
      `• Visitantes: ${submittedData.visitorCount} pessoa(s)\n` +
      `• Telefone: ${submittedData.phone}\n` +
      `${submittedData.notes ? `• Observações: ${submittedData.notes}\n` : ''}` +
      `Agradeço desde já!`
    );
    window.open(`https://wa.me/${INSTITUTION_INFO.whatsappClean}?text=${text}`, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200 font-body"
    >
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header com estilo acolhedor */}
        <div className="flex items-center justify-between px-6 py-4.5 border-b border-stone-200 bg-[#F5F8F0]">
          <div className="flex items-center gap-3">
            <span className="p-2.5 bg-[#073B91] text-white rounded-xl">
              <Calendar className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-heading font-bold text-lg text-[#073B91]">
                Agendar uma Visita ao Lar
              </h2>
              <p className="text-xs text-[#66737A]">
                Conheça de perto nosso ambiente acolhedor em Juiz de Fora
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 rounded-lg text-stone-500 hover:text-stone-800 hover:bg-stone-200/50 transition-colors"
            aria-label="Fechar modal de agendamento"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Conteúdo */}
        <div className="p-6 overflow-y-auto">
          {isSuccess && submittedData ? (
            <div className="text-center py-4 space-y-4">
              <div className="w-14 h-14 bg-[#76A900]/15 text-[#76A900] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-heading text-xl font-bold text-[#073B91]">
                  Solicitação de Visita Registrada!
                </h3>
                <p className="text-sm text-[#66737A] mt-1 max-w-md mx-auto">
                  Será uma grande alegria recebê-lo(a), <strong>{submittedData.fullName}</strong>.
                </p>
              </div>

              <div className="p-4 bg-[#F5F8F0] rounded-xl border border-stone-200 text-left text-xs sm:text-sm space-y-2 max-w-md mx-auto">
                <p className="font-semibold text-[#073B91] border-b border-stone-200 pb-1.5">
                  Detalhes do Agendamento:
                </p>
                <div className="flex justify-between text-[#66737A]">
                  <span>Data:</span>
                  <span className="font-medium text-[#27343B]">{submittedData.preferredDate}</span>
                </div>
                <div className="flex justify-between text-[#66737A]">
                  <span>Turno:</span>
                  <span className="font-medium text-[#27343B]">
                    {submittedData.period === 'manha' ? 'Manhã (09h - 11h)' : 'Tarde (14h - 16h)'}
                  </span>
                </div>
                <div className="flex justify-between text-[#66737A]">
                  <span>Pessoas:</span>
                  <span className="font-medium text-[#27343B]">{submittedData.visitorCount}</span>
                </div>
              </div>

              <p className="text-xs text-[#66737A] max-w-md mx-auto">
                Nossa equipe entrará em contato para confirmar a disponibilidade no dia selecionado, preservando a rotina e o repouso dos moradores.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                <button
                  type="button"
                  onClick={handleOpenWhatsAppConfirmation}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#76A900] hover:bg-[#679400] rounded-lg transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Confirmar via WhatsApp</span>
                </button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="px-4 py-2.5 text-xs sm:text-sm font-medium text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
                >
                  Concluir
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="p-3 bg-blue-50/70 border border-blue-200/80 rounded-xl text-xs text-[#073B91] leading-relaxed">
                As visitas são agendadas previamente para respeitar a tranquilidade, os horários de refeição e o descanso dos nossos residentes acolhidos.
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1">
                  Nome completo <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  {...register('fullName')}
                  placeholder="Seu nome e sobrenome"
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91]"
                />
                {errors.fullName && (
                  <p className="text-xs text-red-600 mt-1">{errors.fullName.message}</p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1">
                    Telefone / WhatsApp <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    {...register('phone')}
                    placeholder="(32) 99999-9999"
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91]"
                  />
                  {errors.phone && (
                    <p className="text-xs text-red-600 mt-1">{errors.phone.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1">
                    E-mail <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    {...register('email')}
                    placeholder="seuemail@exemplo.com"
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91]"
                  />
                  {errors.email && (
                    <p className="text-xs text-red-600 mt-1">{errors.email.message}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1">
                    Data Pretendida <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    {...register('preferredDate')}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91]"
                  />
                  {errors.preferredDate && (
                    <p className="text-xs text-red-600 mt-1">{errors.preferredDate.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1">
                    Turno <span className="text-red-500">*</span>
                  </label>
                  <select
                    {...register('period')}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91]"
                  >
                    <option value="tarde">Tarde (14h - 16h)</option>
                    <option value="manha">Manhã (09h - 11h)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1">
                    Nº de Pessoas <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    {...register('visitorCount')}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1">
                  Observações ou motivo da visita (opcional)
                </label>
                <textarea
                  {...register('notes')}
                  rows={2}
                  placeholder="Ex: Gostaria de conhecer para voluntariado, entrega de doações ou interesse institucional..."
                  className="w-full px-3.5 py-2 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] resize-none"
                />
              </div>

              <div className="pt-1">
                <label className="flex items-start gap-2.5 cursor-pointer text-xs text-[#66737A] select-none">
                  <input
                    type="checkbox"
                    {...register('consent')}
                    className="mt-0.5 rounded-sm border-stone-300 text-[#073B91] focus:ring-[#073B91] h-4 w-4"
                  />
                  <span>
                    Concordo em respeitar as normas de convivência, silêncio e protocolos sanitários do Lar durante a visita.
                  </span>
                </label>
                {errors.consent && (
                  <p className="text-xs text-red-600 mt-1">{errors.consent.message}</p>
                )}
              </div>

              <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row gap-2 justify-end">
                <button
                  type="button"
                  onClick={handleClose}
                  className="px-4 py-2.5 text-xs sm:text-sm font-medium text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-colors shadow-xs disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  <span>{isSubmitting ? 'Enviando...' : 'Solicitar agendamento'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
