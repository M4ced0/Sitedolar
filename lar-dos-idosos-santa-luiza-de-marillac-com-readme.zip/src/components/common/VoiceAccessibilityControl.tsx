import React, { useState, useEffect, useRef } from 'react';
import { PageRoute } from '../../types';
import {
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Play,
  Square,
  Sparkles,
  HelpCircle,
  X,
  Compass,
  Heart,
  Calendar,
  Eye,
  Type,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

// SpeechRecognition type declarations for browsers that support it
interface SpeechRecognitionEvent extends Event {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
      isFinal: boolean;
    };
    length: number;
  };
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

interface IWindow extends Window {
  SpeechRecognition?: any;
  webkitSpeechRecognition?: any;
}

interface VoiceAccessibilityControlProps {
  currentPage: PageRoute;
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: () => void;
  onOpenVisitModal: () => void;
  isOpenExternal?: boolean;
  onToggleExternal?: (open: boolean) => void;
}

// Descrições de audiodescrição especialmente redigidas em tom calmo, acolhedor e informativo
const PAGE_DESCRIPTIONS: Record<PageRoute, { title: string; narrative: string }> = {
  home: {
    title: 'Página Inicial do Lar',
    narrative:
      'Você está na página inicial do Lar dos Idosos Santa Luiza de Marillac, uma Instituição de Longa Permanência para Idosos filantrópica em Juiz de Fora, Minas Gerais. Esta casa oferece mais de cinquenta anos de história, dedicação contínua, moradia acolhedora, equipe de enfermagem vinte e quatro horas por dia e seis refeições balanceadas diárias supervisionadas por nutricionista. Na tela, você pode conhecer as instalações, conferir depoimentos reais de famílias, ver as necessidades da Corrente do Bem para doar alimentos ou fraldas, ou agendar uma visita de segunda a sexta-feira.',
  },
  sobre: {
    title: 'Sobre Nós e Nossos Princípios',
    narrative:
      'Você está na página Sobre Nós. Aqui explicamos que o Lar Santa Luiza de Marillac é estritamente uma moradia coletiva e acolhedora para idosos sem fins lucrativos, e não uma clínica médica ou hospital comercial. Nossos pilares são dignidade humana, enfermagem contínua, convivência comunitária fraterna e respeito à individualidade de cada morador. Nossa missão é oferecer proteção social, conforto e carinho diário.',
  },
  'nossa-historia': {
    title: 'Nossa História de Mais de 50 Anos',
    narrative:
      'Você está na página Nossa História. Apresentamos aqui cinco décadas de tradição vicentina, inspiradas em Santa Luísa de Marillac e São Vicente de Paulo. A linha do tempo mostra desde as primeiras iniciativas comunitárias em Juiz de Fora até a consolidação da sede atual com quartos arejados, horta, pátios ensolarados e suporte de saúde contínuo.',
  },
  'corrente-do-bem': {
    title: 'Corrente do Bem e Doações',
    narrative:
      'Você está na página da Corrente do Bem. Aqui você encontra o catálogo visual e transparente de necessidades do Lar. Nossas maiores urgências diárias são fraldas geriátricas tamanhos G e GG, leite integral, itens de higiene pessoal hidratantes e materiais de limpeza. Você pode clicar no botão Quero Doar para escolher um item ou fazer uma contribuição financeira direta por Chave PIX ou transferência bancária.',
  },
  transparencia: {
    title: 'Transparência e Prestação de Contas',
    narrative:
      'Você está na página de Transparência Institucional. Como entidade filantrópica, publicamos balancetes contábeis periódicos, relatórios anuais de atividades e certificações oficiais de assistência social, como o CEBAS. Todos os relatórios podem ser consultados e baixados livremente pela sociedade civil e órgãos fiscalizadores.',
  },
  contato: {
    title: 'Fale Conosco e Localização',
    narrative:
      'Você está na página de Contato. O Lar fica localizado em Juiz de Fora, Minas Gerais, na Rua Furtado de Menezes, no bairro Vila Furtado de Menezes, atendido pelas linhas de ônibus 322, 325 e 399. Nossos telefones fixo e WhatsApp estão disponíveis de segunda a sexta-feira, das oito da manhã às dezessete horas da tarde. Nesta página há também um formulário simples para enviar mensagens sobre informações, doações ou voluntariado, além do botão para abrir as rotas diretamente no Google Maps e no Waze.',
  },
};

export const VoiceAccessibilityControl: React.FC<VoiceAccessibilityControlProps> = ({
  currentPage,
  onNavigate,
  onOpenDonationModal,
  onOpenVisitModal,
  isOpenExternal,
  onToggleExternal,
}) => {
  const [internalPanelOpen, setInternalPanelOpen] = useState(false);
  const isPanelOpen = isOpenExternal !== undefined ? isOpenExternal : internalPanelOpen;
  const setIsPanelOpen = (open: boolean) => {
    setInternalPanelOpen(open);
    onToggleExternal?.(open);
  };
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(0.9); // Levemente mais pausado (0.9x) por padrão para maior compreensão de idosos
  const [isListening, setIsListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(true);
  const [speechRecSupported, setSpeechRecSupported] = useState(false);
  const [lastTranscript, setLastTranscript] = useState<string>('');
  const [commandFeedback, setCommandFeedback] = useState<string>('');
  const [highContrast, setHighContrast] = useState(false);
  const [largeFont, setLargeFont] = useState(false);

  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  // Initialize Speech APIs
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Speech Synthesis check
      if ('speechSynthesis' in window) {
        synthRef.current = window.speechSynthesis;
        setVoiceSupported(true);
      } else {
        setVoiceSupported(false);
      }

      // Speech Recognition check
      const iWin = window as unknown as IWindow;
      const SpeechRecConstructor = iWin.SpeechRecognition || iWin.webkitSpeechRecognition;

      if (SpeechRecConstructor) {
        setSpeechRecSupported(true);
        try {
          const rec = new SpeechRecConstructor();
          rec.continuous = false;
          rec.interimResults = true;
          rec.lang = 'pt-BR';

          rec.onstart = () => {
            setIsListening(true);
            setCommandFeedback('Ouvindo... pode falar agora.');
          };

          rec.onresult = (event: SpeechRecognitionEvent) => {
            const currentResult = event.results[event.results.length - 1];
            const text = currentResult[0].transcript;
            setLastTranscript(text);

            if (currentResult.isFinal) {
              handleVoiceCommand(text);
            }
          };

          rec.onerror = (event: SpeechRecognitionErrorEvent) => {
            console.warn('Speech recognition error:', event.error);
            setIsListening(false);
            if (event.error === 'not-allowed') {
              setCommandFeedback('Acesso ao microfone não permitido. Você pode usar os botões na tela.');
            } else if (event.error === 'no-speech') {
              setCommandFeedback('Nenhuma voz detectada. Clique no microfone para tentar novamente.');
            } else {
              setCommandFeedback('Comando não compreendido. Tente novamente.');
            }
          };

          rec.onend = () => {
            setIsListening(false);
          };

          recognitionRef.current = rec;
        } catch (e) {
          console.warn('Could not initialize speech recognition:', e);
          setSpeechRecSupported(false);
        }
      }
    }

    return () => {
      if (synthRef.current) {
        synthRef.current.cancel();
      }
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (_) {}
      }
    };
  }, []);

  // Update contrast and font classes on root element
  useEffect(() => {
    const root = document.documentElement;
    if (highContrast) {
      root.classList.add('accessibility-high-contrast');
    } else {
      root.classList.remove('accessibility-high-contrast');
    }

    if (largeFont) {
      root.classList.add('accessibility-large-font');
    } else {
      root.classList.remove('accessibility-large-font');
    }
  }, [highContrast, largeFont]);

  // Cancel speech on page navigation
  useEffect(() => {
    if (isSpeaking && synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
      setIsPaused(false);
    }
  }, [currentPage]);

  // Read current page audio description
  const speakNarrative = (textToSpeak?: string) => {
    if (!synthRef.current) return;

    synthRef.current.cancel();

    const text = textToSpeak || PAGE_DESCRIPTIONS[currentPage]?.narrative;
    if (!text) return;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'pt-BR';
    utterance.rate = speechRate;

    // Try finding natural pt-BR voice
    const voices = synthRef.current.getVoices();
    const ptVoice = voices.find((v) => v.lang.startsWith('pt') || v.lang.startsWith('pt-BR'));
    if (ptVoice) {
      utterance.voice = ptVoice;
    }

    utterance.onstart = () => {
      setIsSpeaking(true);
      setIsPaused(false);
    };

    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    synthRef.current.speak(utterance);
  };

  const stopSpeaking = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
      setIsPaused(false);
    }
  };

  const togglePauseSpeech = () => {
    if (!synthRef.current) return;

    if (isSpeaking && !isPaused) {
      synthRef.current.pause();
      setIsPaused(true);
    } else if (isSpeaking && isPaused) {
      synthRef.current.resume();
      setIsPaused(false);
    } else {
      speakNarrative();
    }
  };

  // Toggle Speech Recognition
  const toggleListening = () => {
    if (!recognitionRef.current) return;

    if (isListening) {
      try {
        recognitionRef.current.stop();
      } catch (_) {}
      setIsListening(false);
    } else {
      setLastTranscript('');
      setCommandFeedback('Ouvindo... Fale com clareza (ex: "ir para sobre", "doar", "ouvir página")');
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.warn('Recognition start error:', err);
      }
    }
  };

  // Process voice commands in Brazilian Portuguese
  const handleVoiceCommand = (commandRaw: string) => {
    const cmd = commandRaw.toLowerCase().trim();

    // Feedback speech function
    const sayFeedback = (msg: string) => {
      setCommandFeedback(msg);
      if (synthRef.current) {
        synthRef.current.cancel();
        const utt = new SpeechSynthesisUtterance(msg);
        utt.lang = 'pt-BR';
        utt.rate = speechRate;
        synthRef.current.speak(utt);
      }
    };

    // Navigation rules
    if (cmd.includes('início') || cmd.includes('inicio') || cmd.includes('começo') || cmd.includes('home')) {
      onNavigate('home');
      sayFeedback('Indo para a página inicial.');
      return;
    }

    if (cmd.includes('sobre') || cmd.includes('quem somos') || cmd.includes('instituição')) {
      onNavigate('sobre');
      sayFeedback('Abrindo a página Sobre Nós.');
      return;
    }

    if (cmd.includes('história') || cmd.includes('historia') || cmd.includes('50 anos')) {
      onNavigate('nossa-historia');
      sayFeedback('Abrindo Nossa História.');
      return;
    }

    if (
      cmd.includes('corrente') ||
      cmd.includes('necessidade') ||
      cmd.includes('necessidades') ||
      cmd.includes('itens')
    ) {
      onNavigate('corrente-do-bem');
      sayFeedback('Abrindo a Corrente do Bem.');
      return;
    }

    if (
      cmd.includes('doar') ||
      cmd.includes('doação') ||
      cmd.includes('doacao') ||
      cmd.includes('quero doar') ||
      cmd.includes('pix')
    ) {
      onOpenDonationModal();
      sayFeedback('Abrindo formulário de doação.');
      return;
    }

    if (
      cmd.includes('transparência') ||
      cmd.includes('transparencia') ||
      cmd.includes('contas') ||
      cmd.includes('balanço') ||
      cmd.includes('documentos')
    ) {
      onNavigate('transparencia');
      sayFeedback('Abrindo página de Transparência.');
      return;
    }

    if (
      cmd.includes('contato') ||
      cmd.includes('fale conosco') ||
      cmd.includes('telefone') ||
      cmd.includes('endereço') ||
      cmd.includes('endereco')
    ) {
      onNavigate('contato');
      sayFeedback('Abrindo página de Contato.');
      return;
    }

    if (cmd.includes('visita') || cmd.includes('visitar') || cmd.includes('agendar')) {
      onOpenVisitModal();
      sayFeedback('Abrindo agendamento de visitas.');
      return;
    }

    if (
      cmd.includes('evento') ||
      cmd.includes('eventos') ||
      cmd.includes('calendário') ||
      cmd.includes('calendario') ||
      cmd.includes('atividade') ||
      cmd.includes('atividades') ||
      cmd.includes('bingo') ||
      cmd.includes('festa')
    ) {
      onNavigate('home');
      setTimeout(() => {
        const el = document.getElementById('calendario-eventos');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 350);
      sayFeedback('Abrindo o calendário de eventos e atividades do Lar.');
      return;
    }

    if (
      cmd.includes('instagram') ||
      cmd.includes('fotos da rotina') ||
      cmd.includes('fotos do lar') ||
      cmd.includes('galeria de fotos') ||
      cmd.includes('fotos recentes')
    ) {
      onNavigate('home');
      setTimeout(() => {
        const el = document.getElementById('galeria-instagram');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 350);
      sayFeedback('Abrindo a galeria do Instagram com fotos da rotina do Lar.');
      return;
    }

    if (
      cmd.includes('calculadora') ||
      cmd.includes('calcular doação') ||
      cmd.includes('calcular doacao') ||
      cmd.includes('impacto') ||
      cmd.includes('cesta básica') ||
      cmd.includes('cesta basica') ||
      cmd.includes('kit higiene')
    ) {
      onNavigate('home');
      setTimeout(() => {
        const el = document.getElementById('calculadora-impacto');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 350);
      sayFeedback('Abrindo a Calculadora de Impacto de Doação.');
      return;
    }

    if (
      cmd.includes('ler') ||
      cmd.includes('ouvir') ||
      cmd.includes('descrever') ||
      cmd.includes('áudio') ||
      cmd.includes('audio') ||
      cmd.includes('falar')
    ) {
      speakNarrative();
      setCommandFeedback('Lendo audiodescrição da página.');
      return;
    }

    if (cmd.includes('parar') || cmd.includes('silêncio') || cmd.includes('silencio') || cmd.includes('pausar')) {
      stopSpeaking();
      sayFeedback('Áudio interrompido.');
      return;
    }

    if (cmd.includes('modo escuro') || cmd.includes('tema escuro') || cmd.includes('modo noturno')) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      sayFeedback('Modo escuro ativado para conforto noturno.');
      return;
    }

    if (cmd.includes('modo claro') || cmd.includes('tema claro') || cmd.includes('modo dia')) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      sayFeedback('Modo claro ativado.');
      return;
    }

    if (cmd.includes('ajuda') || cmd.includes('comandos')) {
      const helpMsg =
        'Comandos disponíveis: Início, Sobre Nós, Nossa História, Corrente do Bem, Doar, Transparência, Contato, Agendar Visita, ou Ouvir Página.';
      sayFeedback(helpMsg);
      return;
    }

    // Default unrecognized
    setCommandFeedback(`Não entendi "${commandRaw}". Tente dizer: "Início", "Sobre", "Doar" ou "Ouvir página".`);
  };

  const currentPageInfo = PAGE_DESCRIPTIONS[currentPage];

  return (
    <>
      {/* Botão flutuante de acessibilidade no canto inferior direito */}
      <aside
        aria-label="Painel de acessibilidade e audiodescrição"
        className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2 font-body"
      >
        {/* Banner de áudio ativo quando reproduzindo e painel minimizado */}
        {isSpeaking && !isPanelOpen && (
          <div className="bg-[#073B91] text-white px-4 py-2 rounded-2xl shadow-lg border border-white/20 flex items-center gap-3 animate-in fade-in duration-200">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#76A900] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-[#76A900]"></span>
            </span>
            <span className="text-xs font-medium">Audiodescrição em reprodução...</span>
            <button
              onClick={stopSpeaking}
              className="p-1 hover:bg-white/20 rounded-md transition-colors"
              title="Parar áudio"
              aria-label="Parar áudio da página"
            >
              <Square className="w-3.5 h-3.5 text-white" />
            </button>
          </div>
        )}

        {/* Botão Principal Flutuante: Grande, Constrastado e Acolhedor */}
        <button
          type="button"
          onClick={() => setIsPanelOpen(!isPanelOpen)}
          className={`flex items-center gap-2.5 px-4 py-3 rounded-full shadow-lg border transition-all cursor-pointer focus-visible:outline-hidden focus-visible:ring-4 focus-visible:ring-[#073B91]/40 ${
            isPanelOpen
              ? 'bg-[#073B91] text-white border-[#073B91]'
              : 'bg-white text-[#073B91] hover:bg-[#F5F8F0] border-stone-300 hover:border-[#073B91]'
          }`}
          aria-expanded={isPanelOpen}
          aria-label="Abrir painel de acessibilidade, audiodescrição e comandos de voz"
          title="Acessibilidade por Voz & Audiodescrição para idosos"
        >
          <div className="relative">
            <Volume2 className="w-5 h-5 text-[#76A900]" />
            {isSpeaking && (
              <span className="absolute -top-1 -right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#76A900] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#76A900]"></span>
              </span>
            )}
          </div>
          <span className="font-heading font-bold text-xs sm:text-sm">
            {isPanelOpen ? 'Fechar Acessibilidade' : 'Ouvir Página & Voz'}
          </span>
          {isPanelOpen ? (
            <ChevronDown className="w-4 h-4 text-white/70" />
          ) : (
            <ChevronUp className="w-4 h-4 text-stone-400" />
          )}
        </button>

        {/* Modal / Card Flutuante de Acessibilidade */}
        {isPanelOpen && (
          <div
            role="dialog"
            aria-modal="false"
            aria-label="Controle de Voz e Audiodescrição Institucional"
            className="w-[calc(100vw-32px)] sm:w-[420px] bg-white rounded-3xl shadow-2xl border-2 border-[#073B91]/30 p-5 sm:p-6 mb-2 animate-in fade-in zoom-in-95 duration-200 text-[#27343B]"
          >
            {/* Cabeçalho do Card */}
            <div className="flex items-start justify-between gap-3 border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-[#F5F8F0] rounded-xl text-[#073B91]">
                  <Volume2 className="w-5 h-5 text-[#76A900]" />
                </div>
                <div>
                  <h3 className="font-heading font-bold text-base text-[#073B91]">
                    Audiodescrição & Voz
                  </h3>
                  <p className="text-[11px] text-[#66737A]">
                    Projetado para facilitar a navegação de idosos
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsPanelOpen(false)}
                className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
                aria-label="Fechar painel de voz"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* SEÇÃO 1: AUDIODESCRIÇÃO DA PÁGINA ATUAL */}
            <div className="mt-4 p-4 rounded-2xl bg-[#F5F8F0] border border-stone-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#073B91] uppercase tracking-wide flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#76A900]" />
                  <span>{currentPageInfo.title}</span>
                </span>
                <span className="text-[11px] font-mono text-stone-500 bg-white px-2 py-0.5 rounded border border-stone-200">
                  {speechRate}x velocidade
                </span>
              </div>

              <p className="text-xs text-[#66737A] leading-relaxed line-clamp-3">
                {currentPageInfo.narrative}
              </p>

              {/* Controles de Reprodução de Áudio */}
              <div className="pt-1 flex flex-wrap items-center gap-2">
                {!isSpeaking ? (
                  <button
                    type="button"
                    onClick={() => speakNarrative()}
                    className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-4 bg-[#073B91] hover:bg-[#052c6e] text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors shadow-xs cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>Ouvir esta página agora</span>
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={togglePauseSpeech}
                      className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-4 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
                    >
                      {isPaused ? <Play className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      <span>{isPaused ? 'Continuar Áudio' : 'Pausar Áudio'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={stopSpeaking}
                      className="inline-flex items-center justify-center gap-1.5 py-2.5 px-3 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                      title="Parar áudio"
                    >
                      <Square className="w-3.5 h-3.5" />
                      <span>Parar</span>
                    </button>
                  </>
                )}

                {/* Seletor de Ritmo de Voz */}
                <div className="w-full flex items-center justify-between text-[11px] text-[#66737A] pt-1">
                  <span>Ritmo de fala:</span>
                  <div className="flex gap-1">
                    {[
                      { rate: 0.8, label: '0.8x Mais Pausado' },
                      { rate: 0.9, label: '0.9x Padrão' },
                      { rate: 1.0, label: '1.0x Normal' },
                    ].map((item) => (
                      <button
                        key={item.rate}
                        type="button"
                        onClick={() => {
                          setSpeechRate(item.rate);
                          if (isSpeaking) {
                            speakNarrative();
                          }
                        }}
                        className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors cursor-pointer ${
                          speechRate === item.rate
                            ? 'bg-[#073B91] text-white font-semibold'
                            : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* SEÇÃO 2: COMANDOS DE NAVEGAÇÃO POR VOZ */}
            <div className="mt-4 border-t border-stone-200 pt-4 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-heading font-bold text-xs sm:text-sm text-[#073B91] flex items-center gap-1.5">
                  <Mic className="w-4 h-4 text-[#76A900]" />
                  <span>Comandos de Voz</span>
                </h4>
                {speechRecSupported ? (
                  <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Disponível no navegador
                  </span>
                ) : (
                  <span className="text-[10px] text-stone-500 font-medium bg-stone-100 px-2 py-0.5 rounded">
                    Atalhos manuais ativos
                  </span>
                )}
              </div>

              {speechRecSupported ? (
                <div>
                  <button
                    type="button"
                    onClick={toggleListening}
                    className={`w-full py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                      isListening
                        ? 'bg-rose-600 text-white animate-pulse shadow-md'
                        : 'bg-white hover:bg-stone-100 text-[#073B91] border-2 border-[#073B91]'
                    }`}
                  >
                    {isListening ? (
                      <>
                        <MicOff className="w-4 h-4 text-white" />
                        <span>Ouvindo... Clique para finalizar</span>
                      </>
                    ) : (
                      <>
                        <Mic className="w-4 h-4 text-[#76A900]" />
                        <span>Falar um Comando de Voz</span>
                      </>
                    )}
                  </button>

                  {/* Feedback do Comando Falado */}
                  {(commandFeedback || lastTranscript) && (
                    <div className="mt-2.5 p-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs">
                      {lastTranscript && (
                        <p className="text-[#073B91] font-medium font-mono text-[11px]">
                          Você disse: "{lastTranscript}"
                        </p>
                      )}
                      {commandFeedback && (
                        <p className="text-[#27343B] mt-0.5 font-medium">{commandFeedback}</p>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800">
                  <p>
                    Reconhecimento de voz contínuo não suportado neste navegador. Utilize os botões rápidos de audiodescrição e atalhos abaixo.
                  </p>
                </div>
              )}

              {/* Botões de Ação Rápida por Toque Fácil (Tamanho Grande para limitação motora) */}
              <div className="pt-1">
                <span className="text-[11px] font-semibold text-[#66737A] block mb-1.5">
                  Navegação rápida acessível com 1 toque:
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => {
                      onNavigate('home');
                      speakNarrative(PAGE_DESCRIPTIONS.home.narrative);
                    }}
                    className="p-2.5 rounded-xl bg-white hover:bg-[#F5F8F0] border border-stone-200 text-[#27343B] text-left transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <Compass className="w-3.5 h-3.5 text-[#073B91] shrink-0" />
                    <span>Início</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onNavigate('sobre');
                      speakNarrative(PAGE_DESCRIPTIONS.sobre.narrative);
                    }}
                    className="p-2.5 rounded-xl bg-white hover:bg-[#F5F8F0] border border-stone-200 text-[#27343B] text-left transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#073B91] shrink-0" />
                    <span>Sobre Nós</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onNavigate('corrente-do-bem');
                      speakNarrative(PAGE_DESCRIPTIONS['corrente-do-bem'].narrative);
                    }}
                    className="p-2.5 rounded-xl bg-white hover:bg-[#F5F8F0] border border-stone-200 text-[#27343B] text-left transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <Heart className="w-3.5 h-3.5 text-[#76A900] shrink-0" />
                    <span>Corrente do Bem</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onOpenDonationModal();
                      speakNarrative('Abrindo a tela de doação para o Lar Santa Luiza de Marillac.');
                    }}
                    className="p-2.5 rounded-xl bg-white hover:bg-[#F5F8F0] border border-stone-200 text-[#76A900] text-left transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <Heart className="w-3.5 h-3.5 fill-[#76A900]/20 shrink-0" />
                    <span>Fazer Doação</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onNavigate('contato');
                      speakNarrative(PAGE_DESCRIPTIONS.contato.narrative);
                    }}
                    className="p-2.5 rounded-xl bg-white hover:bg-[#F5F8F0] border border-stone-200 text-[#27343B] text-left transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <HelpCircle className="w-3.5 h-3.5 text-[#073B91] shrink-0" />
                    <span>Fale Conosco</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onOpenVisitModal();
                      speakNarrative('Abrindo a tela para agendar uma visita guiada ao Lar.');
                    }}
                    className="p-2.5 rounded-xl bg-white hover:bg-[#F5F8F0] border border-stone-200 text-[#073B91] text-left transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <Calendar className="w-3.5 h-3.5 shrink-0" />
                    <span>Agendar Visita</span>
                  </button>
                </div>
              </div>
            </div>

            {/* SEÇÃO 3: AJUSTES VISUAIS COMPLEMENTARES */}
            <div className="mt-4 pt-3 border-t border-stone-200 flex items-center justify-between text-xs">
              <span className="text-[#66737A] font-medium">Ajustes Visuais:</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setLargeFont(!largeFont)}
                  className={`px-2.5 py-1 rounded-lg border font-semibold transition-colors cursor-pointer flex items-center gap-1 ${
                    largeFont
                      ? 'bg-[#073B91] text-white border-[#073B91]'
                      : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                  }`}
                  title="Aumentar tamanho das letras do site"
                >
                  <Type className="w-3.5 h-3.5" />
                  <span>Letra Maior {largeFont ? '(Ligado)' : ''}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHighContrast(!highContrast)}
                  className={`px-2.5 py-1 rounded-lg border font-semibold transition-colors cursor-pointer flex items-center gap-1 ${
                    highContrast
                      ? 'bg-[#27343B] text-white border-[#27343B]'
                      : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                  }`}
                  title="Ativar alto contraste visual"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Contraste {highContrast ? '(Ligado)' : ''}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </aside>
    </>
  );
};
