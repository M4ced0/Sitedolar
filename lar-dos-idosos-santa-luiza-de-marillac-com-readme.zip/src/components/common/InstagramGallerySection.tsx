import React, { useState, useEffect, useCallback, useId } from 'react';
import {
  Instagram,
  Heart,
  MessageCircle,
  Share2,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  X,
  Send,
  Check,
  Sparkles,
  Camera,
  MapPin,
  Clock,
  UserCheck,
  Bookmark,
  Smile,
  ShieldCheck,
  Flower2,
  Music,
  Coffee,
  Activity,
  Users,
  Image as ImageIcon,
} from 'lucide-react';
import { INSTITUTION_INFO } from '../../data/institutionalData';
import { notifySuccess } from '../../utils/notifications';

export type InstagramCategory = 'todas' | 'rotina' | 'oficinas' | 'eventos' | 'horta';

export interface InstagramComment {
  id: string;
  author: string;
  text: string;
  timeAgo: string;
  isVolunteer?: boolean;
}

export interface InstagramPost {
  id: string;
  imageUrl: string;
  altText: string;
  category: 'rotina' | 'oficinas' | 'eventos' | 'horta';
  categoryLabel: string;
  caption: string;
  hashtags: string[];
  location: string;
  timeAgo: string;
  likesCount: number;
  commentsCount: number;
  comments: InstagramComment[];
}

export const INSTAGRAM_POSTS: InstagramPost[] = [
  {
    id: 'insta-post-1',
    imageUrl: '', // Wireframe: Inserir foto do post 1 (800x800px)
    altText: 'Idoso sorridente cuidando de canteiro na horta suspensa com mudas verdes',
    category: 'horta',
    categoryLabel: 'Horta & Natureza',
    caption:
      '“A terra nos ensina a ter paciência e amor pelo tempo de florescer.” 🌿 Seu Benedito e Dona Geraldinha cuidando com carinho das mudas de hortelã, alecrim e camomila na nossa horta suspensa adaptada. Momentos de conexão, cheiro de mato e muita paz aqui na Vila Furtado de Menezes.',
    hashtags: [
      '#LarSantaLuizadeMarillac',
      '#JuizDeFora',
      '#HortaTerapêutica',
      '#CuidadoAoIdoso',
      '#LongevidadeAtiva',
    ],
    location: 'Horta Sensorial Suspensa · Lar Santa Luiza de Marillac',
    timeAgo: 'Há 2 dias',
    likesCount: 184,
    commentsCount: 14,
    comments: [
      {
        id: 'c1-1',
        author: 'mariaclara.jf',
        text: 'Que lindeza ver o sorriso do Seu Benedito! Essa horta faz um bem enorme para todos eles.',
        timeAgo: 'Há 2 dias',
        isVolunteer: false,
      },
      {
        id: 'c1-2',
        author: 'voluntarios.vicentinos',
        text: 'Parabéns à equipe pelo cuidado de manter os canteiros elevados e acessíveis aos cadeirantes! Trabalho exemplar.',
        timeAgo: 'Há 1 dia',
        isVolunteer: true,
      },
      {
        id: 'c1-3',
        author: 'terapeuta.camila',
        text: 'A estimulação sensorial pelo aroma das ervas é fantástica para a memória afetiva!',
        timeAgo: 'Há 18 horas',
        isVolunteer: true,
      },
    ],
  },
  {
    id: 'insta-post-2',
    imageUrl: '', // Wireframe: Inserir foto do post 2 (800x800px)
    altText: 'Residentes reunidos no café da tarde com broa de milho e café fresco',
    category: 'rotina',
    categoryLabel: 'Rotina & Convivência',
    caption:
      'Final de tarde em Minas Gerais tem que ter café passado na hora, broa de milho quentinha e aquele pão de queijo crocante feito com todo amor pela nossa equipe de nutrição. Aqui, cada refeição é momento de conversa fraterna e afeto compartilhado! ☕🧀',
    hashtags: [
      '#CaféComAfeto',
      '#ComidaMineira',
      '#LarDosIdosos',
      '#JuizDeForaMG',
      '#NutriçãoGerontológica',
    ],
    location: 'Refeitório Comunitário · Lar Santa Luiza',
    timeAgo: 'Há 4 dias',
    likesCount: 236,
    commentsCount: 19,
    comments: [
      {
        id: 'c2-1',
        author: 'anapaula_silva_jf',
        text: 'Minha mãe sempre me conta com tanto carinho do café da tarde de vocês! Obrigado pelo cuidado.',
        timeAgo: 'Há 4 dias',
      },
      {
        id: 'c2-2',
        author: 'nutri.daniela',
        text: 'Cardápio balanceado, adaptado e cheio de afeto que aquece a alma de quem já viveu tanto!',
        timeAgo: 'Há 3 dias',
        isVolunteer: true,
      },
    ],
  },
  {
    id: 'insta-post-3',
    imageUrl: '', // Wireframe: Inserir foto do post 3 (800x800px)
    altText: 'Violão e roda musical de serenata no pátio com moradores cantando juntos',
    category: 'eventos',
    categoryLabel: 'Eventos & Música',
    caption:
      'Quando o som do violão começa a tocar no pátio sob a sombra das árvores, os olhos dos nossos moradores brilham! 🎶 Modas de viola, serenatas e cantigas de época que resgatam as mais doces memórias de juventude. Gratidão aos voluntários que doam seu talento e tempo para alegrar nossos dias!',
    hashtags: [
      '#Musicoterapia',
      '#MemóriaAfetiva',
      '#VoluntariadoJF',
      '#SerenataMineira',
      '#LarSantaLuiza',
    ],
    location: 'Pátio das Jabuticabeiras · Lar Santa Luiza de Marillac',
    timeAgo: 'Há 6 dias',
    likesCount: 312,
    commentsCount: 28,
    comments: [
      {
        id: 'c3-1',
        author: 'felipe.violao',
        text: 'Tocar para eles foi uma das experiências mais marcantes da minha vida. Quero voltar toda semana!',
        timeAgo: 'Há 5 dias',
        isVolunteer: true,
      },
      {
        id: 'c3-2',
        author: 'roberta_rezende',
        text: 'Que momento abençoado! Meu avô amava essas canções antigas.',
        timeAgo: 'Há 4 dias',
      },
    ],
  },
  {
    id: 'insta-post-4',
    imageUrl: '', // Wireframe: Inserir foto do post 4 (800x800px)
    altText: 'Mãos de idosa tecendo crochê colorido em manta de lã macia',
    category: 'oficinas',
    categoryLabel: 'Oficinas & Saúde',
    caption:
      'As mãos que tanto trabalharam continuam tecendo arte, carinho e aconchego. 🧶 Na nossa oficina semanal de artesanato, Dona Lourdes e Dona Geraldinha produzem mantas e toucas em crochê que aquecem os colegas e enfeitam o Lar. A concentração e a coordenação motora agradecem!',
    hashtags: [
      '#TerapiaOcupacional',
      '#ArtesanatoSênior',
      '#CrochêSolidário',
      '#JuizDeFora',
      '#EstimulaçãoMotora',
    ],
    location: 'Salão de Convivência & Artesanato',
    timeAgo: 'Há 1 semana',
    likesCount: 198,
    commentsCount: 16,
    comments: [
      {
        id: 'c4-1',
        author: 'lucia_artesanato',
        text: 'Que pontos perfeitos! O trabalho manual é um remédio poderoso para a mente.',
        timeAgo: 'Há 6 dias',
      },
      {
        id: 'c4-2',
        author: 'carolina.enfermagem',
        text: 'Trabalho lindo que ajuda muito na preservação da mobilidade fina das mãos!',
        timeAgo: 'Há 5 dias',
        isVolunteer: true,
      },
    ],
  },
  {
    id: 'insta-post-5',
    imageUrl: '', // Wireframe: Inserir foto do post 5 (800x800px)
    altText: 'Retrato de idoso sorridente concentrado no jogo amigável de dominó',
    category: 'rotina',
    categoryLabel: 'Rotina & Convivência',
    caption:
      'Concentração máxima e boas risadas no nosso campeonato vespertino de dominó! 🁓🁙 Aqui a amizade fala mais alto que qualquer vitória. Jogos de tabuleiro estimulam o raciocínio rápido, a atenção e, acima de tudo, a convivência entre irmãos de caminhada.',
    hashtags: [
      '#DominóNaTerceiraIdade',
      '#EstímuloCognitivo',
      '#AmizadeSemIdade',
      '#LarSãoMateus',
      '#JuizDeForaMG',
    ],
    location: 'Salão de Jogos e Lazer · Juiz de Fora',
    timeAgo: 'Há 1 semana',
    likesCount: 167,
    commentsCount: 12,
    comments: [
      {
        id: 'c5-1',
        author: 'marcos.antonio_jf',
        text: 'Seu Zé não perde uma partida! Mestre do dominó!',
        timeAgo: 'Há 1 semana',
      },
      {
        id: 'c5-2',
        author: 'beatriz_to',
        text: 'Atividades lúdicas em grupo fazem toda a diferença na saúde mental.',
        timeAgo: 'Há 6 dias',
        isVolunteer: true,
      },
    ],
  },
  {
    id: 'insta-post-6',
    imageUrl: '', // Wireframe: Inserir foto do post 6 (800x800px)
    altText: 'Dona Lourdinha lendo tranquilamente na varanda ensolarada',
    category: 'rotina',
    categoryLabel: 'Rotina & Convivência',
    caption:
      'Dona Lourdinha aproveitando a brisa suave e a claridade natural para ler seus livros de poesia. O silêncio acolhedor, a segurança e o respeito ao ritmo próprio de cada morador são pilares inegociáveis do nosso Lar. 📖🌸',
    hashtags: [
      '#LeituraNaTerceiraIdade',
      '#PazDeEspírito',
      '#DignidadeHumana',
      '#LarSantaLuizaDeMarillac',
      '#JuizDeFora',
    ],
    location: 'Jardim dos Ipês · Lar Santa Luiza de Marillac',
    timeAgo: 'Há 10 dias',
    likesCount: 215,
    commentsCount: 18,
    comments: [
      {
        id: 'c6-1',
        author: 'professora.helena',
        text: 'Dona Lourdinha foi minha professora há 40 anos! Que emoção ver ela tão bem cuidada e lendo com esse brilho no olhar.',
        timeAgo: 'Há 9 dias',
      },
      {
        id: 'c6-2',
        author: 'associacao.vicentina',
        text: 'Um exemplo vivo de dedicação à educação que hoje recebe o carinho merecido.',
        timeAgo: 'Há 8 dias',
        isVolunteer: true,
      },
    ],
  },
  {
    id: 'insta-post-7',
    imageUrl: '', // Wireframe: Inserir foto do post 7 (800x800px)
    altText: 'Sessão de fisioterapia preventiva com fisioterapeuta auxiliando idoso com faixas',
    category: 'oficinas',
    categoryLabel: 'Oficinas & Saúde',
    caption:
      'Mobilidade e autonomia preservadas todos os dias! Nossos fisioterapeutas conduzem circuitos suaves de equilíbrio, fortalecimento e alongamento. Cuidar preventivamente é assegurar que cada idoso caminhe com confiança e alegria. 🩺🏃‍♀️',
    hashtags: [
      '#FisioterapiaGeriátrica',
      '#PrevençãoDeQuedas',
      '#SaúdeDoIdoso',
      '#UFJF',
      '#LarSantaLuiza',
    ],
    location: 'Sala de Fisioterapia e Reabilitação',
    timeAgo: 'Há 2 semanas',
    likesCount: 174,
    commentsCount: 11,
    comments: [
      {
        id: 'c7-1',
        author: 'dr.marcelo_geriatra',
        text: 'Trabalho de manutenção motora impecável! Parabéns a toda a equipe técnica.',
        timeAgo: 'Há 13 dias',
      },
      {
        id: 'c7-2',
        author: 'patricia_enfermeira',
        text: 'Cuidado integrado de enfermagem e fisioterapia faz toda a diferença.',
        timeAgo: 'Há 12 dias',
        isVolunteer: true,
      },
    ],
  },
  {
    id: 'insta-post-8',
    imageUrl: '', // Wireframe: Inserir foto do post 8 (800x800px)
    altText: 'Celebração comemorativa com mesa enfeitada e flores no pátio ensolarado',
    category: 'eventos',
    categoryLabel: 'Eventos & Música',
    caption:
      'Comemorar a vida é o maior presente que podemos dar! 🎂 Tarde de celebração dos aniversariantes do mês com bolo confeitado pela equipe de nutrição, balões e a presença querida dos familiares e voluntários vicentinos. Viva cada história de vida do Lar!',
    hashtags: [
      '#AniversariantesDoMês',
      '#CelebraçãoDaVida',
      '#FamíliaVicentina',
      '#AmorAoPróximo',
      '#JuizDeFora',
    ],
    location: 'Pátio Central · Juiz de Fora (MG)',
    timeAgo: 'Há 2 semanas',
    likesCount: 289,
    commentsCount: 37,
    comments: [
      {
        id: 'c8-1',
        author: 'familia_oliveira_jf',
        text: 'Obrigado por proporcionarem um dia tão feliz e digno para os nossos idosos!',
        timeAgo: 'Há 2 semanas',
      },
      {
        id: 'c8-2',
        author: 'voluntaria_claudia',
        text: 'O abraço de cada um deles vale mais que qualquer coisa no mundo!',
        timeAgo: 'Há 2 semanas',
        isVolunteer: true,
      },
    ],
  },
];

interface InstagramGallerySectionProps {
  onOpenVisitModal?: () => void;
  onOpenDonationModal?: () => void;
}

export const InstagramGallerySection: React.FC<InstagramGallerySectionProps> = ({
  onOpenVisitModal,
  onOpenDonationModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<InstagramCategory>('todas');
  const [activePost, setActivePost] = useState<InstagramPost | null>(null);
  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});
  const [userLikesCount, setUserLikesCount] = useState<Record<string, number>>({});
  const [customComments, setCustomComments] = useState<Record<string, InstagramComment[]>>({});
  const [newCommentText, setNewCommentText] = useState('');
  const [newCommentAuthor, setNewCommentAuthor] = useState('');
  const [commentSuccess, setCommentSuccess] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);
  const [imageErrorMap, setImageErrorMap] = useState<Record<string, boolean>>({});

  const commentInputId = useId();
  const authorInputId = useId();

  // Filter posts
  const filteredPosts = INSTAGRAM_POSTS.filter((post) => {
    if (selectedCategory === 'todas') return true;
    return post.category === selectedCategory;
  });

  // Handle Like toggle
  const handleToggleLike = (postId: string, initialLikes: number) => {
    setLikedPosts((prev) => {
      const isCurrentlyLiked = !!prev[postId];
      const nextLiked = !isCurrentlyLiked;

      setUserLikesCount((counts) => {
        const currentCount = counts[postId] ?? initialLikes;
        return {
          ...counts,
          [postId]: nextLiked ? currentCount + 1 : currentCount - 1,
        };
      });

      return {
        ...prev,
        [postId]: nextLiked,
      };
    });
  };

  // Handle Add Comment
  const handleAddComment = (e: React.FormEvent, postId: string) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const authorName = newCommentAuthor.trim() || 'Visitante Solidário';
    const newComment: InstagramComment = {
      id: `c-user-${Date.now()}`,
      author: authorName,
      text: newCommentText.trim(),
      timeAgo: 'Agora mesmo',
      isVolunteer: false,
    };

    setCustomComments((prev) => ({
      ...prev,
      [postId]: [...(prev[postId] || []), newComment],
    }));

    setNewCommentText('');
    setCommentSuccess(true);
    notifySuccess('Mensagem de carinho enviada com sucesso aos nossos residentes!');
    setTimeout(() => setCommentSuccess(false), 3000);
  };

  // Lightbox Navigation
  const handlePrevPost = useCallback(() => {
    if (!activePost) return;
    const currentIndex = filteredPosts.findIndex((p) => p.id === activePost.id);
    if (currentIndex > 0) {
      setActivePost(filteredPosts[currentIndex - 1]);
    } else {
      setActivePost(filteredPosts[filteredPosts.length - 1]);
    }
  }, [activePost, filteredPosts]);

  const handleNextPost = useCallback(() => {
    if (!activePost) return;
    const currentIndex = filteredPosts.findIndex((p) => p.id === activePost.id);
    if (currentIndex < filteredPosts.length - 1) {
      setActivePost(filteredPosts[currentIndex + 1]);
    } else {
      setActivePost(filteredPosts[0]);
    }
  }, [activePost, filteredPosts]);

  // Keyboard navigation for Lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!activePost) return;
      if (e.key === 'Escape') setActivePost(null);
      if (e.key === 'ArrowLeft') handlePrevPost();
      if (e.key === 'ArrowRight') handleNextPost();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activePost, handlePrevPost, handleNextPost]);

  // Share post via WhatsApp or Copy link
  const handleSharePost = (post: InstagramPost) => {
    const text = encodeURIComponent(
      `Veja esta foto do cotidiano no Lar dos Idosos Santa Luiza de Marillac (Juiz de Fora - MG):\n\n"${post.caption}"\n\nAcompanhe no Instagram @larluizademarillac!`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleCopyPostLink = () => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(INSTITUTION_INFO.instagramUrl);
      setShareSuccess(true);
      notifySuccess('Link do perfil oficial do Instagram copiado!');
      setTimeout(() => setShareSuccess(false), 2500);
    }
  };

  return (
    <section
      id="galeria-instagram"
      className="py-16 sm:py-24 bg-gradient-to-b from-[#FAFBF7] via-[#F2F7EC]/60 to-[#FAFBF7] border-t border-stone-200/80 scroll-mt-20"
      aria-label="Galeria do Instagram do Lar Santa Luiza de Marillac"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* =========================================================================
            HEADER DA SEÇÃO: INSTITUCIONAL & DIÁLOGO COM A COMUNIDADE
            ========================================================================= */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 pb-8 border-b border-stone-200">
          <div className="space-y-3 max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#073B91] font-body block">
              Cotidiano & Memória Afetiva
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#27343B] tracking-tight leading-tight">
              O Dia a Dia no Instagram do Lar
            </h2>
            <p className="text-base text-[#66737A] font-body leading-relaxed">
              Acompanhe as fotos recentes, oficinas terapêuticas, passeios nos jardins e momentos de convivência que preenchem de dignidade e alegria a rotina dos nossos 42 idosos residentes.
            </p>
          </div>

          {/* Institutional Instagram Profile Card Ribbon */}
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/90 shadow-2xs flex items-center gap-4 shrink-0">
            {/* Avatar with gradient ring */}
            <div className="relative">
              <div className="w-13 h-13 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center shadow-xs">
                <div className="w-full h-full rounded-full bg-white p-0.5 flex items-center justify-center overflow-hidden">
                  <div className="w-full h-full rounded-full bg-[#073B91] flex items-center justify-center text-white font-heading font-bold text-base">
                    LM
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-1 -right-1 bg-gradient-to-tr from-pink-500 to-purple-600 text-white rounded-full p-1 shadow-2xs">
                <Instagram className="w-3 h-3" />
              </div>
            </div>

            {/* Profile Info */}
            <div className="space-y-1">
              <div className="flex items-center gap-1.5">
                <span className="font-heading font-bold text-sm text-[#27343B]">
                  {INSTITUTION_INFO.instagram}
                </span>
                <span title="Perfil Institucional Verificado">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#073B91]" />
                </span>
              </div>
              <div className="text-[11px] text-stone-500 font-body">
                <span>548 publicações</span>
                <span className="mx-1.5">·</span>
                <span>4.850 seguidores</span>
              </div>
              <a
                href={INSTITUTION_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#073B91] hover:text-[#052c6e] hover:underline pt-0.5"
              >
                <span>Ver perfil oficial</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        {/* =========================================================================
            FILTROS DE CATEGORIA & BOTÃO SEGUIR
            ========================================================================= */}
        <div className="mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          {/* Segmented Filter Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {(
              [
                { id: 'todas', label: 'Todas as Fotos' },
                { id: 'rotina', label: 'Rotina & Convivência' },
                { id: 'oficinas', label: 'Oficinas & Saúde' },
                { id: 'eventos', label: 'Música & Festas' },
                { id: 'horta', label: 'Horta & Natureza' },
              ] as Array<{ id: InstagramCategory; label: string }>
            ).map((cat) => {
              const isActive = selectedCategory === cat.id;
              const count =
                cat.id === 'todas'
                  ? INSTAGRAM_POSTS.length
                  : INSTAGRAM_POSTS.filter((p) => p.category === cat.id).length;

              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                      : 'bg-stone-50 text-stone-600 border border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span
                    className={`text-[11px] px-1.5 py-0.2 rounded font-mono ${
                      isActive ? 'bg-white/20 text-white' : 'bg-stone-200/80 text-stone-500'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Quick Instagram Action */}
          <div className="flex items-center gap-2">
            <a
              href={INSTITUTION_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 hover:opacity-95 rounded-lg transition-all shadow-2xs font-body"
            >
              <Instagram className="w-3.5 h-3.5" />
              <span>Seguir @larsantaluizademarillac</span>
            </a>
          </div>
        </div>

        {/* =========================================================================
            GRID DE FOTOS DO INSTAGRAM (FEED EM QUADRADO 1:1)
            ========================================================================= */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 lg:gap-5">
          {filteredPosts.map((post) => {
            const isLiked = !!likedPosts[post.id];
            const displayLikes = userLikesCount[post.id] ?? post.likesCount;
            const extraComments = customComments[post.id] || [];
            const displayCommentsCount = post.commentsCount + extraComments.length;
            const hasError = imageErrorMap[post.id];

            return (
              <div
                key={post.id}
                onClick={() => setActivePost(post)}
                className="group relative aspect-square bg-stone-100 rounded-2xl overflow-hidden border border-stone-200/80 shadow-2xs cursor-pointer select-none transition-all duration-200 hover:shadow-md"
              >
                {/* Wireframe Placeholder for Instagram Post */}
                <div className="w-full h-full bg-slate-100 p-4 flex flex-col justify-between text-slate-700 border-2 border-dashed border-slate-300 group-hover:border-emerald-400 group-hover:bg-emerald-50/20 transition-all">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200">
                      <Camera className="w-3 h-3 text-slate-400" />
                      <span>Wireframe</span>
                    </span>
                    <span className="font-mono text-[10px]">{post.timeAgo}</span>
                  </div>
                  <div className="space-y-1.5 my-auto text-center py-2">
                    <div className="w-10 h-10 mx-auto rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-400 shadow-2xs group-hover:text-emerald-600 group-hover:border-emerald-300">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-bold text-[#073B91] block uppercase tracking-wider">
                      {post.categoryLabel}
                    </span>
                    <p className="text-xs font-medium line-clamp-2 text-slate-600">
                      {post.caption}
                    </p>
                    <span className="text-[9px] font-mono text-slate-400 bg-white/70 px-1.5 py-0.5 rounded border border-slate-200 inline-block">
                      800 × 800 px
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 flex items-center justify-between font-mono pt-2 border-t border-slate-200">
                    <span>❤️ {displayLikes}</span>
                    <span>💬 {displayCommentsCount}</span>
                  </div>
                </div>

                {/* Subtle top indicator */}
                <div className="absolute top-2.5 right-2.5 bg-black/40 backdrop-blur-xs text-white p-1 rounded-md opacity-90 transition-opacity">
                  <Camera className="w-3.5 h-3.5" />
                </div>

                {/* Hover Overlay with Stats (Instagram Style) */}
                <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex flex-col justify-between p-4 text-white">
                  <div className="flex items-center justify-between text-[11px] text-white/80 font-body">
                    <span>{post.categoryLabel}</span>
                    <span className="font-mono">{post.timeAgo}</span>
                  </div>

                  <p className="text-xs line-clamp-3 text-white/95 font-body leading-relaxed">
                    {post.caption}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-white/20 text-xs font-mono">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <Heart
                          className={`w-3.5 h-3.5 ${
                            isLiked ? 'fill-red-500 text-red-500' : 'fill-white/30 text-white'
                          }`}
                        />
                        <span>{displayLikes}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="w-3.5 h-3.5 text-white" />
                        <span>{displayCommentsCount}</span>
                      </span>
                    </div>
                    <span className="text-[10px] text-blue-200 font-semibold tracking-wider uppercase">
                      Abrir foto
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* =========================================================================
            BOTTOM STRIP: CONVITE DE PARTICIPAÇÃO
            ========================================================================= */}
        <div className="mt-12 p-6 bg-stone-50 rounded-2xl border border-stone-200/90 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="font-heading font-bold text-base text-[#27343B]">
              Quer compartilhar carinho ou nos marcar no Instagram?
            </h4>
            <p className="text-xs text-[#66737A] font-body">
              Use a hashtag <strong className="text-[#073B91]">#LarLuizadeMarillac</strong> ou marque <strong className="text-[#073B91]">@larluizademarillac</strong> em suas visitas e ações solidárias.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleCopyPostLink}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 hover:bg-stone-100 rounded-lg transition-colors font-body cursor-pointer"
            >
              {shareSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">Link copiado!</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Compartilhar Perfil</span>
                </>
              )}
            </button>
            <a
              href={INSTITUTION_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-colors font-body"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Abrir no App</span>
            </a>
          </div>
        </div>
      </div>

      {/* =========================================================================
          LIGHTBOX MODAL ESTILO INSTAGRAM (DETALHES, COMENTÁRIOS, INTERAÇÃO)
          ========================================================================= */}
      {activePost && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Publicação do Instagram"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
          onClick={() => setActivePost(null)}
        >
          {/* Navigation Chevron Left */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handlePrevPost();
            }}
            aria-label="Foto anterior"
            className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 p-3 text-white/80 hover:text-white bg-black/40 hover:bg-black/60 rounded-full transition-colors cursor-pointer z-50"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Navigation Chevron Right */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleNextPost();
            }}
            aria-label="Próxima foto"
            className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 p-3 text-white/80 hover:text-white bg-black/40 hover:bg-black/60 rounded-full transition-colors cursor-pointer z-50"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Lightbox Container Box */}
          <div
            className="bg-white rounded-3xl max-w-4xl w-full border border-stone-200 shadow-2xl overflow-hidden relative my-auto grid grid-cols-1 md:grid-cols-12 max-h-[92vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button Mobile/Desktop */}
            <button
              type="button"
              onClick={() => setActivePost(null)}
              aria-label="Fechar visualizador"
              className="absolute top-4 right-4 z-20 p-2 text-stone-500 hover:text-stone-800 bg-white/90 hover:bg-white rounded-full shadow-md transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Left Column: Wireframe Modal Slot (md:col-span-7) */}
            <div className="md:col-span-7 bg-slate-900 flex items-center justify-center relative min-h-[300px] md:min-h-[540px] p-8">
              <div className="p-8 text-center text-slate-300 space-y-4 max-w-md border-2 border-dashed border-slate-700 rounded-2xl bg-slate-800/80">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-700/80 border border-slate-600 flex items-center justify-center text-sky-400 shadow-lg">
                  <Camera className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-sky-400 block mb-1">
                    [Espaço Wireframe · Instagram]
                  </span>
                  <p className="font-heading font-semibold text-base text-white">
                    {activePost.altText}
                  </p>
                  <p className="text-xs text-slate-400 font-body mt-1">
                    {activePost.location}
                  </p>
                </div>
                <div className="pt-2">
                  <span className="text-[11px] font-mono text-slate-400 bg-slate-900/80 px-3 py-1 rounded border border-slate-700">
                    Dimensão recomendada: 1080 × 1080 px
                  </span>
                </div>
              </div>
            </div>

            {/* Right Column: Instagram Post Details & Feed (md:col-span-5) */}
            <div className="md:col-span-5 flex flex-col justify-between bg-white border-l border-stone-200 h-full max-h-[560px] overflow-hidden">
              {/* Header */}
              <div className="p-4 border-b border-stone-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 p-0.5">
                    <div className="w-full h-full rounded-full bg-[#073B91] text-white flex items-center justify-center font-bold text-xs font-heading">
                      LM
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="font-heading font-bold text-xs text-[#27343B]">
                        {INSTITUTION_INFO.shortName}
                      </span>
                      <ShieldCheck className="w-3.5 h-3.5 text-[#073B91]" />
                    </div>
                    <span className="text-[11px] text-stone-500 font-body block truncate max-w-[190px]">
                      {activePost.location}
                    </span>
                  </div>
                </div>

                <a
                  href={INSTITUTION_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold text-[#073B91] hover:underline whitespace-nowrap pr-6 md:pr-0"
                >
                  Seguir
                </a>
              </div>

              {/* Scrollable Content (Caption + Comments) */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs font-body divide-y divide-stone-100">
                {/* Main Post Caption */}
                <div className="space-y-2 pb-3">
                  <div className="flex items-start gap-2.5">
                    <span className="font-bold text-stone-900 shrink-0">
                      {INSTITUTION_INFO.instagram}
                    </span>
                    <p className="text-stone-700 leading-relaxed">
                      {activePost.caption}
                    </p>
                  </div>

                  {/* Hashtags */}
                  <div className="flex flex-wrap gap-1 text-[11px] text-[#073B91]">
                    {activePost.hashtags.map((ht) => (
                      <span key={ht} className="hover:underline">
                        {ht}
                      </span>
                    ))}
                  </div>

                  <span className="text-[10px] text-stone-400 font-mono block">
                    Publicado {activePost.timeAgo}
                  </span>
                </div>

                {/* Comments List */}
                <div className="pt-3 space-y-3">
                  <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">
                    Mensagens de Carinho & Apoio ({activePost.comments.length + (customComments[activePost.id]?.length || 0)})
                  </span>

                  {/* Static Pre-seeded Comments */}
                  {activePost.comments.map((comment) => (
                    <div key={comment.id} className="flex items-start gap-2">
                      <div className="w-6 h-6 rounded-full bg-stone-200 text-stone-600 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                        {comment.author.charAt(0).toUpperCase()}
                      </div>
                      <div className="space-y-0.5 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-stone-800">
                            {comment.author}
                          </span>
                          {comment.isVolunteer && (
                            <span className="text-[9px] text-[#073B91] font-semibold bg-blue-50 px-1.5 py-0.2 rounded">
                              Voluntário
                            </span>
                          )}
                          <span className="text-[10px] text-stone-400 font-mono ml-auto">
                            {comment.timeAgo}
                          </span>
                        </div>
                        <p className="text-stone-600 leading-snug">{comment.text}</p>
                      </div>
                    </div>
                  ))}

                  {/* User-submitted comments from local session */}
                  {customComments[activePost.id]?.map((comment) => (
                    <div
                      key={comment.id}
                      className="flex items-start gap-2 bg-blue-50/50 p-2 rounded-xl border border-blue-100"
                    >
                      <div className="w-6 h-6 rounded-full bg-[#073B91] text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                        {comment.author.charAt(0).toUpperCase()}
                      </div>
                      <div className="space-y-0.5 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-[#073B91]">
                            {comment.author}
                          </span>
                          <span className="text-[10px] text-stone-400 font-mono ml-auto">
                            {comment.timeAgo}
                          </span>
                        </div>
                        <p className="text-stone-700 leading-snug">{comment.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Bar (Like, Share, Direct Link) */}
              <div className="p-3 border-t border-stone-200 bg-stone-50/50 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() =>
                        handleToggleLike(activePost.id, activePost.likesCount)
                      }
                      aria-label="Curtir publicação"
                      className="text-stone-700 hover:text-red-500 transition-colors cursor-pointer"
                    >
                      <Heart
                        className={`w-5 h-5 ${
                          likedPosts[activePost.id]
                            ? 'fill-red-500 text-red-500 scale-110'
                            : 'hover:scale-105'
                        } transition-transform`}
                      />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const input = document.getElementById(commentInputId);
                        input?.focus();
                      }}
                      aria-label="Comentar publicação"
                      className="text-stone-700 hover:text-[#073B91] transition-colors cursor-pointer"
                    >
                      <MessageCircle className="w-5 h-5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSharePost(activePost)}
                      aria-label="Compartilhar no WhatsApp"
                      className="text-stone-700 hover:text-emerald-600 transition-colors cursor-pointer"
                    >
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>

                  <a
                    href={INSTITUTION_INFO.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-semibold text-stone-600 hover:text-[#073B91] flex items-center gap-1"
                  >
                    <span>Abrir no Instagram</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* Likes Counter */}
                <div className="text-xs font-semibold text-stone-900 font-body">
                  <span>
                    {(userLikesCount[activePost.id] ?? activePost.likesCount).toLocaleString(
                      'pt-BR'
                    )}{' '}
                    curtidas
                  </span>
                </div>

                {/* Leave Comment Form */}
                <form
                  onSubmit={(e) => handleAddComment(e, activePost.id)}
                  className="space-y-1.5 pt-1"
                >
                  <div className="flex items-center gap-2">
                    <label htmlFor={authorInputId} className="sr-only">
                      Seu nome
                    </label>
                    <input
                      id={authorInputId}
                      type="text"
                      value={newCommentAuthor}
                      onChange={(e) => setNewCommentAuthor(e.target.value)}
                      placeholder="Seu nome (opcional)"
                      className="w-1/3 px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs placeholder-stone-400 focus:outline-hidden focus:border-[#073B91]"
                    />
                    <label htmlFor={commentInputId} className="sr-only">
                      Escreva um recado carinhoso
                    </label>
                    <input
                      id={commentInputId}
                      type="text"
                      value={newCommentText}
                      onChange={(e) => setNewCommentText(e.target.value)}
                      placeholder="Deixe um carinho para os residentes..."
                      className="flex-1 px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs placeholder-stone-400 focus:outline-hidden focus:border-[#073B91]"
                    />
                    <button
                      type="submit"
                      disabled={!newCommentText.trim()}
                      aria-label="Publicar mensagem"
                      className="p-1.5 bg-[#073B91] hover:bg-[#052c6e] text-white rounded-lg disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {commentSuccess && (
                    <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-medium">
                      <Check className="w-3 h-3 text-emerald-600" />
                      <span>Mensagem enviada com carinho para os residentes!</span>
                    </div>
                  )}
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
