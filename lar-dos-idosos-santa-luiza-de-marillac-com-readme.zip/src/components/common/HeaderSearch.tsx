import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Search, X, ArrowRight, FileText, Heart, Calendar, HelpCircle, Building } from 'lucide-react';
import { PageRoute } from '../../types';
import { DEMO_NEEDS, TRANSPARENCY_DOCUMENTS, SERVICE_DIFFERENTIALS, INSTITUTION_INFO } from '../../data/institutionalData';

interface SearchResultItem {
  id: string;
  title: string;
  description: string;
  page: PageRoute;
  category: 'Página' | 'Cuidado e Rotina' | 'Corrente do Bem' | 'Transparência' | 'Informação';
  iconType: 'page' | 'care' | 'need' | 'doc' | 'info';
}

interface HeaderSearchProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: () => void;
  onOpenVisitModal: () => void;
  className?: string;
}

export const HeaderSearch: React.FC<HeaderSearchProps> = ({
  onNavigate,
  onOpenDonationModal,
  onOpenVisitModal,
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Keyboard shortcut Ctrl+K / Cmd+K or /
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      } else if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
        inputRef.current?.blur();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  // Click outside to close results dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  // Institutional Search Index
  const searchIndex: SearchResultItem[] = useMemo(() => {
    const items: SearchResultItem[] = [
      // Main Pages
      {
        id: 'page-home',
        title: 'Início (Página Inicial)',
        description: 'Apresentação geral do Lar, acolhimento humanizado, diferenciais e destaques.',
        page: 'home',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'page-sobre',
        title: 'Sobre Nós & Princípios da ILPI',
        description: 'Missão, visão, valores, esclarecimento sobre acolhimento residencial e estrutura.',
        page: 'sobre',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'page-historia',
        title: 'Nossa História (Mais de 50 Anos)',
        description: 'Trajetória histórica, fundação vicentina em Juiz de Fora e linha do tempo de dedicação.',
        page: 'nossa-historia',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'page-corrente',
        title: 'Corrente do Bem (Catálogo de Doações)',
        description: 'Lista transparente de necessidades: fraldas, alimentos, itens de higiene e limpeza.',
        page: 'corrente-do-bem',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'page-transparencia',
        title: 'Transparência & Prestação de Contas',
        description: 'Relatórios anuais, balancetes trimestrais, CEBAS e estatuto da instituição.',
        page: 'transparencia',
        category: 'Página',
        iconType: 'page',
      },
      {
        id: 'page-contato',
        title: 'Contato & Localização em Juiz de Fora',
        description: `Endereço: ${INSTITUTION_INFO.address}, linhas de ônibus ${INSTITUTION_INFO.busLinesText}, telefone ${INSTITUTION_INFO.phone}.`,
        page: 'contato',
        category: 'Página',
        iconType: 'page',
      },
      // Important Direct Actions
      {
        id: 'info-visitas',
        title: 'Agendar Visita ao Lar',
        description: 'Conheça nossas instalações, converse com a equipe e veja de perto o ambiente dos residentes.',
        page: 'contato',
        category: 'Informação',
        iconType: 'info',
      },
      {
        id: 'info-pix',
        title: 'Chave PIX e Como Fazer Doação Financeira',
        description: `Chave PIX oficial (${INSTITUTION_INFO.email}), transferências e recibo filantrópico.`,
        page: 'corrente-do-bem',
        category: 'Corrente do Bem',
        iconType: 'need',
      },
      // Institutional Needs
      ...DEMO_NEEDS.map((need) => ({
        id: `need-${need.id}`,
        title: `Doação: ${need.name}`,
        description: `${need.description} Meta atual: ${need.quantityNeeded} ${need.unit}.`,
        page: 'corrente-do-bem' as PageRoute,
        category: 'Corrente do Bem' as const,
        iconType: 'need' as const,
      })),
      // Institutional Differentials
      ...SERVICE_DIFFERENTIALS.map((diff) => ({
        id: `diff-${diff.id}`,
        title: `Cuidado: ${diff.title}`,
        description: diff.description,
        page: 'sobre' as PageRoute,
        category: 'Cuidado e Rotina' as const,
        iconType: 'care' as const,
      })),
      // Official Documents
      ...TRANSPARENCY_DOCUMENTS.map((doc) => ({
        id: `doc-${doc.id}`,
        title: `Documento: ${doc.title}`,
        description: `${doc.summary} (${doc.fileType.toUpperCase()}, ${doc.fileSize}).`,
        page: 'transparencia' as PageRoute,
        category: 'Transparência' as const,
        iconType: 'doc' as const,
      })),
    ];
    return items;
  }, []);

  // Filtered Results
  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();
    return searchIndex.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
    ).slice(0, 6);
  }, [query, searchIndex]);

  const handleSelectResult = (item: SearchResultItem) => {
    onNavigate(item.page);
    setIsOpen(false);
    setQuery('');

    if (item.id === 'info-visitas') {
      setTimeout(() => onOpenVisitModal(), 300);
    } else if (item.id === 'info-pix') {
      setTimeout(() => onOpenDonationModal(), 300);
    }
  };

  const getResultIcon = (iconType: string) => {
    switch (iconType) {
      case 'page':
        return <Building className="w-4 h-4 text-[#073B91]" />;
      case 'care':
        return <Heart className="w-4 h-4 text-[#073B91]" />;
      case 'need':
        return <Heart className="w-4 h-4 text-[#76A900]" />;
      case 'doc':
        return <FileText className="w-4 h-4 text-[#073B91]" />;
      default:
        return <HelpCircle className="w-4 h-4 text-[#76A900]" />;
    }
  };

  return (
    <div className={`relative font-body ${className}`} ref={containerRef}>
      {/* BARRA DE PESQUISA GRANDE E DESTACADA */}
      <div className="relative flex items-center w-full">
        <div className="w-full flex items-center gap-2.5 px-3.5 sm:px-4 py-2 sm:py-2.5 bg-[#FAFBF7] hover:bg-white focus-within:bg-white rounded-xl border border-stone-300 focus-within:border-[#073B91] focus-within:ring-2 focus-within:ring-[#073B91]/15 shadow-2xs transition-all">
          <Search className="w-4 h-4 text-[#073B91] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              if (!isOpen) setIsOpen(true);
            }}
            onFocus={() => setIsOpen(true)}
            placeholder="Pesquisar páginas, doações, visitas, relatórios..."
            className="w-full bg-transparent text-xs sm:text-sm text-[#27343B] placeholder-stone-500 font-body focus:outline-hidden"
            aria-label="Pesquisar no site"
          />

          {query ? (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                inputRef.current?.focus();
              }}
              className="p-1 text-stone-400 hover:text-stone-700 rounded-md transition-colors cursor-pointer"
              title="Limpar pesquisa"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <kbd className="hidden lg:inline-block text-[10px] bg-white text-stone-400 px-1.5 py-0.5 rounded border border-stone-200 font-mono shadow-2xs">
              ⌘K
            </kbd>
          )}
        </div>
      </div>

      {/* PAINEL DE RESULTADOS EM DROPDOWN (Aparece ao focar ou digitar) */}
      {isOpen && (
        <div className="absolute left-0 right-0 sm:right-auto sm:left-0 top-full mt-2 w-full sm:w-[460px] md:w-[520px] bg-white rounded-2xl shadow-xl border border-stone-200/90 z-50 overflow-hidden animate-in fade-in duration-150">
          {/* Cabeçalho do Dropdown */}
          <div className="p-3 border-b border-stone-100 bg-[#FAFBF7] flex items-center justify-between text-xs text-[#5A666E]">
            <span className="font-semibold text-[#073B91]">Resultados da Busca</span>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="text-[11px] font-medium text-stone-500 hover:text-stone-800 bg-white px-2 py-0.5 rounded border border-stone-200 transition-colors cursor-pointer"
            >
              Fechar (Esc)
            </button>
          </div>

          {/* Área de Resultados */}
          <div className="max-h-[360px] overflow-y-auto p-2">
            {query.trim() === '' ? (
              /* Sugestões rápidas quando vazio */
              <div className="p-4 space-y-3 text-xs text-[#66737A]">
                <p className="font-semibold text-[#27343B] uppercase tracking-wider text-[11px]">
                  Sugestões rápidas para pesquisar:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {['Fraldas geriátricas', 'Visitas ao Lar', 'Enfermagem 24h', 'Transparência fiscal', 'Alimentação', 'Como doar'].map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => {
                        setQuery(tag);
                        inputRef.current?.focus();
                      }}
                      className="px-2.5 py-1 text-xs bg-[#F5F8F0] hover:bg-stone-200 text-[#073B91] rounded-lg border border-stone-200 transition-colors cursor-pointer"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            ) : results.length === 0 ? (
              /* Sem resultados */
              <div className="py-8 px-4 text-center space-y-2 text-[#66737A]">
                <p className="font-heading font-semibold text-sm text-[#27343B]">
                  Nenhum resultado para "{query}"
                </p>
                <p className="text-xs">
                  Tente buscar por termos como <em>doações</em>, <em>visitas</em>, <em>remédios</em> ou <em>prestação</em>.
                </p>
              </div>
            ) : (
              /* Lista de resultados encontrados */
              <div className="space-y-1">
                {results.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectResult(item)}
                    className="w-full p-2.5 rounded-xl hover:bg-[#F5F8F0] text-left transition-colors flex items-start gap-3 group cursor-pointer border border-transparent hover:border-stone-200"
                  >
                    <div className="p-2 rounded-lg bg-stone-100 group-hover:bg-white text-[#073B91] shrink-0 mt-0.5 border border-stone-200">
                      {getResultIcon(item.iconType)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="font-heading font-bold text-xs sm:text-sm text-[#27343B] group-hover:text-[#073B91] truncate transition-colors">
                          {item.title}
                        </h4>
                        <span className="text-[10px] font-semibold text-[#76A900] bg-white px-1.5 py-0.5 rounded border border-stone-200 shrink-0">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-[11px] sm:text-xs text-[#66737A] line-clamp-1 mt-0.5 font-body">
                        {item.description}
                      </p>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-stone-300 group-hover:text-[#073B91] group-hover:translate-x-0.5 transition-all self-center shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
