import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { X, Heart, CheckCircle2, QrCode, Copy, Check, MessageSquare, AlertCircle } from 'lucide-react';
import { INSTITUTION_INFO, DEMO_NEEDS } from '../../data/institutionalData';
import { NeedItem } from '../../types';
import { notifySuccess, notifyInfo } from '../../utils/notifications';

const donationSchema = z.object({
  fullName: z.string().min(3, 'Por favor, informe seu nome completo (mínimo 3 caracteres)'),
  email: z.string().email('Informe um endereço de e-mail válido'),
  phone: z.string().min(10, 'Informe um número de telefone ou WhatsApp válido com DDD'),
  itemDonated: z.string().min(2, 'Selecione ou especifique o item que deseja doar'),
  quantity: z.string().min(1, 'Informe a quantidade pretendida'),
  message: z.string().optional(),
  consentLgpd: z.boolean().refine((val) => val === true, {
    message: 'É necessário concordar com o tratamento dos dados conforme a LGPD',
  }),
});

type DonationFormData = z.infer<typeof donationSchema>;

interface DonationModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedNeed?: NeedItem | null;
  initialTab?: 'material' | 'pix';
  suggestedAmount?: number;
  suggestedImpactText?: string;
}

export const DonationModal: React.FC<DonationModalProps> = ({
  isOpen,
  onClose,
  selectedNeed,
  initialTab,
  suggestedAmount,
  suggestedImpactText,
}) => {
  const [activeTab, setActiveTab] = useState<'material' | 'pix'>(initialTab || 'material');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copiedPix, setCopiedPix] = useState(false);
  const [submittedData, setSubmittedData] = useState<DonationFormData | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<DonationFormData>({
    resolver: zodResolver(donationSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      itemDonated: selectedNeed ? selectedNeed.name : '',
      quantity: selectedNeed?.quantityNeeded ? `${selectedNeed.quantityNeeded} ${selectedNeed.unit}` : '1',
      message: '',
      consentLgpd: false,
    },
  });

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
    if (selectedNeed) {
      setValue('itemDonated', selectedNeed.name);
      setValue(
        'quantity',
        selectedNeed.quantityNeeded ? `${selectedNeed.quantityNeeded} ${selectedNeed.unit}` : '1'
      );
      setActiveTab('material');
    } else if (suggestedImpactText && initialTab === 'material') {
      setValue('itemDonated', suggestedImpactText);
      setValue('quantity', '1 combo');
    }
  }, [selectedNeed, initialTab, suggestedImpactText, setValue]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleClose = () => {
    setIsSubmitted(false);
    setSubmittedData(null);
    reset();
    onClose();
  };

  const onSubmit = (data: DonationFormData) => {
    setSubmittedData(data);
    setIsSubmitted(true);
    notifySuccess(`Doação de "${data.itemDonated}" agendada com sucesso! Muito obrigado.`);
  };

  const handleCopyPixKey = () => {
    // Chave PIX oficial (E-mail original)
    const pixText = INSTITUTION_INFO.email;
    navigator.clipboard.writeText(pixText);
    setCopiedPix(true);
    notifySuccess('Chave PIX copiada com sucesso!');
    setTimeout(() => setCopiedPix(false), 2500);
  };

  const handleOpenWhatsAppSummary = () => {
    if (!submittedData) return;
    const text = encodeURIComponent(
      `Olá! Meu nome é ${submittedData.fullName}. Gostaria de confirmar minha intenção de doação para o Lar dos Idosos Santa Luiza de Marillac:\n` +
      `• Item: ${submittedData.itemDonated}\n` +
      `• Quantidade: ${submittedData.quantity}\n` +
      `• Telefone: ${submittedData.phone}\n` +
      `${submittedData.message ? `• Mensagem: ${submittedData.message}\n` : ''}` +
      `Como podemos combinar a entrega ou retirada?`
    );
    window.open(`https://wa.me/${INSTITUTION_INFO.whatsappClean}?text=${text}`, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="donation-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-[#F5F8F0]">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-[#76A900] text-white rounded-lg">
              <Heart className="w-5 h-5 fill-white/20" />
            </span>
            <div>
              <h2 id="donation-modal-title" className="text-base sm:text-lg font-heading font-bold text-[#073B91]">
                Faça Parte da Corrente do Bem
              </h2>
              <p className="text-xs text-stone-500">
                Sua solidariedade transforma os dias dos nossos moradores
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 rounded-lg text-stone-500 hover:text-stone-800 hover:bg-stone-200/50 transition-colors"
            aria-label="Fechar janela de doação"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selection */}
        {!isSubmitted && (
          <div className="flex border-b border-stone-200 bg-stone-50/80 px-6 pt-3 gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('material')}
              className={`pb-2.5 px-3 text-xs sm:text-sm font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === 'material'
                  ? 'border-[#073B91] text-[#073B91] font-semibold'
                  : 'border-transparent text-stone-600 hover:text-stone-900'
              }`}
            >
              Doação de Alimentos e Materiais
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('pix')}
              className={`pb-2.5 px-3 text-xs sm:text-sm font-medium transition-colors border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'pix'
                  ? 'border-[#073B91] text-[#073B91] font-semibold'
                  : 'border-transparent text-stone-600 hover:text-stone-900'
              }`}
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>Contribuição Financeira (PIX)</span>
            </button>
          </div>
        )}

        {/* Body content */}
        <div className="p-6 overflow-y-auto">
          {isSubmitted && submittedData ? (
            /* Success confirmation screen */
            <div className="text-center py-4 space-y-4">
              <div className="w-14 h-14 bg-[#76A900]/15 text-[#76A900] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-heading text-xl font-bold text-[#073B91]">
                  Intenção de Doação Registrada!
                </h3>
                <p className="text-sm text-stone-600 mt-1 max-w-md mx-auto">
                  Agradecemos imensamente pelo seu gesto de amor, <strong>{submittedData.fullName}</strong>.
                </p>
              </div>

              <div className="p-4 bg-[#F5F8F0] rounded-xl border border-stone-200 text-left text-xs sm:text-sm space-y-2 max-w-md mx-auto">
                <p className="font-semibold text-[#073B91] border-b border-stone-200 pb-1.5">
                  Resumo da sua contribuição:
                </p>
                <div className="flex justify-between text-stone-600">
                  <span>Item:</span>
                  <span className="font-medium text-stone-900">{submittedData.itemDonated}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Quantidade:</span>
                  <span className="font-medium text-stone-900">{submittedData.quantity}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Telefone:</span>
                  <span className="font-medium text-stone-900">{submittedData.phone}</span>
                </div>
              </div>

              <p className="text-xs text-stone-500 max-w-md mx-auto">
                Nossa equipe entrará em contato para alinhar os detalhes da entrega no Lar. Você também pode adiantar a comunicação pelo WhatsApp oficial:
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                <button
                  type="button"
                  onClick={handleOpenWhatsAppSummary}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#76A900] hover:bg-[#679400] rounded-lg transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Avisar equipe via WhatsApp</span>
                </button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="px-4 py-2.5 text-xs sm:text-sm font-medium text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
                >
                  Concluir e fechar
                </button>
              </div>
            </div>
          ) : activeTab === 'pix' ? (
            /* PIX Tab */
            <div className="space-y-5 py-2">
              <div className="p-4 bg-amber-50/80 rounded-xl border border-amber-200 text-xs sm:text-sm text-amber-900 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Área Institucional de Contribuição</p>
                  <p className="mt-0.5 text-amber-800">
                    Por rigor de integridade e transparência da ILPI filantrópica, os dados bancários definitivos e o QR Code oficial estão em fase de homologação formal pela diretoria.
                  </p>
                </div>
              </div>

              {suggestedAmount && (
                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs sm:text-sm text-emerald-950 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                    R$
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-semibold text-emerald-900">
                        Valor Definido na Calculadora: <span className="font-mono text-base font-bold text-emerald-700">R$ {suggestedAmount.toFixed(2).replace('.', ',')}</span>
                      </p>
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                        Impacto Simulado
                      </span>
                    </div>
                    {suggestedImpactText && (
                      <p className="mt-1 text-xs text-emerald-800">
                        {suggestedImpactText}
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="p-6 bg-[#F5F8F0] rounded-xl border border-stone-200 text-center space-y-4">
                <div className="w-36 h-36 bg-white border border-stone-300 rounded-lg mx-auto flex items-center justify-center shadow-xs">
                  <div className="text-center p-3">
                    <QrCode className="w-14 h-14 text-[#073B91] mx-auto opacity-70" />
                    <span className="text-[10px] text-stone-500 block mt-1 font-mono">
                      QR CODE PIX OFICIAL
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-xs text-stone-500 uppercase tracking-wider font-semibold">
                    Chave PIX E-mail (Provisória / Contato)
                  </p>
                  <div className="flex items-center justify-center gap-2 max-w-sm mx-auto">
                    <code className="text-xs sm:text-sm font-mono bg-white px-3 py-1.5 rounded-md border border-stone-300 text-stone-800">
                      {INSTITUTION_INFO.email}
                    </code>
                    <button
                      type="button"
                      onClick={handleCopyPixKey}
                      className="p-1.5 text-xs bg-white hover:bg-stone-100 text-stone-700 border border-stone-300 rounded-md transition-colors inline-flex items-center gap-1"
                      title="Copiar chave PIX"
                    >
                      {copiedPix ? <Check className="w-4 h-4 text-[#76A900]" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <p className="text-xs text-stone-500 max-w-md mx-auto">
                  Para doações em dinheiro com emissão de recibo filantrópico oficial, favor entrar em contato diretamente com a nossa secretaria pelo telefone <strong>{INSTITUTION_INFO.phone}</strong>.
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleClose}
                  className="px-5 py-2 text-xs sm:text-sm font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>
          ) : (
            /* Material Donation Form */
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              {/* Item selection */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Item a doar <span className="text-red-500">*</span>
                </label>
                <div className="space-y-2">
                  <input
                    type="text"
                    {...register('itemDonated')}
                    placeholder="Ex: Fraldas geriátricas G, Leite, Sabonete líquido..."
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                  />
                  {errors.itemDonated && (
                    <p className="text-xs text-red-600 mt-1">{errors.itemDonated.message}</p>
                  )}
                  {/* Quick suggestions from catalog */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <span className="text-[11px] text-stone-500 self-center">Sugestões rápidas:</span>
                    {DEMO_NEEDS.slice(0, 3).map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setValue('itemDonated', item.name);
                          setValue('quantity', `${item.quantityNeeded || 1} ${item.unit}`);
                        }}
                        className="text-[11px] text-[#073B91] bg-stone-100 hover:bg-[#F5F8F0] px-2 py-0.5 rounded-sm border border-stone-200 transition-colors"
                      >
                        {item.name.slice(0, 26)}...
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Quantity */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Quantidade pretendida <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  {...register('quantity')}
                  placeholder="Ex: 5 pacotes, 10 litros, 2 caixas..."
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                />
                {errors.quantity && (
                  <p className="text-xs text-red-600 mt-1">{errors.quantity.message}</p>
                )}
              </div>

              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Seu nome completo <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  {...register('fullName')}
                  placeholder="Nome e sobrenome"
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                />
                {errors.fullName && (
                  <p className="text-xs text-red-600 mt-1">{errors.fullName.message}</p>
                )}
              </div>

              {/* Email & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                    E-mail <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    {...register('email')}
                    placeholder="seuemail@exemplo.com"
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                  />
                  {errors.email && (
                    <p className="text-xs text-red-600 mt-1">{errors.email.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                    Telefone / WhatsApp <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    {...register('phone')}
                    placeholder="(32) 99999-9999"
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                  />
                  {errors.phone && (
                    <p className="text-xs text-red-600 mt-1">{errors.phone.message}</p>
                  )}
                </div>
              </div>

              {/* Optional message */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Mensagem ou observações (opcional)
                </label>
                <textarea
                  {...register('message')}
                  rows={2}
                  placeholder="Ex: Prefiro entregar no sábado pela manhã ou combinar retirada no bairro..."
                  className="w-full px-3.5 py-2 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors resize-none"
                />
              </div>

              {/* LGPD Consent */}
              <div className="pt-2">
                <label className="flex items-start gap-2.5 cursor-pointer text-xs text-stone-600 select-none">
                  <input
                    type="checkbox"
                    {...register('consentLgpd')}
                    className="mt-0.5 rounded-sm border-stone-300 text-[#073B91] focus:ring-[#073B91] h-4 w-4"
                  />
                  <span>
                    Concordo com o tratamento dos meus dados exclusivamente para coordenação desta doação com o Lar Santa Luiza de Marillac, nos termos da Lei Geral de Proteção de Dados (LGPD).
                  </span>
                </label>
                {errors.consentLgpd && (
                  <p className="text-xs text-red-600 mt-1">{errors.consentLgpd.message}</p>
                )}
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row gap-2 justify-end">
                <button
                  type="button"
                  onClick={handleClose}
                  className="px-4 py-2.5 text-xs sm:text-sm font-medium text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#76A900] hover:bg-[#679400] rounded-lg transition-colors shadow-xs disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Heart className="w-4 h-4 fill-white/20" />
                  <span>{isSubmitting ? 'Registrando...' : 'Confirmar intenção de doação'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
