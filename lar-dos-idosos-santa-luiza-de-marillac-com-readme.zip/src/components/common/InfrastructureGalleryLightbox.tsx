import React, { useState, useEffect, useCallback } from 'react';
import { X, ChevronLeft, ChevronRight, ZoomIn, Info, Camera, Image as ImageIcon } from 'lucide-react';
import { WireframePlaceholder } from './WireframePlaceholder';

export interface GalleryImageItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  imageUrl: string;
  highResUrl: string;
  category: string;
  tag: string;
}

export const INFRASTRUCTURE_GALLERY: GalleryImageItem[] = [
  {
    id: 'jardim',
    title: 'Pátio & Jardins Arborizados',
    subtitle: 'Conexão diária com a natureza e banho de sol seguro',
    description:
      'Área externa cercada e protegida, com bancos ergonômicos, calçamento plano e plano de sombra natural de árvores nativas. Ideal para caminhadas orientadas pela fisioterapia e momentos de contemplação.',
    imageUrl: '', // Wireframe: Inserir foto do Pátio/Jardim (800x600px)
    highResUrl: '', // Wireframe: Inserir foto em alta resolução (1600x1200px)
    category: 'Área Externa',
    tag: 'Ar Livre & Socialização',
  },
  {
    id: 'refeitorio',
    title: 'Refeitório & Salão de Convivência',
    subtitle: 'Alimentação afetiva sob supervisão nutricional',
    description:
      'Espaço climatizado e amplo onde acontecem as 6 refeições diárias balanceadas, além de oficinas lúdicas, jogos de tabuleiro, apresentações musicais voluntárias e celebrações festivas da nossa comunidade.',
    imageUrl: '', // Wireframe: Inserir foto do Refeitório
    highResUrl: '',
    category: 'Social',
    tag: 'Nutrição & Encontros',
  },
  {
    id: 'enfermagem',
    title: 'Posto de Enfermagem 24 Horas',
    subtitle: 'Rigor técnico, triagem e controle de medicamentos',
    description:
      'Equipado para o monitoramento contínuo de sinais vitais, aferição de glicemia, curativos e dispensação rigorosa de medicamentos sob prontuário individualizado de cada idoso.',
    imageUrl: '', // Wireframe: Inserir foto do Posto de Enfermagem
    highResUrl: '',
    category: 'Saúde',
    tag: 'Assistência Contínua',
  },
  {
    id: 'dormitorios',
    title: 'Dormitórios Adaptados & Acolhedores',
    subtitle: 'Privacidade, descanso tranquilo e acessibilidade',
    description:
      'Quartos ventilados com barras de apoio, campainhas de chamada rápida ao lado dos leitos, iluminação suave noturna e armários individuais para objetos afetivos pessoais dos residentes.',
    imageUrl: '', // Wireframe: Inserir foto dos Dormitórios
    highResUrl: '',
    category: 'Acomodações',
    tag: 'Conforto & Repouso',
  },
  {
    id: 'fisioterapia',
    title: 'Sala de Fisioterapia & Terapia Ocupacional',
    subtitle: 'Estímulo à autonomia motora e cognitiva',
    description:
      'Espaço com barras paralelas, bolas suíças, faixas elásticas e jogos cognitivos desenhados para preservar a mobilidade, equilíbrio postural e independência nas atividades diárias.',
    imageUrl: '', // Wireframe: Inserir foto da Fisioterapia
    highResUrl: '',
    category: 'Reabilitação',
    tag: 'Mobilidade Ativa',
  },
  {
    id: 'capela',
    title: 'Espaço de Oração & Espiritualidade',
    subtitle: 'Acolhimento da fé, serenidade e tradição vicentina',
    description:
      'Um recanto silencioso e de paz para quem deseja orar, meditar ou participar das celebrações ecumênicas semanais, respeitando sempre a crença e a individualidade de cada idoso.',
    imageUrl: '', // Wireframe: Inserir foto da Capela/Espaço de Oração
    highResUrl: '',
    category: 'Espiritualidade',
    tag: 'Paz & Reflexão',
  },
];

interface InfrastructureGalleryLightboxProps {
  onOpenVisitModal?: () => void;
}

export const InfrastructureGalleryLightbox: React.FC<InfrastructureGalleryLightboxProps> = ({
  onOpenVisitModal,
}) => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('todos');

  const filteredItems = activeCategory === 'todos'
    ? INFRASTRUCTURE_GALLERY
    : INFRASTRUCTURE_GALLERY.filter((item) => item.category === activeCategory);

  const categories = ['todos', ...Array.from(new Set(INFRASTRUCTURE_GALLERY.map((i) => i.category)))];

  const handleOpenLightbox = (index: number) => {
    // map the filtered index to actual INFRASTRUCTURE_GALLERY index
    const item = filteredItems[index];
    const originalIndex = INFRASTRUCTURE_GALLERY.findIndex((g) => g.id === item.id);
    setSelectedIndex(originalIndex >= 0 ? originalIndex : 0);
  };

  const handleCloseLightbox = useCallback(() => {
    setSelectedIndex(null);
  }, []);

  const handleNext = useCallback(() => {
    if (selectedIndex === null) return;
    setSelectedIndex((prev) => ((prev! + 1) % INFRASTRUCTURE_GALLERY.length));
  }, [selectedIndex]);

  const handlePrev = useCallback(() => {
    if (selectedIndex === null) return;
    setSelectedIndex((prev) => (prev! === 0 ? INFRASTRUCTURE_GALLERY.length - 1 : prev! - 1));
  }, [selectedIndex]);

  // Keyboard navigation for Lightbox
  useEffect(() => {
    if (selectedIndex === null) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCloseLightbox();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    // Lock body scroll
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [selectedIndex, handleCloseLightbox, handleNext, handlePrev]);

  const currentItem = selectedIndex !== null ? INFRASTRUCTURE_GALLERY[selectedIndex] : null;

  return (
    <div>
      {/* Category Filter Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-8">
        <span className="text-xs font-semibold text-[#66737A] uppercase tracking-wider mr-2 font-mono">
          Filtrar por área:
        </span>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all duration-200 cursor-pointer ${
              activeCategory === cat
                ? 'bg-[#073B91] text-white shadow-xs'
                : 'bg-white text-[#27343B] border border-stone-200 hover:border-[#073B91]/40 hover:bg-stone-50'
            }`}
          >
            {cat === 'todos' ? 'Todos os Ambientes (6)' : cat}
          </button>
        ))}
      </div>

      {/* Grid of Photo Cards with Click to Zoom */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {filteredItems.map((item, idx) => (
          <div
            key={item.id}
            onClick={() => handleOpenLightbox(idx)}
            className="group relative bg-white rounded-2xl overflow-hidden border border-stone-200/90 shadow-2xs hover:shadow-md transition-all duration-300 flex flex-col cursor-pointer focus:outline-hidden focus:ring-2 focus:ring-[#76A900]"
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleOpenLightbox(idx);
              }
            }}
            aria-label={`Ver foto em tela cheia: ${item.title}`}
          >
            {/* Image Container -> Wireframe */}
            <div className="relative aspect-4/3 overflow-hidden bg-slate-50 p-2">
              <WireframePlaceholder
                label={item.title}
                suggestedDimensions="800 × 600 px"
                aspectRatio="aspect-4/3"
                type="gallery"
                slotId={`infra-${item.id}`}
                notes={item.tag}
                className="w-full h-full"
              />
            </div>

            {/* Description Info */}
            <div className="p-5 flex-1 flex flex-col justify-between space-y-2">
              <div>
                <h3 className="font-heading font-bold text-base sm:text-lg text-[#27343B] group-hover:text-[#073B91] transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-[#76A900] font-medium mt-0.5">
                  {item.subtitle}
                </p>
                <p className="text-xs sm:text-sm text-[#66737A] font-body mt-2 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-[#073B91] font-medium">
                <span>Clique para alta resolução</span>
                <span className="text-stone-300 group-hover:translate-x-1 group-hover:text-[#76A900] transition-all">
                  →
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Fullscreen Modal */}
      {selectedIndex !== null && currentItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`Visualização em tela cheia de ${currentItem.title}`}
          className="fixed inset-0 z-50 bg-black/92 backdrop-blur-md flex flex-col justify-between animate-fade-in"
          onClick={handleCloseLightbox}
        >
          {/* Top Header Bar */}
          <div
            className="flex items-center justify-between px-4 sm:px-8 py-4 bg-linear-to-b from-black/80 to-transparent z-10"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-white">
              <span className="text-xs uppercase tracking-widest text-[#9FE000] font-mono">
                {currentItem.category} • Foto {selectedIndex + 1} de {INFRASTRUCTURE_GALLERY.length}
              </span>
              <h2 className="text-lg sm:text-xl font-heading font-bold text-white">
                {currentItem.title}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCloseLightbox}
                className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                aria-label="Fechar galeria em tela cheia (Esc)"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Center: Image & Controls */}
          <div
            className="relative flex-1 flex items-center justify-center p-2 sm:p-6 select-none"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Prev button */}
            <button
              type="button"
              onClick={handlePrev}
              className="absolute left-3 sm:left-6 p-3 rounded-full bg-black/50 hover:bg-black/80 text-white border border-white/20 transition-all hover:scale-105 cursor-pointer z-10"
              aria-label="Foto anterior (Seta esquerda)"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* High Resolution Image Slot */}
            <div className="max-w-4xl max-h-[75vh] w-full h-[60vh] flex items-center justify-center p-4">
              <div className="w-full h-full max-w-3xl rounded-2xl border-2 border-dashed border-slate-600 bg-slate-900/90 flex flex-col items-center justify-center text-center p-8 space-y-4 shadow-2xl">
                <div className="w-16 h-16 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-sky-400 shadow-xl">
                  <Camera className="w-8 h-8" />
                </div>
                <div className="space-y-1 max-w-md">
                  <span className="text-xs font-mono uppercase tracking-widest text-sky-400 block">
                    [Espaço Wireframe · Foto de Infraestrutura]
                  </span>
                  <h3 className="font-heading font-bold text-xl text-white">
                    {currentItem.title}
                  </h3>
                  <p className="text-xs text-slate-300">
                    {currentItem.subtitle}
                  </p>
                </div>
                <span className="text-xs font-mono text-slate-400 bg-slate-950/80 px-3 py-1 rounded-md border border-slate-800">
                  Dimensão sugerida em alta resolução: 1600 × 1200 px
                </span>
              </div>
            </div>

            {/* Next button */}
            <button
              type="button"
              onClick={handleNext}
              className="absolute right-3 sm:right-6 p-3 rounded-full bg-black/50 hover:bg-black/80 text-white border border-white/20 transition-all hover:scale-105 cursor-pointer z-10"
              aria-label="Próxima foto (Seta direita)"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Bottom Bar: Caption & Quick Thumbnails */}
          <div
            className="bg-linear-to-t from-black/90 via-black/80 to-transparent p-4 sm:p-6 z-10 text-white max-w-5xl mx-auto w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-t border-white/10 pt-4">
              <div className="space-y-1 max-w-2xl">
                <p className="text-xs text-[#9FE000] font-medium flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5" />
                  {currentItem.subtitle}
                </p>
                <p className="text-xs sm:text-sm text-stone-300 leading-relaxed font-body">
                  {currentItem.description}
                </p>
              </div>

              {/* Thumbnails list */}
              <div className="flex items-center gap-2 overflow-x-auto py-1">
                {INFRASTRUCTURE_GALLERY.map((thumb, tIdx) => (
                  <button
                    key={thumb.id}
                    onClick={() => setSelectedIndex(tIdx)}
                    className={`relative w-14 h-10 rounded-md overflow-hidden shrink-0 border-2 transition-all cursor-pointer flex items-center justify-center text-[11px] font-mono font-bold ${
                      selectedIndex === tIdx
                        ? 'border-[#76A900] bg-slate-800 text-white scale-105'
                        : 'border-white/20 bg-slate-900/80 text-slate-400 opacity-60 hover:opacity-100'
                    }`}
                    aria-label={`Ir para ${thumb.title}`}
                  >
                    <span>0{tIdx + 1}</span>
                  </button>
                ))}
              </div>
            </div>

            {onOpenVisitModal && (
              <div className="mt-3 pt-3 border-t border-white/10 text-center">
                <span className="text-xs text-stone-400 mr-2">
                  Deseja conhecer nossa infraestrutura pessoalmente?
                </span>
                <button
                  onClick={() => {
                    handleCloseLightbox();
                    onOpenVisitModal();
                  }}
                  className="inline-flex items-center text-xs font-semibold text-[#9FE000] hover:text-white underline cursor-pointer"
                >
                  Agende uma visita guiada sem compromisso
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
