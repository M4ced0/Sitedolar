import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Calendar,
  Clock,
  Tag,
  ArrowRight,
  Sparkles,
  Share2,
  X,
  Check,
  Heart,
  Users,
  Compass,
  CheckCircle2,
  Bookmark,
  ExternalLink,
  MessageSquare,
  Newspaper,
  Bell,
  Mail,
  Camera,
  Image as ImageIcon,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { WireframePlaceholder } from './WireframePlaceholder';
import { INSTITUTION_INFO } from '../../data/institutionalData';
import { notifySuccess } from '../../utils/notifications';

export interface NewsArticle {
  id: string;
  title: string;
  category: 'eventos' | 'projetos' | 'campanhas' | 'melhorias';
  categoryLabel: string;
  date: string;
  readTime: string;
  summary: string;
  imageUrl: string;
  statusBadge: string;
  featured?: boolean;
  content: {
    intro: string;
    paragraphs: string[];
    highlightQuote?: {
      quote: string;
      author: string;
      role: string;
    };
    results?: string[];
  };
}

export const NEWS_ARTICLES: NewsArticle[] = [
  {
    id: 'noticia-musicoterapia-conservatorio',
    title: 'Tarde de Memória Afetiva e Música com Jovens Voluntários de Juiz de Fora',
    category: 'eventos',
    categoryLabel: 'Eventos & Convivência',
    date: '12 de Outubro de 2026',
    readTime: '3 min de leitura',
    statusBadge: 'Evento Realizado',
    featured: true,
    summary:
      'Estudantes e músicos voluntários do Conservatório Estadual de Música trouxeram serenatas, modas de viola e chorinho para alegrar a tarde dos residentes.',
    imageUrl: '', // Wireframe: Inserir foto da notícia (1000x600px)
    content: {
      intro:
        'A música tem o poder singular de resgatar lembranças profundas e iluminar o olhar de quem já viveu tantas décadas. No último sábado, o Lar Santa Luiza de Marillac abriu suas portas para uma tarde inesquecível de integração intergeracional.',
      paragraphs: [
        'Organizada em parceria com voluntários do Conservatório Estadual de Música Haidée França Americano e jovens da comunidade de Juiz de Fora, a oficina reuniu moradores no pátio ensolarado para cantar cantigas de roda, clássicos do cancioneiro mineiro e chorinhos tradicionais.',
        'Segundo a equipe de enfermagem e assistência social, atividades como esta estimulam a cognição, reduzem o estresse e promovem momentos genuínos de riso e partilha entre residentes que nem sempre contam com visitas frequentes de parentes.',
        'O residente Seu Zé da Gaita (81 anos) fez questão de acompanhar o violão com sua própria gaita de boca, sendo aplaudido de pé pelos colegas e pela equipe de cuidadores.',
      ],
      highlightQuote: {
        quote:
          'Ver o sorriso de cada senhor e senhora ao recordar as canções de sua mocidade nos mostra que cuidar também é celebrar a alegria presente.',
        author: 'Mariana Duarte',
        role: 'Coordenadora de Atividades de Convivência',
      },
      results: [
        'Mais de 35 residentes participaram ativamente da atividade',
        '8 jovens músicos voluntários mobilizados na Vila Furtado de Menezes e região',
        'Estímulo cognitivo e alívio do isolamento social através da musicoterapia',
      ],
    },
  },
  {
    id: 'noticia-horta-sensorial',
    title: 'Colheita da Primavera: Horta Sensorial e Medicinal Traz Bem-Estar aos Moradores',
    category: 'projetos',
    categoryLabel: 'Projetos do Lar',
    date: '05 de Outubro de 2026',
    readTime: '4 min de leitura',
    statusBadge: 'Projeto Contínuo',
    summary:
      'Canteiros suspensos adaptados para cadeirantes permitem que os residentes cultivem hortaliças, alecrim, hortelã e chás medicinais no jardim do Lar.',
    imageUrl: '', // Wireframe: Inserir foto do projeto horta
    content: {
      intro:
        'O contato direto com a terra, com as texturas das folhas e com os aromas naturais despertou uma nova rotina cheia de entusiasmo nos pátios do Lar dos Idosos Santa Luiza de Marillac.',
      paragraphs: [
        'O projeto "Raízes do Cuidado" foi estruturado com canteiros suspensos na altura adequada para pessoas idosas em cadeiras de rodas ou com mobilidade reduzida, garantindo que todos possam semear, regar e colher sem risco de quedas.',
        'Nesta semana, os residentes celebraram a colheita dos primeiros ramos de manjericão, alecrim, hortelã e couve orgânica, que foram prontamente integrados ao preparo das sopas e infusões nutritivas pelo time de nutrição.',
        'Dona Geralda Barbosa (76 anos), antiga moradora do campo em Minas Gerais, assumiu com carinho a tarefa matinal de regar os vasos medicinais antes do café da manhã.',
      ],
      highlightQuote: {
        quote:
          'Mexer na terra me faz lembrar da casa da minha mãe na roça. Sentir o cheiro do alecrim faz a gente se sentir útil e viva.',
        author: 'Dona Geralda',
        role: 'Residente no Lar há 3 anos',
      },
      results: [
        '6 canteiros elevados 100% adaptados conforme normas de acessibilidade',
        'Incentivo à coordenação motora fina e estímulo sensorial aromático',
        'Temperos naturais frescos incorporados ao cardápio diário da instituição',
      ],
    },
  },
  {
    id: 'noticia-agasalho-inverno-solidario',
    title: 'Campanha de Conforto Térmico: Juiz de Fora se Une pelos Moradores do Lar',
    category: 'campanhas',
    categoryLabel: 'Campanhas & Doações',
    date: '28 de Setembro de 2026',
    readTime: '2 min de leitura',
    statusBadge: 'Meta Atingida',
    summary:
      'Graças à solidariedade de paróquias, comércios da Vila Furtado de Menezes e doações da comunidade, foram arrecadados cobertores térmicos e agasalhos novos.',
    imageUrl: '', // Wireframe: Inserir foto da campanha
    content: {
      intro:
        'As noites de Juiz de Fora e da Zona da Mata exigem atenção especial com a saúde respiratória e a temperatura corporal dos idosos acolhidos.',
      paragraphs: [
        'A campanha institucional "Aconchego Fraterno" mobilizou mais de 120 famílias de Juiz de Fora, comerciantes locais e grupos de voluntários durante todo o mês passado.',
        'Foram entregues cobertores de microfibra hipoalergênicos, meias térmicas antiderrapantes e blusas de lã laváveis, devidamente identificadas para o uso individual e respeitoso de cada acolhido.',
        'A prestação de contas integral e o inventário dos itens doados já estão disponíveis em nosso portal de transparência, mantendo a tradição ética de honestidade do Lar.',
      ],
      highlightQuote: {
        quote:
          'Cada cobertor doado não aquece apenas o corpo; aquece a certeza de que nossos velhinhos não foram esquecidos pela comunidade.',
        author: 'Irmã Beatriz',
        role: 'Diretoria Voluntária Vicentina',
      },
      results: [
        '84 cobertores novos e higienizados recebidos',
        'Garantia de 100% dos leitos com proteção térmica reforçada',
        'Emissão de recibos e registro público no Portal de Transparência',
      ],
    },
  },
  {
    id: 'noticia-sala-fisioterapia',
    title: 'Conclusão da Modernização do Espaço de Reabilitação e Fisioterapia Motora',
    category: 'melhorias',
    categoryLabel: 'Melhorias & Obras',
    date: '18 de Setembro de 2026',
    readTime: '3 min de leitura',
    statusBadge: 'Estrutura Entregue',
    summary:
      'Novas barras de apoio paralelas, cicloergômetros e piso vinílico de alto amortecimento proporcionam mais segurança nas sessões diárias de fortalecimento.',
    imageUrl: '', // Wireframe: Inserir foto da fisioterapia
    content: {
      intro:
        'A prevenção contra quedas e a preservação da marcha são pilares fundamentais para a dignidade e independência dos residentes do Lar Santa Luiza de Marillac.',
      paragraphs: [
        'Com recursos provenientes de doações contínuas e apoio da Corrente do Bem, foi concluída a reforma da Sala de Cinesioterapia e Reabilitação Motora.',
        'O espaço agora conta com barras paralelas ergonômicas, espelho de marcha, tatame terapêutico, cicloergômetros de baixa resistência e piso vinílico com absorção de impacto, reduzindo riscos de lesões.',
        'Com a nova estrutura, a fisioterapia preventiva passa a atender 100% dos residentes com indicação médica de segunda a sexta-feira.',
      ],
      highlightQuote: {
        quote:
          'Um idoso que recupera a confiança para dar alguns passos pelo jardim conquista de volta a sua sensação de liberdade.',
        author: 'Dr. Lucas Silveira',
        role: 'Fisioterapeuta Geriátrico Responsável',
      },
      results: [
        'Aumento de 40% na capacidade de atendimentos semanais de fisioterapia',
        'Adequação total às exigências da ANVISA e Corpo de Bombeiros',
        'Investimento transparente auditado e publicado no balancete trimestral',
      ],
    },
  },
];

interface RecentNewsSectionProps {
  onOpenDonationModal?: () => void;
  onOpenVisitModal?: () => void;
}

export const RecentNewsSection: React.FC<RecentNewsSectionProps> = ({
  onOpenDonationModal,
  onOpenVisitModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [activeArticle, setActiveArticle] = useState<NewsArticle | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubmitted, setNewsletterSubmitted] = useState(false);

  const categories = [
    { id: 'todos', label: 'Todas as Novidades' },
    { id: 'eventos', label: 'Eventos & Convivência' },
    { id: 'projetos', label: 'Projetos do Lar' },
    { id: 'campanhas', label: 'Campanhas & Doações' },
    { id: 'melhorias', label: 'Melhorias & Obras' },
  ];

  const filteredArticles =
    selectedCategory === 'todos'
      ? NEWS_ARTICLES
      : NEWS_ARTICLES.filter((item) => item.category === selectedCategory);

  const newsScrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkNewsScroll = useCallback(() => {
    const el = newsScrollRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 15);
    setCanScrollRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 15);
  }, []);

  useEffect(() => {
    const el = newsScrollRef.current;
    if (!el) return;
    checkNewsScroll();
    el.addEventListener('scroll', checkNewsScroll, { passive: true });
    window.addEventListener('resize', checkNewsScroll);
    return () => {
      el.removeEventListener('scroll', checkNewsScroll);
      window.removeEventListener('resize', checkNewsScroll);
    };
  }, [checkNewsScroll, filteredArticles]);

  const handleScrollNews = (direction: 'left' | 'right') => {
    const el = newsScrollRef.current;
    if (!el) return;
    const scrollAmount = el.clientWidth > 640 ? 380 : 310;
    el.scrollBy({ left: direction === 'left' ? -scrollAmount : scrollAmount, behavior: 'smooth' });
  };

  const handleShare = (article: NewsArticle) => {
    const url = window.location.href;
    const shareText = `${article.title} - Lar dos Idosos Santa Luiza de Marillac (Juiz de Fora): ${url}`;
    
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareText);
      setCopiedLink(true);
      notifySuccess('Link da notícia copiado para a área de transferência!');
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setNewsletterSubmitted(true);
    notifySuccess('Inscrição no boletim realizada com sucesso! Bem-vindo(a).');
    setTimeout(() => {
      setNewsletterEmail('');
      setNewsletterSubmitted(false);
    }, 4000);
  };

  return (
    <section id="noticias-recentes" className="py-20 lg:py-28 bg-gradient-to-b from-[#EFF5FD] via-[#FAFBF7] to-[#EFF5FD] border-b border-[#073B91]/15">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho da Seção */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#073B91]/10 border border-[#073B91]/25 text-[#073B91] text-xs font-bold uppercase tracking-wider font-body shadow-2xs">
              <Newspaper className="w-3.5 h-3.5 text-[#073B91]" />
              <span>Notícias Recentes & Comunidade</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#27343B] leading-tight">
              Acompanhe as últimas realizações, eventos e projetos do nosso Lar.
            </h2>
            <p className="text-base text-[#66737A] font-body leading-relaxed">
              O Lar Santa Luiza de Marillac é um espaço de vida ativa e respeito mútuo. Veja como as doações da sociedade juiz-forana e o carinho dos voluntários se transformam em ações concretas de afeto e cuidado.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <span className="text-xs text-[#66737A] font-body hidden sm:inline">
              Juiz de Fora · MG
            </span>
            <div className="h-4 w-px bg-stone-300 hidden sm:inline" />
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white border border-stone-200 text-xs font-medium text-[#27343B] shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-[#76A900] animate-pulse" />
              <span>Atualizado Outubro 2026</span>
            </span>
          </div>
        </div>

        {/* Barra de Filtros por Categoria */}
        <div className="flex flex-wrap items-center gap-2 mb-10 pb-2 border-b border-stone-200">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all duration-200 font-body cursor-pointer ${
                  isActive
                    ? 'bg-[#073B91] text-white shadow-2xs'
                    : 'bg-white text-[#66737A] hover:text-[#27343B] hover:bg-stone-100 border border-stone-200/80'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Notícia em Destaque (Se estiver na categoria "todos" ou "eventos") */}
        {selectedCategory === 'todos' && NEWS_ARTICLES.find((a) => a.featured) && (
          <div className="mb-12">
            {(() => {
              const feat = NEWS_ARTICLES.find((a) => a.featured)!;
              return (
                <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12 hover:border-[#073B91]/40 transition-colors">
                  <div className="lg:col-span-7 relative p-3">
                    <WireframePlaceholder
                      label={`Notícia Destaque: ${feat.title}`}
                      suggestedDimensions="1000 × 600 px"
                      aspectRatio="aspect-video"
                      type="banner"
                      slotId={`noticia-${feat.id}`}
                      notes={feat.summary}
                      className="w-full h-full min-h-[280px]"
                    />
                  </div>

                  <div className="lg:col-span-5 p-6 sm:p-8 lg:p-10 flex flex-col justify-between">
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 text-xs text-[#66737A] font-body">
                        <span className="flex items-center gap-1 font-semibold text-[#073B91]">
                          <Tag className="w-3.5 h-3.5" />
                          {feat.categoryLabel}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          {feat.date}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {feat.readTime}
                        </span>
                      </div>

                      <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#27343B] leading-tight hover:text-[#073B91] transition-colors">
                        <button
                          type="button"
                          onClick={() => setActiveArticle(feat)}
                          className="text-left cursor-pointer"
                        >
                          {feat.title}
                        </button>
                      </h3>

                      <p className="text-sm text-[#66737A] font-body leading-relaxed">
                        {feat.summary}
                      </p>

                      <div className="p-4 rounded-xl bg-[#F5F8F0] border border-stone-200/80 text-xs text-[#27343B]">
                        <p className="italic text-[#66737A] mb-1">
                          "{feat.content.highlightQuote?.quote}"
                        </p>
                        <p className="font-semibold text-[#073B91]">
                          — {feat.content.highlightQuote?.author}, {feat.content.highlightQuote?.role}
                        </p>
                      </div>
                    </div>

                    <div className="pt-6 border-t border-stone-200/80 flex items-center justify-between gap-4 mt-6">
                      <button
                        type="button"
                        onClick={() => setActiveArticle(feat)}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#073B91] hover:bg-[#052c6e] text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer shadow-2xs font-body"
                      >
                        <span>Ler notícia completa</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleShare(feat)}
                        className="p-2.5 rounded-lg border border-stone-200 text-[#66737A] hover:text-[#073B91] hover:bg-stone-50 transition-colors cursor-pointer"
                        title="Compartilhar notícia"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* Cabeçalho do Carrossel de Artigos em Linha Única */}
        <div className="flex items-center justify-between gap-4 mb-4 pt-4 border-t border-stone-200">
          <div>
            <h3 className="font-heading text-lg sm:text-xl font-bold text-[#27343B]">
              {selectedCategory === 'todos' ? 'Todas as Publicações & Matérias' : `Notícias de ${categories.find(c => c.id === selectedCategory)?.label || ''}`}
            </h3>
            <p className="text-xs text-[#66737A] font-body mt-0.5">
              {filteredArticles.length} {filteredArticles.length === 1 ? 'matéria publicada' : 'matérias publicadas'} · Use as setinhas para navegar lado a lado
            </p>
          </div>

          {/* Setinhas de Navegação no Cabeçalho */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleScrollNews('left')}
              disabled={!canScrollLeft}
              className="p-2.5 rounded-full bg-white border border-stone-200 text-stone-700 hover:text-[#073B91] hover:border-[#073B91] hover:shadow-md disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer shadow-xs active:scale-95"
              aria-label="Passar para notícias anteriores à esquerda"
              title="Notícia anterior"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => handleScrollNews('right')}
              disabled={!canScrollRight}
              className="p-2.5 rounded-full bg-white border border-stone-200 text-stone-700 hover:text-[#073B91] hover:border-[#073B91] hover:shadow-md disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer shadow-xs active:scale-95"
              aria-label="Passar para próximas notícias à direita"
              title="Próxima notícia"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Carrossel de Artigos: Fileira Única Horizontal com Scroll Suave e Snap */}
        <div className="relative group/carousel">
          {/* Botão Flutuante Esquerdo (Desktop) */}
          {canScrollLeft && (
            <button
              type="button"
              onClick={() => handleScrollNews('left')}
              className="hidden lg:flex absolute -left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-white/95 border border-stone-200 text-[#073B91] shadow-lg items-center justify-center hover:bg-white hover:scale-105 active:scale-95 transition-all cursor-pointer"
              aria-label="Rolar para esquerda"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}

          {/* Botão Flutuante Direito (Desktop) */}
          {canScrollRight && (
            <button
              type="button"
              onClick={() => handleScrollNews('right')}
              className="hidden lg:flex absolute -right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-white/95 border border-stone-200 text-[#073B91] shadow-lg items-center justify-center hover:bg-white hover:scale-105 active:scale-95 transition-all cursor-pointer"
              aria-label="Rolar para direita"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}

          <div
            ref={newsScrollRef}
            className="flex gap-6 overflow-x-auto scroll-smooth snap-x snap-mandatory py-3 px-1 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
          >
            {filteredArticles.map((article) => {
              return (
                <article
                  key={article.id}
                  className="w-[300px] sm:w-[350px] md:w-[380px] shrink-0 snap-start bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden flex flex-col justify-between hover:shadow-md hover:border-stone-300 transition-all duration-300 group"
                >
                  <div>
                    {/* Imagem do Card -> Wireframe */}
                    <div className="relative p-2">
                      <WireframePlaceholder
                        label={article.title}
                        suggestedDimensions="700 × 400 px"
                        aspectRatio="aspect-video"
                        type="card"
                        slotId={`noticia-${article.id}`}
                        notes={article.categoryLabel}
                        className="w-full h-44"
                      />
                      <div className="absolute top-4 left-4 flex gap-2">
                        <span className="px-2 py-0.5 rounded-md bg-[#073B91]/90 text-white text-[11px] font-medium backdrop-blur-xs">
                          {article.categoryLabel}
                        </span>
                      </div>
                    </div>

                    {/* Conteúdo do Card */}
                    <div className="p-5 sm:p-6 space-y-3">
                      <div className="flex items-center gap-2 text-xs text-[#66737A] font-body">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-[#76A900]" />
                          {article.date}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {article.readTime}
                        </span>
                      </div>

                      <h3 className="font-heading text-base sm:text-lg font-bold text-[#27343B] leading-snug group-hover:text-[#073B91] transition-colors line-clamp-2">
                        <button
                          type="button"
                          onClick={() => setActiveArticle(article)}
                          className="text-left cursor-pointer"
                        >
                          {article.title}
                        </button>
                      </h3>

                      <p className="text-xs sm:text-sm text-[#66737A] font-body leading-relaxed line-clamp-3">
                        {article.summary}
                      </p>
                    </div>
                  </div>

                  {/* Rodapé do Card */}
                  <div className="p-5 sm:p-6 pt-0">
                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setActiveArticle(article)}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#073B91] hover:text-[#052c6e] group-hover:underline transition-colors font-body cursor-pointer"
                      >
                        <span>Acompanhar detalhes</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleShare(article)}
                        className="p-1.5 rounded-md text-[#66737A] hover:text-[#073B91] hover:bg-stone-50 transition-colors cursor-pointer"
                        title="Compartilhar"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>

        {/* Faixa Interativa: Conecte-se com o Lar (Informativo e Transparência) */}
        <div className="mt-14 bg-gradient-to-br from-[#073B91] to-[#052c6e] rounded-3xl p-8 sm:p-10 text-white shadow-md relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-72 h-72 rounded-full bg-white/5 pointer-events-none" />
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-7 space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-white text-xs font-medium">
                <Bell className="w-3.5 h-3.5 text-[#76A900]" />
                <span>Boletim Informativo do Lar</span>
              </div>
              <h3 className="font-heading text-2xl sm:text-3xl font-bold leading-tight">
                Receba as novidades, festas e projetos no seu e-mail
              </h3>
              <p className="text-sm text-white/80 font-body leading-relaxed max-w-xl">
                Nossa prestação de contas com Juiz de Fora é contínua. Inscreva-se para receber convites para nossos bazares, celebrações de datas festivas e relatos do dia a dia dos residentes.
              </p>
            </div>

            <div className="lg:col-span-5">
              {newsletterSubmitted ? (
                <div className="bg-white/15 border border-white/20 rounded-2xl p-6 text-center space-y-2 backdrop-blur-xs">
                  <div className="w-10 h-10 rounded-full bg-[#76A900] text-white flex items-center justify-center mx-auto">
                    <Check className="w-5 h-5" />
                  </div>
                  <p className="text-sm font-semibold">Obrigado pelo seu interesse!</p>
                  <p className="text-xs text-white/80">
                    Você passará a receber nosso boletim comunitário com amor e transparência.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="space-y-3">
                  <div className="flex flex-col sm:flex-row gap-2">
                    <div className="relative flex-1">
                      <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="email"
                        required
                        value={newsletterEmail}
                        onChange={(e) => setNewsletterEmail(e.target.value)}
                        placeholder="Seu melhor e-mail..."
                        className="w-full pl-10 pr-4 py-3 text-sm rounded-lg bg-white text-[#27343B] placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-[#76A900] font-body"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-5 py-3 rounded-lg bg-[#76A900] hover:bg-[#679400] text-white font-semibold text-sm transition-colors shrink-0 shadow-2xs font-body cursor-pointer flex items-center justify-center gap-2"
                    >
                      <span>Cadastrar</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-2xs text-white/60 font-body">
                    Prometemos não enviar spam. Comunicações estritamente filantrópicas e voluntárias.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>

      </div>

      {/* Modal de Detalhes da Notícia / Matéria Completa */}
      {activeArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
          <div
            className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-stone-200 shadow-2xl relative my-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Botão Fechar */}
            <button
              type="button"
              onClick={() => setActiveArticle(null)}
              className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-black/50 hover:bg-black/70 text-white backdrop-blur-xs transition-colors cursor-pointer"
              aria-label="Fechar notícia"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Capa Wireframe do Modal */}
            <div className="relative h-64 sm:h-72 w-full bg-slate-900 overflow-hidden flex flex-col justify-end p-6 border-b border-slate-700">
              {/* Blueprint grid texture */}
              <div
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(circle, #38bdf8 1.5px, transparent 1.5px)',
                  backgroundSize: '24px 24px',
                }}
              />
              {/* Wireframe Tag Top Left */}
              <div className="absolute top-4 left-6 z-10 flex items-center gap-2 bg-slate-800/90 border border-slate-700 text-sky-400 px-3 py-1 rounded-full text-xs font-mono">
                <Camera className="w-3.5 h-3.5" />
                <span>Espaço Wireframe · Capa da Notícia (1200 × 600 px)</span>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent pointer-events-none" />
              <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
                <div className="flex flex-wrap items-center gap-2 text-xs font-body">
                  <span className="px-2.5 py-1 rounded-md bg-[#76A900] font-semibold">
                    {activeArticle.categoryLabel}
                  </span>
                  <span className="px-2.5 py-1 rounded-md bg-white/20 backdrop-blur-xs">
                    {activeArticle.date}
                  </span>
                  <span className="px-2.5 py-1 rounded-md bg-white/20 backdrop-blur-xs">
                    {activeArticle.readTime}
                  </span>
                </div>
                <h3 className="font-heading text-xl sm:text-2xl lg:text-3xl font-bold leading-tight">
                  {activeArticle.title}
                </h3>
              </div>
            </div>

            {/* Corpo do Modal */}
            <div className="p-6 sm:p-8 lg:p-10 space-y-6">
              
              {/* Notificação de cópia de link */}
              {copiedLink && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Link da notícia copiado para a área de transferência!</span>
                </div>
              )}

              {/* Introdução */}
              <p className="text-base sm:text-lg font-medium text-[#27343B] font-body leading-relaxed border-l-4 border-[#073B91] pl-4">
                {activeArticle.content.intro}
              </p>

              {/* Parágrafos da matéria */}
              <div className="space-y-4 text-sm sm:text-base text-[#66737A] font-body leading-relaxed">
                {activeArticle.content.paragraphs.map((p, idx) => (
                  <p key={idx}>{p}</p>
                ))}
              </div>

              {/* Citação em destaque */}
              {activeArticle.content.highlightQuote && (
                <div className="p-6 rounded-2xl bg-[#F5F8F0] border border-stone-200 space-y-3">
                  <p className="italic text-base sm:text-lg text-[#27343B] font-heading font-medium">
                    "{activeArticle.content.highlightQuote.quote}"
                  </p>
                  <div className="flex items-center gap-2 text-xs font-body">
                    <div className="w-8 h-8 rounded-full bg-[#073B91] text-white flex items-center justify-center font-bold">
                      {activeArticle.content.highlightQuote.author.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-[#27343B]">
                        {activeArticle.content.highlightQuote.author}
                      </p>
                      <p className="text-[#66737A]">
                        {activeArticle.content.highlightQuote.role}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Resultados / Impacto */}
              {activeArticle.content.results && activeArticle.content.results.length > 0 && (
                <div className="space-y-3 pt-2">
                  <h4 className="font-heading font-bold text-base text-[#27343B] flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-[#76A900]" />
                    <span>Impacto Gerado para os Residentes</span>
                  </h4>
                  <ul className="space-y-2 text-xs sm:text-sm text-[#66737A] font-body">
                    {activeArticle.content.results.map((res, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#76A900] mt-2 shrink-0" />
                        <span>{res}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Ações e Compartilhamento */}
              <div className="pt-6 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => handleShare(activeArticle)}
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-stone-300 text-xs font-semibold text-[#27343B] hover:bg-stone-50 transition-colors font-body cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-[#073B91]" />
                    <span>Compartilhar</span>
                  </button>
                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                      `${activeArticle.title} - Lar Santa Luiza de Marillac Juiz de Fora: ${window.location.href}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#25D366] text-white text-xs font-semibold hover:bg-[#20bd5a] transition-colors font-body"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>WhatsApp</span>
                  </a>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  {onOpenDonationModal && (
                    <button
                      type="button"
                      onClick={() => {
                        setActiveArticle(null);
                        onOpenDonationModal();
                      }}
                      className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#76A900] hover:bg-[#679400] text-white text-xs font-semibold transition-colors font-body cursor-pointer shadow-2xs"
                    >
                      <Heart className="w-4 h-4 fill-white/20" />
                      <span>Apoiar Este Projeto</span>
                    </button>
                  )}

                  {onOpenVisitModal && (
                    <button
                      type="button"
                      onClick={() => {
                        setActiveArticle(null);
                        onOpenVisitModal();
                      }}
                      className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#073B91] hover:bg-[#052c6e] text-white text-xs font-semibold transition-colors font-body cursor-pointer shadow-2xs"
                    >
                      <Users className="w-4 h-4" />
                      <span>Agendar Visita</span>
                    </button>
                  )}
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </section>
  );
};
