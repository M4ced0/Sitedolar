import React, { useState } from 'react';
import { PageRoute } from '../types';
import {
  INSTITUTION_INFO,
  DEMO_NEEDS,
} from '../data/institutionalData';
import { HeroCarouselBanner } from '../components/common/HeroCarouselBanner';
import {
  Heart,
  ArrowRight,
  ShieldCheck,
  Home,
  HeartHandshake,
  Pill,
  UtensilsCrossed,
  Sparkles,
  Users,
  MapPin,
  ExternalLink,
  FileCheck2,
  Phone,
  CheckCircle2,
  Calendar,
  Clock,
  Sun,
  Coffee,
  Smile,
  Bus,
} from 'lucide-react';
import { motion } from 'motion/react';
import { TestimonialsSlider } from '../components/common/TestimonialsSlider';
import { ResidentLifeStories } from '../components/common/ResidentLifeStories';
import { DonationImpactCalculator } from '../components/common/DonationImpactCalculator';
import { RecentNewsSection } from '../components/common/RecentNewsSection';
import { EventsCalendarSection } from '../components/common/EventsCalendarSection';
import { InstagramGallerySection } from '../components/common/InstagramGallerySection';
import { FaqSection } from '../components/common/FaqSection';
import { WireframePlaceholder } from '../components/common/WireframePlaceholder';

interface HomePageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: (options?: any) => void;
  onOpenVisitModal: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenDonationModal,
  onOpenVisitModal,
}) => {
  const [activeCareTab, setActiveCareTab] = useState<'moradia' | 'enfermagem' | 'nutricao' | 'convivencia'>('moradia');
  const featuredNeeds = DEMO_NEEDS.slice(0, 3);

  const careOptions = [
    {
      id: 'moradia' as const,
      label: 'Moradia Acolhedora',
      title: 'Ambiente seguro, confortável e adaptado à terceira idade.',
      description:
        'Instalações estruturadas para o descanso, a segurança e a sensação genuína de lar. Dormitórios arejados, corredores com barras de apoio, acessibilidade plena e amplos pátios ensolarados para desfrutar o dia a dia com serenidade.',
      bullets: [
        'Quartos e suítes com luz natural abundante',
        'Acessibilidade integral sem degraus ou barreiras',
        'Pátios e jardins para banho de sol diário',
        'Ambiente familiar e respeito à privacidade individual',
      ],
      photoUrl: '', // Wireframe: Inserir foto da Moradia Acolhedora
      photoAlt: 'Pátio arborizado e acomodações do Lar Santa Luiza de Marillac',
      icon: <Home className="w-5 h-5" />,
    },
    {
      id: 'enfermagem' as const,
      label: 'Cuidados de Enfermagem 24h',
      title: 'Assistência contínua com zelo e controle rigoroso.',
      description:
        'Nossa equipe de enfermagem atua em regime ininterrupto, atenta aos sinais vitais, curativos, rotinas de assepsia e administração precisa das medicações conforme as receitas de cada médico assistente.',
      bullets: [
        'Acompanhamento de enfermagem disponível 24 horas',
        'Controle minucioso de medicação prescrita',
        'Aferição diária de pressão, glicemia e sinais vitais',
        'Prontuário individualizado e suporte assistencial humanizado',
      ],
      photoUrl: '', // Wireframe: Inserir foto de Enfermagem 24h
      photoAlt: 'Equipe de enfermagem atenciosa com morador idoso',
      icon: <HeartHandshake className="w-5 h-5" />,
    },
    {
      id: 'nutricao' as const,
      label: 'Alimentação & Nutrição',
      title: 'Refeições diárias preparadas com carinho e equilíbrio.',
      description:
        'Oferecemos até 6 refeições por dia (café da manhã, colação, almoço, lanche, jantar e ceia) preparadas na cozinha própria do Lar, com alimentos frescos e cardápios supervisionados por nutricionista.',
      bullets: [
        'Até 6 refeições balanceadas todos os dias',
        'Dietas personalizadas (diabéticos, hipertensos, consistência pastosa)',
        'Ingredientes frescos e preparo artesanal com sabor de casa',
        'Acompanhamento de hidratação contínua ao longo do dia',
      ],
      photoUrl: '', // Wireframe: Inserir foto da Alimentação & Nutrição
      photoAlt: 'Refeição saudável e acolhedora no refeitório comunitário',
      icon: <UtensilsCrossed className="w-5 h-5" />,
    },
    {
      id: 'convivencia' as const,
      label: 'Convivência & Atividades',
      title: 'Vida social ativa, música, celebrações e afeto.',
      description:
        'A solidão não tem espaço no Lar. Promovemos oficinas, conversas, leituras, momentos de espiritualidade, celebrações de aniversários e integração com voluntários de Juiz de Fora para manter a mente e o coração aquecidos.',
      bullets: [
        'Atividades de estimulação cognitiva e motora leve',
        'Celebrações ecumênicas, aniversários e festividades',
        'Momentos de canto, música e jogos de tabuleiro',
        'Visitas fraternas e acolhimento com a comunidade',
      ],
      photoUrl: '', // Wireframe: Inserir foto de Convivência & Atividades
      photoAlt: 'Residentes conversando e sorrindo em espaço de convivência',
      icon: <Users className="w-5 h-5" />,
    },
  ];

  const currentCare = careOptions.find((c) => c.id === activeCareTab) || careOptions[0];

  return (
    <div className="w-full bg-white font-body">
      {/* =========================================================================
          HERO CARROSSEL DE IMAGENS COM ESCRITAS & BOTÕES INTUITIVOS ANIMADOS
          ========================================================================= */}
      <HeroCarouselBanner
        onNavigate={onNavigate}
        onOpenDonationModal={onOpenDonationModal}
        onOpenVisitModal={onOpenVisitModal}
      />

      {/* Faixa de Credibilidade & Presença Institucional */}
      <section className="bg-gradient-to-r from-[#EFF6FF] via-[#F4F9EC] to-[#EFF6FF] py-9 border-y border-[#073B91]/15">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-white/95 border-l-4 border-l-[#073B91] border border-stone-200/90 shadow-2xs hover:shadow-xs hover:border-[#073B91] transition-all">
              <div className="p-2.5 bg-[#073B91]/10 rounded-xl text-[#073B91] shrink-0">
                <Clock className="w-5 h-5 text-[#073B91]" />
              </div>
              <div>
                <p className="font-heading font-extrabold text-base text-[#27343B]">50+ Anos</p>
                <p className="text-xs text-[#66737A]">Tradição de acolhimento em JF</p>
              </div>
            </div>

            <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-white/95 border-l-4 border-l-[#073B91] border border-stone-200/90 shadow-2xs hover:shadow-xs hover:border-[#073B91] transition-all">
              <div className="p-2.5 bg-[#073B91]/10 rounded-xl text-[#073B91] shrink-0">
                <HeartHandshake className="w-5 h-5 text-[#073B91]" />
              </div>
              <div>
                <p className="font-heading font-extrabold text-base text-[#27343B]">Cuidados 24h</p>
                <p className="text-xs text-[#66737A]">Enfermagem sempre presente</p>
              </div>
            </div>

            <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-white/95 border-l-4 border-l-[#76A900] border border-stone-200/90 shadow-2xs hover:shadow-xs hover:border-[#76A900] transition-all">
              <div className="p-2.5 bg-[#76A900]/15 rounded-xl text-[#76A900] shrink-0">
                <UtensilsCrossed className="w-5 h-5 text-[#76A900]" />
              </div>
              <div>
                <p className="font-heading font-extrabold text-base text-[#27343B]">6 Refeições / Dia</p>
                <p className="text-xs text-[#66737A]">Supervisão por nutricionista</p>
              </div>
            </div>

            <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-white/95 border-l-4 border-l-[#76A900] border border-stone-200/90 shadow-2xs hover:shadow-xs hover:border-[#76A900] transition-all">
              <div className="p-2.5 bg-[#76A900]/15 rounded-xl text-[#76A900] shrink-0">
                <ShieldCheck className="w-5 h-5 text-[#76A900]" />
              </div>
              <div>
                <p className="font-heading font-extrabold text-base text-[#27343B]">100% Filantrópico</p>
                <p className="text-xs text-[#66737A]">Entidade beneficente sem fins lucrativos</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          AEGIS SIGNATURE: "CARE & LIVING EXPERIENCE" (INTERACTIVE TABS)
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-[#F2F7EC] via-[#EBF4E0] to-[#FAFBF7] border-b border-[#76A900]/25">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#76A900]/15 border border-[#76A900]/30 text-xs font-bold tracking-wider uppercase text-[#4d7000] font-body shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-[#76A900]" />
              <span>Nosso Cuidado Integral</span>
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#27343B]">
              Como cuidamos de cada morador, todos os dias.
            </h2>
            <p className="text-base text-[#66737A] font-body">
              Descubra os pilares da rotina residencial que garantem segurança física, nutrição saudável e aconchego humano no Lar Santa Luiza de Marillac.
            </p>

            {/* Interactive Tab Selector Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
              {careOptions.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setActiveCareTab(opt.id)}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                    activeCareTab === opt.id
                      ? 'bg-[#073B91] text-white shadow-xs'
                      : 'bg-white/90 text-[#27343B] hover:bg-white hover:border-[#073B91]/40 border border-stone-200/90 shadow-2xs'
                  }`}
                >
                  <span className={activeCareTab === opt.id ? 'text-[#9FE000]' : 'text-[#073B91]'}>
                    {opt.icon}
                  </span>
                  <span>{opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Active Tab Content Card (Aegis style split) */}
          <div className="bg-white rounded-3xl border-2 border-[#76A900]/25 shadow-md overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-6 sm:p-10 lg:p-12">
              {/* Textual Details */}
              <div className="lg:col-span-6 space-y-5">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#76A900] font-body">
                  {currentCare.label}
                </span>
                <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#27343B] leading-tight">
                  {currentCare.title}
                </h3>
                <p className="text-sm sm:text-base text-[#66737A] font-body leading-relaxed">
                  {currentCare.description}
                </p>

                <ul className="space-y-3 pt-2 text-sm text-[#27343B] font-body">
                  {currentCare.bullets.map((b, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-[#76A900] shrink-0 mt-0.5" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>

                <div className="pt-4 flex flex-wrap gap-3">
                  <button
                    type="button"
                    onClick={onOpenVisitModal}
                    className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-colors"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Agendar visita para conhecer</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('sobre')}
                    className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-[#073B91] hover:text-[#052c6e] bg-[#F5F8F0] border border-stone-200 rounded-lg transition-colors"
                  >
                    <span>Mais detalhes sobre a rotina</span>
                  </button>
                </div>
              </div>

              {/* Wireframe Slot for Care Routine */}
              <div className="lg:col-span-6">
                <WireframePlaceholder
                  label={`Foto: ${currentCare.label}`}
                  suggestedDimensions="1000 × 750 px"
                  aspectRatio="aspect-4/3"
                  type="card"
                  slotId={`rotina-${currentCare.id}`}
                  notes={currentCare.photoAlt}
                  className="w-full h-full min-h-[280px]"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          AEGIS SIGNATURE: "LIFE AT THE LAR" (MAGAZINE PHOTO STORIES)
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-[#FAFBF7] via-[#F0F5FA] to-[#FAFBF7] border-b border-stone-200/80">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
            <div className="max-w-2xl space-y-3">
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#073B91]/10 border border-[#073B91]/20 text-xs font-bold tracking-wider uppercase text-[#073B91] font-body shadow-2xs">
                <Sun className="w-3.5 h-3.5 text-[#073B91]" />
                <span>Dia a Dia no Lar</span>
              </span>
              <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#27343B]">
                A Vida no Lar Santa Luiza de Marillac
              </h2>
              <p className="text-base text-[#66737A] font-body">
                Retratos genuínos de afeto, conversas na varanda, alimentação saudável e tranquilidade.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('sobre')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-stone-200 text-sm font-semibold text-[#073B91] hover:text-[#052c6e] hover:border-[#073B91]/40 shadow-2xs font-body shrink-0 transition-all"
            >
              <span>Conhecer todos os ambientes</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Story 1 */}
            <div className="group rounded-2xl overflow-hidden border border-stone-200/90 border-t-4 border-t-[#76A900] bg-white shadow-2xs hover:shadow-md hover:border-[#76A900]/60 transition-all flex flex-col">
              <div className="relative p-2">
                <WireframePlaceholder
                  label="Jardins & Pátio: Banho de Sol"
                  suggestedDimensions="700 × 525 px"
                  aspectRatio="aspect-4/3"
                  type="card"
                  slotId="dia-a-dia-1"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-heading font-bold text-base text-[#27343B] mb-1">
                    Banho de Sol nos Jardins
                  </h4>
                  <p className="text-xs text-[#66737A] leading-relaxed">
                    Momentos matinais ao ar livre, sombra fresca de pergolados e tranquilidade na natureza.
                  </p>
                </div>
              </div>
            </div>

            {/* Story 2 */}
            <div className="group rounded-2xl overflow-hidden border border-stone-200/90 border-t-4 border-t-[#073B91] bg-white shadow-2xs hover:shadow-md hover:border-[#073B91]/60 transition-all flex flex-col">
              <div className="relative p-2">
                <WireframePlaceholder
                  label="Alimentação: Refeições & Conversas"
                  suggestedDimensions="700 × 525 px"
                  aspectRatio="aspect-4/3"
                  type="card"
                  slotId="dia-a-dia-2"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-heading font-bold text-base text-[#27343B] mb-1">
                    Refeições e Boas Conversas
                  </h4>
                  <p className="text-xs text-[#66737A] leading-relaxed">
                    Cardápios nutritivos preparados com carinho e servidos em ambiente fraterno e limpo.
                  </p>
                </div>
              </div>
            </div>

            {/* Story 3 */}
            <div className="group rounded-2xl overflow-hidden border border-stone-200/90 border-t-4 border-t-[#76A900] bg-white shadow-2xs hover:shadow-md hover:border-[#76A900]/60 transition-all flex flex-col">
              <div className="relative p-2">
                <WireframePlaceholder
                  label="Enfermagem 24h: Cuidado em Cada Gesto"
                  suggestedDimensions="700 × 525 px"
                  aspectRatio="aspect-4/3"
                  type="card"
                  slotId="dia-a-dia-3"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-heading font-bold text-base text-[#27343B] mb-1">
                    Cuidado em Cada Gesto
                  </h4>
                  <p className="text-xs text-[#66737A] leading-relaxed">
                    Administração cuidadosa de medicamentos e escuta atenta às necessidades de saúde.
                  </p>
                </div>
              </div>
            </div>

            {/* Story 4 */}
            <div className="group rounded-2xl overflow-hidden border border-stone-200/90 border-t-4 border-t-[#073B91] bg-white shadow-2xs hover:shadow-md hover:border-[#073B91]/60 transition-all flex flex-col">
              <div className="relative p-2">
                <WireframePlaceholder
                  label="Convivência: Vínculos que Iluminam"
                  suggestedDimensions="700 × 525 px"
                  aspectRatio="aspect-4/3"
                  type="card"
                  slotId="dia-a-dia-4"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-heading font-bold text-base text-[#27343B] mb-1">
                    Vínculos que Iluminam
                  </h4>
                  <p className="text-xs text-[#66737A] leading-relaxed">
                    Celebrações de aniversários, memórias partilhadas e convivência familiar fraterna.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          HISTÓRIAS DE VIDA DOS RESIDENTES (HUMANIZAÇÃO E BIOGRAFIAS)
          ========================================================================= */}
      <ResidentLifeStories
        onOpenVisitModal={onOpenVisitModal}
        onOpenDonationModal={() => onOpenDonationModal()}
      />

      {/* =========================================================================
          DEPOIMENTOS DE FAMÍLIAS & VÍNCULOS DE CONFIANÇA
          ========================================================================= */}
      <TestimonialsSlider
        onOpenVisitModal={onOpenVisitModal}
        onOpenDonationModal={() => onOpenDonationModal()}
      />

      {/* =========================================================================
          HISTÓRIA & TRADIÇÃO VICENTINA EM JUIZ DE FORA
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-[#F2F7EC] via-[#EFF5FD] to-[#F5F8F0] border-b border-stone-200/80">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-5">
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#76A900]/15 border border-[#76A900]/30 text-xs font-bold tracking-wider uppercase text-[#4d7000] font-body shadow-2xs">
                <ShieldCheck className="w-3.5 h-3.5 text-[#76A900]" />
                <span>Cinco Décadas de História</span>
              </span>
              <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#27343B] leading-tight">
                Uma trajetória construída pela solidariedade de Juiz de Fora.
              </h2>
              <p className="text-base text-[#66737A] font-body leading-relaxed">
                Fundado nos princípios de caridade e respeito à dignidade humana de Santa Luísa de Marillac e São Vicente de Paulo, o Lar dos Idosos representa um porto seguro para pessoas idosas sem retaguarda familiar ou em situação de vulnerabilidade.
              </p>
              <p className="text-sm text-[#66737A] font-body leading-relaxed">
                Graças à colaboração contínua da comunidade local, mantemos um padrão de acolhimento ético, transparente e focado no ser humano.
              </p>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigate('nossa-historia')}
                  className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-[#073B91] bg-white hover:bg-stone-100 border border-stone-300 rounded-lg transition-colors font-body shadow-2xs"
                >
                  <span>Explorar a linha do tempo completa</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 bg-gradient-to-br from-[#073B91] via-[#0a48a9] to-[#042866] text-white p-8 sm:p-10 rounded-3xl shadow-xl space-y-6 border border-[#073B91]/40 relative overflow-hidden">
              <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#76A900]/20 rounded-full blur-2xl pointer-events-none" />
              <div className="space-y-1 relative z-10">
                <span className="font-heading text-4xl sm:text-5xl font-extrabold text-[#B7F000] tracking-tight drop-shadow-xs">
                  50+ Anos
                </span>
                <p className="font-heading font-semibold text-white/95 text-base sm:text-lg">
                  De dedicação ininterrupta e acolhimento contínuo
                </p>
              </div>

              <div className="border-t border-white/15 pt-5 space-y-3.5 text-xs sm:text-sm text-white/85 font-body relative z-10">
                <p className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#B7F000] shrink-0" />
                  <span>Acolhimento residencial contínuo 24 horas</span>
                </p>
                <p className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#B7F000] shrink-0" />
                  <span>Acompanhamento de enfermagem e medicações</span>
                </p>
                <p className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#B7F000] shrink-0" />
                  <span>Alimentação e nutrição com supervisão diária</span>
                </p>
                <p className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#B7F000] shrink-0" />
                  <span>Prestação de contas e transparência pública</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          CORRENTE DO BEM (DESTAQUES DE SOLIDARIEDADE)
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-[#F4F8EE] via-[#EBF4DE] to-[#F4F8EE] border-b border-[#76A900]/25">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div className="max-w-2xl space-y-3">
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#76A900]/15 border border-[#76A900]/30 text-xs font-bold tracking-wider uppercase text-[#4d7000] font-body shadow-2xs">
                <Heart className="w-3.5 h-3.5 text-[#76A900] fill-[#76A900]/20" />
                <span>Solidariedade Que Transforma</span>
              </span>
              <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#27343B]">
                A solidariedade também faz parte do nosso cuidado.
              </h2>
              <p className="text-base text-[#66737A] font-body">
                Conheça as necessidades do Lar e descubra como pequenos gestos podem contribuir para o dia a dia dos nossos residentes.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('corrente-do-bem')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-stone-200 text-sm font-semibold text-[#073B91] hover:text-[#052c6e] hover:border-[#073B91]/40 shadow-2xs font-body shrink-0 transition-all"
            >
              <span>Ver catálogo completo de itens</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredNeeds.map((need) => (
              <div
                key={need.id}
                className="bg-white rounded-2xl border-2 border-[#76A900]/30 p-6 flex flex-col justify-between shadow-2xs hover:shadow-md hover:border-[#76A900] transition-all"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-body">
                    <span className="font-medium text-[#66737A]">{need.categoryLabel}</span>
                    <span className="text-amber-800 font-semibold bg-amber-50 px-2.5 py-0.5 rounded border border-amber-200/80">
                      Prioridade {need.priority.toUpperCase()}
                    </span>
                  </div>

                  <h3 className="font-heading font-bold text-lg text-[#27343B] leading-snug">
                    {need.name}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#66737A] font-body leading-relaxed">
                    {need.description}
                  </p>

                  <div className="pt-2 text-xs font-body text-[#66737A] flex items-center justify-between border-t border-stone-200/60">
                    <span>Meta necessária:</span>
                    <span className="font-semibold text-[#27343B] font-mono">
                      {need.quantityNeeded} {need.unit}
                    </span>
                  </div>
                </div>

                <div className="pt-5 mt-4 border-t border-stone-200/60 flex items-center justify-between">
                  <span className="text-[11px] text-[#66737A] font-body">Exemplo</span>
                  <button
                    type="button"
                    onClick={() => onOpenDonationModal(need)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#76A900] hover:bg-[#679400] rounded-lg transition-colors shadow-2xs font-body cursor-pointer"
                  >
                    <Heart className="w-3.5 h-3.5 fill-white/20" />
                    <span>Quero doar</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <button
              type="button"
              onClick={() => onNavigate('corrente-do-bem')}
              className="px-8 py-3.5 text-sm font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg shadow-xs transition-colors font-body"
            >
              Participar da Corrente do Bem
            </button>
          </div>
        </div>
      </section>

      {/* =========================================================================
          CALCULADORA DE IMPACTO DE DOAÇÃO (CESTAS BÁSICAS, KITS HIGIENE, NUTRIÇÃO)
          ========================================================================= */}
      <DonationImpactCalculator
        onOpenDonationModal={onOpenDonationModal}
        onNavigate={onNavigate}
      />

      {/* =========================================================================
          NOTÍCIAS RECENTES & PROJETOS COMUNITÁRIOS DO LAR
          ========================================================================= */}
      <RecentNewsSection
        onOpenDonationModal={() => onOpenDonationModal()}
        onOpenVisitModal={onOpenVisitModal}
      />

      {/* =========================================================================
          CALENDÁRIO DE ATIVIDADES, EVENTOS & DATAS COMEMORATIVAS
          ========================================================================= */}
      <EventsCalendarSection
        onOpenVisitModal={onOpenVisitModal}
        onOpenDonationModal={() => onOpenDonationModal()}
      />

      {/* =========================================================================
          GALERIA DO INSTAGRAM — COTIDIANO & FOTOS RECENTES DO LAR
          ========================================================================= */}
      <InstagramGallerySection
        onOpenVisitModal={onOpenVisitModal}
        onOpenDonationModal={() => onOpenDonationModal()}
      />

      {/* =========================================================================
          PERGUNTAS FREQUENTES (FAQ) — ESCLARECIMENTO INSTITUCIONAL
          ========================================================================= */}
      <FaqSection
        onNavigate={onNavigate}
        onOpenVisitModal={onOpenVisitModal}
        onOpenDonationModal={() => onOpenDonationModal()}
      />

      {/* =========================================================================
          AEGIS STYLE: "VISITE NOSSA CASA" & LOCALIZAÇÃO
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-[#EFF6FF] via-[#F4F9EC] to-[#EFF6FF] border-t border-stone-200/70">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl border-2 border-[#073B91]/20 shadow-lg p-8 sm:p-12 lg:p-14">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
              <div className="lg:col-span-7 space-y-5">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#073B91] font-body">
                  Conheça o Lar de Perto
                </span>
                <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#27343B] leading-tight">
                  Venha vivenciar o carinho e o acolhimento do Lar Santa Luiza de Marillac.
                </h2>
                <p className="text-base text-[#66737A] font-body leading-relaxed">
                  Para nós, cada visitante é recebido com a mesma alegria que acolhemos nossos moradores. Agende sua visita e conheça nossas instalações, jardins e equipe em Juiz de Fora.
                </p>

                <div className="space-y-2 text-sm text-[#27343B] font-body pt-1">
                  <p className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-[#76A900] shrink-0 mt-0.5" />
                    <span>
                      <strong>{INSTITUTION_INFO.address}</strong>
                      <br />
                      <span className="text-xs text-[#66737A]">
                        {INSTITUTION_INFO.addressComplement} · CEP {INSTITUTION_INFO.cep}
                      </span>
                    </span>
                  </p>
                  <p className="flex items-center gap-2 text-xs text-[#073B91] font-semibold">
                    <Bus className="w-4 h-4 text-[#073B91] shrink-0" />
                    <span>Linhas de ônibus que atendem o Lar: {INSTITUTION_INFO.busLinesText}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-[#76A900] shrink-0" />
                    <span>Telefone e WhatsApp: {INSTITUTION_INFO.phone}</span>
                  </p>
                </div>

                <div className="pt-4 flex flex-wrap gap-3.5">
                  <button
                    type="button"
                    onClick={onOpenVisitModal}
                    className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-colors shadow-xs"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Agendar uma Visita ao Lar</span>
                  </button>

                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${INSTITUTION_INFO.googleMapsQuery}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#073B91] hover:text-[#052c6e] bg-[#F5F8F0] border border-stone-300 rounded-lg transition-colors"
                  >
                    <span>Ver Rotas no Google Maps</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>

              {/* Mapa e Selo de Acolhimento */}
              <div className="lg:col-span-5 bg-gradient-to-br from-[#F5F8F0] to-white rounded-2xl border border-stone-200/80 p-6 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-[#76A900]/15 text-[#76A900] flex items-center justify-center">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="font-heading font-bold text-lg text-[#073B91]">
                    Acolhimento Responsável
                  </h4>
                  <p className="text-xs text-[#66737A] mt-1 max-w-xs mx-auto">
                    Visitas agendadas para garantir o descanso e a tranquilidade dos residentes acolhidos.
                  </p>
                </div>
                <div className="w-full pt-4 border-t border-stone-200/80 flex justify-between text-xs text-[#66737A]">
                  <span>Atendimento: 08h às 17h</span>
                  <span>Juiz de Fora - MG</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
