import React from 'react';
import { PageRoute } from '../types';
import {
  MISSION_VISION_VALUES,
  SERVICE_DIFFERENTIALS,
} from '../data/institutionalData';
import {
  Target,
  Eye,
  Heart,
  CheckCircle2,
  ArrowRight,
  Home,
  HeartHandshake,
  Pill,
  UtensilsCrossed,
  Sparkles,
  Users,
  ShieldCheck,
  Calendar,
} from 'lucide-react';
import { InfrastructureGalleryLightbox } from '../components/common/InfrastructureGalleryLightbox';
import { FaqSection } from '../components/common/FaqSection';
import { WireframePlaceholder } from '../components/common/WireframePlaceholder';

interface AboutPageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: () => void;
  onOpenVisitModal?: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({
  onNavigate,
  onOpenDonationModal,
  onOpenVisitModal,
}) => {
  const getDifferentialIcon = (iconName: string) => {
    switch (iconName) {
      case 'Home':
        return <Home className="w-5 h-5 text-[#073B91]" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-5 h-5 text-[#073B91]" />;
      case 'Pill':
        return <Pill className="w-5 h-5 text-[#073B91]" />;
      case 'UtensilsCrossed':
        return <UtensilsCrossed className="w-5 h-5 text-[#073B91]" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#073B91]" />;
      case 'Users':
        return <Users className="w-5 h-5 text-[#073B91]" />;
      case 'ShieldCheck':
      default:
        return <ShieldCheck className="w-5 h-5 text-[#073B91]" />;
    }
  };

  return (
    <div className="w-full bg-white font-body">
      {/* Header Institucional */}
      <section className="bg-[#F5F8F0]/60 pt-16 pb-16 lg:pt-20 lg:pb-20 border-b border-stone-200/60">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#76A900] font-body">
              Sobre a Instituição
            </span>
            <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-[#27343B] leading-[1.15] tracking-tight">
              Mais de cinco décadas dedicadas à dignidade da pessoa idosa.
            </h1>
            <p className="text-base sm:text-lg text-[#66737A] font-body leading-relaxed">
              Conheça o papel da nossa Instituição de Longa Permanência para Idosos (ILPI), nossos princípios assistenciais e a dedicação ao acolhimento humanizado em Juiz de Fora.
            </p>
          </div>
        </div>
      </section>

      {/* =========================================================================
          SEÇÃO 1: QUEM SOMOS (ESCLARECIMENTO DE ILPI)
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-[#FAFBF7] via-[#F2F7EC]/50 to-[#FAFBF7] border-b border-stone-200/80">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            <div className="lg:col-span-7 space-y-6">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#073B91] font-body">
                Nossa Identidade Assistencial
              </span>
              <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-[#27343B] leading-tight">
                Uma Instituição de Longa Permanência para Idosos (ILPI), não uma clínica médica externa.
              </h2>
              <p className="text-[#66737A] text-base leading-relaxed font-body">
                O <strong>Lar dos Idosos Santa Luiza de Marillac</strong> é uma entidade filantrópica sem fins lucrativos que oferece moradia integral, cuidados contínuos, alimentação diária e assistência biopsicossocial a idosos residentes.
              </p>

              <div className="p-5 rounded-xl bg-[#F5F8F0] border border-stone-200/80 space-y-2 text-sm text-[#27343B]">
                <p className="font-semibold text-[#073B91] font-heading">
                  Diferenciação importante:
                </p>
                <p className="leading-relaxed font-body text-[#66737A]">
                  Não prestamos atendimentos ambulatoriais abertos ao público externo, nem operamos como clínica comercial de passagem. Somos um <strong>verdadeiro lar residencial</strong> para os nossos residentes acolhidos, preservando sua privacidade, segurança e rotina tranquila.
                </p>
              </div>

              <p className="text-[#66737A] text-sm leading-relaxed font-body">
                Nossa missão inspira-se nos preceitos vicentinos de caridade e respeito à dignidade humana, proporcionando um ambiente familiar, afetuoso e acolhedor a cada habitante da casa.
              </p>
            </div>

            <div className="lg:col-span-5">
              <WireframePlaceholder
                label="Foto Institucional: Cuidado e Convivência Humanizada"
                suggestedDimensions="1000 × 750 px"
                aspectRatio="aspect-4/3"
                type="card"
                slotId="sobre-institucional"
                notes="Respeito incondicional à história de cada morador"
                className="w-full h-full min-h-[300px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          SEÇÃO 2: MISSÃO, VISÃO E VALORES
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-[#F5F8F0]/60 border-b border-stone-200/60">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-14 space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#76A900] font-body">
              Pilares Institucionais
            </span>
            <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-[#27343B]">
              Missão, Visão e Valores
            </h2>
            <p className="text-xs text-[#66737A] font-body italic">
              (Textos institucionais provisórios, sujeitos à homologação formal da diretoria)
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Missão */}
            <div className="bg-white p-8 rounded-xl border border-stone-200/80 shadow-2xs space-y-4 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#073B91]/10 text-[#073B91] flex items-center justify-center mb-4">
                  <Target className="w-5 h-5" />
                </div>
                <h3 className="font-heading font-bold text-xl text-[#073B91]">
                  {MISSION_VISION_VALUES.mission.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#66737A] leading-relaxed mt-2 font-body">
                  {MISSION_VISION_VALUES.mission.text}
                </p>
              </div>
              <span className="text-[11px] text-[#66737A] border-t border-stone-100 pt-3 block font-mono">
                {MISSION_VISION_VALUES.mission.note}
              </span>
            </div>

            {/* Visão */}
            <div className="bg-white p-8 rounded-xl border border-stone-200/80 shadow-2xs space-y-4 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#76A900]/15 text-[#76A900] flex items-center justify-center mb-4">
                  <Eye className="w-5 h-5" />
                </div>
                <h3 className="font-heading font-bold text-xl text-[#76A900]">
                  {MISSION_VISION_VALUES.vision.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#66737A] leading-relaxed mt-2 font-body">
                  {MISSION_VISION_VALUES.vision.text}
                </p>
              </div>
              <span className="text-[11px] text-[#66737A] border-t border-stone-100 pt-3 block font-mono">
                {MISSION_VISION_VALUES.vision.note}
              </span>
            </div>

            {/* Valores */}
            <div className="bg-white p-8 rounded-xl border border-stone-200/80 shadow-2xs space-y-4 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#073B91]/10 text-[#073B91] flex items-center justify-center mb-4">
                  <Heart className="w-5 h-5" />
                </div>
                <h3 className="font-heading font-bold text-xl text-[#073B91]">
                  {MISSION_VISION_VALUES.values.title}
                </h3>
                <ul className="space-y-2 mt-3 text-xs sm:text-sm text-[#66737A] font-body">
                  {MISSION_VISION_VALUES.values.items.map((val, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#76A900] shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-[#27343B] font-heading">{val.name}:</strong> {val.desc}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
              <span className="text-[11px] text-[#66737A] border-t border-stone-100 pt-3 block font-mono">
                {MISSION_VISION_VALUES.values.note}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          SEÇÃO 3: NOSSOS DIFERENCIAIS
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-[#EFF6FF]/60 via-white to-[#EFF6FF]/60 border-b border-stone-200/80">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-14 space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#073B91] font-body">
              Atuação Diária
            </span>
            <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-[#27343B]">
              Serviços e Cuidados Mantidos no Lar
            </h2>
            <p className="text-sm sm:text-base text-[#66737A] font-body">
              Cada aspecto da rotina é desenhado para promover bem-estar, segurança e conforto aos residentes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICE_DIFFERENTIALS.map((item) => (
              <div
                key={item.id}
                className="bg-white p-7 rounded-xl border border-stone-200/80 shadow-2xs space-y-3"
              >
                <div className="w-10 h-10 rounded-lg bg-[#F5F8F0] border border-stone-200 flex items-center justify-center">
                  {getDifferentialIcon(item.iconName)}
                </div>
                <h3 className="font-heading font-bold text-base sm:text-lg text-[#27343B]">
                  {item.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#66737A] leading-relaxed font-body">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* =========================================================================
          SEÇÃO 4: NOSSA ESTRUTURA (GALERIA DOS AMBIENTES)
          ========================================================================= */}
      <section className="py-20 lg:py-28 bg-[#F5F8F0]/40">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-14 space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#76A900] font-body">
              Instalações
            </span>
            <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-[#27343B]">
              Nossa Estrutura Acolhedora
            </h2>
            <p className="text-sm sm:text-base text-[#66737A] font-body">
              Ambientes integrados, ventilados e adaptados para o descanso e a socialização dos idosos.
            </p>
          </div>

          {/* Galeria interativa com Lightbox para visualização em tela cheia e alta resolução */}
          <InfrastructureGalleryLightbox onOpenVisitModal={onOpenVisitModal} />

          {/* CTA Box */}
          <div className="mt-16 p-8 sm:p-10 rounded-2xl bg-[#F5F8F0] border border-stone-200/80 text-center space-y-4 max-w-3xl mx-auto">
            <h3 className="font-heading font-bold text-xl sm:text-2xl text-[#073B91]">
              Deseja conhecer nossa história em detalhes?
            </h3>
            <p className="text-sm text-[#66737A] font-body max-w-xl mx-auto">
              Acesse a linha do tempo completa e saiba mais sobre as cinco décadas de dedicação em Juiz de Fora.
            </p>
            <div className="flex flex-wrap gap-3.5 justify-center pt-3">
              <button
                type="button"
                onClick={() => onNavigate('nossa-historia')}
                className="group inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all font-body cursor-pointer"
              >
                <span>Conhecer Nossa História</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              {onOpenVisitModal && (
                <button
                  type="button"
                  onClick={onOpenVisitModal}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#073B91] bg-white hover:bg-stone-50 border border-stone-300/90 rounded-xl shadow-2xs hover:shadow-xs hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all font-body cursor-pointer"
                >
                  <Calendar className="w-4 h-4 text-[#76A900]" />
                  <span>Agendar Visita ao Lar</span>
                </button>
              )}
              <button
                type="button"
                onClick={onOpenDonationModal}
                className="group inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold text-white bg-[#76A900] hover:bg-[#689400] rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all font-body cursor-pointer"
              >
                <Heart className="w-4 h-4 fill-white text-white group-hover:animate-pulse" />
                <span>Fazer uma Doação</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          SEÇÃO 5: PERGUNTAS FREQUENTES (FAQ INSTITUCIONAL)
          ========================================================================= */}
      <FaqSection
        onNavigate={onNavigate}
        onOpenVisitModal={onOpenVisitModal}
        onOpenDonationModal={onOpenDonationModal}
      />
    </div>
  );
};
