import React, { useState, useMemo } from 'react';
import { PageRoute, TransparencyDoc } from '../types';
import { TRANSPARENCY_DOCUMENTS } from '../data/institutionalData';
import {
  FileText,
  Download,
  Eye,
  CheckCircle2,
  Building,
  FileCheck2,
  X,
  AlertCircle,
  BarChart2,
} from 'lucide-react';
import { ImpactTransparencySection } from '../components/common/ImpactTransparencySection';
import { notifySuccess } from '../utils/notifications';

interface TransparencyPageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: () => void;
}

export const TransparencyPage: React.FC<TransparencyPageProps> = ({
  onNavigate,
  onOpenDonationModal,
}) => {
  const [activeTab, setActiveTab] = useState<'prestacao' | 'documentos'>('prestacao');
  const [selectedYear, setSelectedYear] = useState<string>('todos');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('todos');
  const [previewDoc, setPreviewDoc] = useState<TransparencyDoc | null>(null);
  const [downloadNotification, setDownloadNotification] = useState<string | null>(null);

  const availableYears = ['todos', '2025', '2024'];

  const filteredDocs = useMemo(() => {
    return TRANSPARENCY_DOCUMENTS.filter((doc) => {
      const matchTab =
        activeTab === 'prestacao'
          ? doc.category === 'prestacao'
          : doc.category !== 'prestacao';

      const matchYear =
        selectedYear === 'todos' || doc.year.toString() === selectedYear;

      const matchPeriod =
        selectedPeriod === 'todos' ||
        (doc.month && doc.month.toLowerCase().includes(selectedPeriod.toLowerCase()));

      return matchTab && matchYear && matchPeriod;
    });
  }, [activeTab, selectedYear, selectedPeriod]);

  const handleDownload = (doc: TransparencyDoc) => {
    setDownloadNotification(`Iniciando download de "${doc.title}" (${doc.fileSize})...`);
    notifySuccess(`Download iniciado: "${doc.title}" (${doc.fileSize})`);
    setTimeout(() => {
      setDownloadNotification(null);
    }, 3500);
  };

  return (
    <div className="w-full bg-white font-body">
      {/* Header Institucional */}
      <section className="bg-[#F5F8F0]/60 pt-16 pb-16 lg:pt-20 lg:pb-20 border-b border-stone-200/60">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#073B91] font-body">
              Governança & Prestação de Contas
            </span>
            <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-[#27343B] leading-[1.15] tracking-tight">
              Transparência que fortalece a confiança.
            </h1>
            <p className="text-base sm:text-lg text-[#66737A] font-body leading-relaxed">
              O Lar dos Idosos Santa Luiza de Marillac preza pela máxima lisura e responsabilidade na aplicação de cada doação recebida da sociedade civil e convênios públicos.
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <a
                href="#transparencia-impacto"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#073B91] hover:bg-[#052c6e] text-white text-xs font-bold transition-colors shadow-2xs"
              >
                <BarChart2 className="w-4 h-4" />
                <span>Ver Gráficos de Impacto</span>
              </a>
              <a
                href="#documentos-contabeis"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-stone-50 text-stone-700 border border-stone-200 text-xs font-bold transition-colors shadow-2xs"
              >
                <FileText className="w-4 h-4" />
                <span>Consultar Balancetes Oficiais</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Seção Interativa de Transparência de Impacto (Recharts) */}
      <ImpactTransparencySection
        onOpenDonationModal={onOpenDonationModal}
        onNavigate={onNavigate}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          const el = document.getElementById('documentos-contabeis');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* Conteúdo Principal com Abas de Documentos Oficiais */}
      <section id="documentos-contabeis" className="py-16 lg:py-24 bg-stone-50/50">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          {/* Toast de Download */}
          {downloadNotification && (
            <div className="mb-8 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs sm:text-sm flex items-center justify-between shadow-xs font-body">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{downloadNotification}</span>
              </div>
              <button
                type="button"
                onClick={() => setDownloadNotification(null)}
                className="text-emerald-700 hover:text-emerald-900 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Abas Principais de Documentos */}
          <div className="border-b border-stone-200 flex flex-wrap gap-6 mb-10">
            <button
              type="button"
              onClick={() => {
                setActiveTab('prestacao');
                setSelectedPeriod('todos');
              }}
              className={`pb-4 px-1 text-base sm:text-lg font-heading font-bold transition-colors border-b-2 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'prestacao'
                  ? 'border-[#073B91] text-[#073B91]'
                  : 'border-transparent text-[#66737A] hover:text-[#27343B]'
              }`}
            >
              <FileCheck2 className="w-5 h-5 text-[#76A900]" />
              <span>Aba 1 — Prestação de Contas & Balancetes</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('documentos');
                setSelectedPeriod('todos');
              }}
              className={`pb-4 px-1 text-base sm:text-lg font-heading font-bold transition-colors border-b-2 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'documentos'
                  ? 'border-[#073B91] text-[#073B91]'
                  : 'border-transparent text-[#66737A] hover:text-[#27343B]'
              }`}
            >
              <Building className="w-5 h-5 text-[#073B91]" />
              <span>Aba 2 — Documentos Institucionais & Estatuto</span>
            </button>
          </div>

          {/* Barra de Filtros */}
          <div className="bg-[#F5F8F0] p-5 sm:p-6 rounded-2xl border border-stone-200/80 mb-10 flex flex-wrap items-center justify-between gap-4 text-xs font-body">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-[#27343B]">Filtrar por Ano:</span>
                <div className="flex gap-1.5">
                  {availableYears.map((yr) => (
                    <button
                      key={yr}
                      type="button"
                      onClick={() => setSelectedYear(yr)}
                      className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                        selectedYear === yr
                          ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                          : 'bg-white text-[#27343B] border border-stone-200 hover:bg-stone-50'
                      }`}
                    >
                      {yr === 'todos' ? 'Todos os Anos' : yr}
                    </button>
                  ))}
                </div>
              </div>

              {activeTab === 'prestacao' && (
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-[#27343B]">Período:</span>
                  <select
                    value={selectedPeriod}
                    onChange={(e) => setSelectedPeriod(e.target.value)}
                    className="bg-white border border-stone-300 rounded-md px-3 py-1.5 text-[#27343B] focus:ring-1 focus:ring-[#073B91]"
                  >
                    <option value="todos">Todos os períodos</option>
                    <option value="1º Trimestre">1º Trimestre (Jan - Mar)</option>
                    <option value="2º Trimestre">2º Trimestre (Abr - Jun)</option>
                    <option value="3º Trimestre">3º Trimestre (Jul - Set)</option>
                    <option value="4º Trimestre">4º Trimestre (Out - Dez)</option>
                  </select>
                </div>
              )}
            </div>

            <div className="text-[#66737A]">
              Total de documentos disponíveis: <strong className="text-stone-900">{filteredDocs.length}</strong>
            </div>
          </div>

          {/* Nota de Integridade */}
          <div className="p-5 mb-10 bg-white rounded-2xl border border-stone-200/80 text-xs text-[#66737A] flex items-start gap-3.5 font-body shadow-2xs">
            <AlertCircle className="w-5 h-5 text-[#073B91] shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-[#27343B]">
                Padrão de Integridade da Informação Contábil
              </p>
              <p className="mt-0.5 leading-relaxed">
                Os gráficos visuais acima consolidam as informações dos balancetes contábeis oficiais aprovados pelo Conselho Fiscal da instituição. Todos os relatórios detalhados e arquivos PDF originais rubricados estão disponíveis para download e consulta pública direta abaixo.
              </p>
            </div>
          </div>

          {/* Listagem de Documentos */}
          {filteredDocs.length === 0 ? (
            <div className="text-center py-16 bg-[#F5F8F0] rounded-2xl border border-stone-200 p-8 space-y-2 font-body">
              <FileText className="w-10 h-10 text-stone-400 mx-auto" />
              <p className="font-heading font-bold text-lg text-[#27343B]">
                Nenhum relatório encontrado para o filtro selecionado
              </p>
              <p className="text-xs text-[#66737A]">
                Alterne os filtros de ano ou trimestre para consultar outros exercícios contábeis.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredDocs.map((doc) => (
                <div
                  key={doc.id}
                  className="p-6 rounded-2xl bg-white border border-stone-200/80 shadow-2xs hover:border-[#073B91]/30 transition-all flex flex-col md:flex-row md:items-center justify-between gap-5 font-body"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#073B91]/10 text-[#073B91] flex items-center justify-center shrink-0">
                      <FileText className="w-6 h-6" />
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-semibold text-[#073B91]">
                          {doc.categoryLabel}
                        </span>
                        <span aria-hidden="true" className="text-stone-300">·</span>
                        <span className="text-[#66737A] font-mono">Exercício {doc.year}</span>
                        {doc.month && (
                          <>
                            <span aria-hidden="true" className="text-stone-300">·</span>
                            <span className="text-[#66737A]">{doc.month}</span>
                          </>
                        )}
                        <span aria-hidden="true" className="text-stone-300">·</span>
                        <span className="text-[#66737A] font-mono">{doc.fileSize}</span>
                      </div>

                      <h3 className="font-heading font-bold text-lg sm:text-xl text-[#27343B]">
                        {doc.title}
                      </h3>

                      <p className="text-xs sm:text-sm text-[#66737A] leading-relaxed max-w-3xl">
                        {doc.summary}
                      </p>

                      <p className="text-[11px] text-[#66737A] pt-1 font-mono">
                        Publicado em: {doc.publishDate}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end md:self-center shrink-0 pt-2 md:pt-0">
                    <button
                      type="button"
                      onClick={() => setPreviewDoc(doc)}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-[#073B91] bg-stone-100 hover:bg-[#F5F8F0] rounded-lg transition-colors border border-stone-200 cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Visualizar</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDownload(doc)}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-white bg-[#76A900] hover:bg-[#679400] rounded-lg transition-colors shadow-2xs cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Baixar PDF</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Modal de Pré-visualização de Documento */}
      {previewDoc && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200 font-body"
        >
          <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-stone-300 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-[#F5F8F0]">
              <div className="flex items-center gap-3">
                <span className="p-2 bg-[#073B91] text-white rounded-lg">
                  <FileText className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-heading font-bold text-sm sm:text-base text-[#073B91]">
                    Visualizador de Documento Oficial
                  </h3>
                  <p className="text-xs text-[#66737A]">
                    {previewDoc.title} ({previewDoc.fileSize})
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleDownload(previewDoc)}
                  className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 rounded-lg transition-colors cursor-pointer"
                  title="Baixar cópia"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDoc(null)}
                  className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 rounded-lg transition-colors cursor-pointer"
                  aria-label="Fechar visualizador"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="p-6 sm:p-8 overflow-y-auto bg-stone-100 flex justify-center">
              <div className="w-full max-w-2xl bg-white shadow-md border border-stone-300 p-8 sm:p-12 min-h-[480px] flex flex-col justify-between text-stone-800">
                <div className="border-b-2 border-stone-800 pb-4 text-center space-y-1">
                  <p className="text-[10px] tracking-widest uppercase font-semibold text-stone-500 font-body">
                    República Federativa do Brasil · Estado de Minas Gerais
                  </p>
                  <h2 className="font-heading font-bold text-base sm:text-lg text-[#073B91]">
                    LAR DOS IDOSOS SANTA LUIZA DE MARILLAC
                  </h2>
                  <p className="text-xs text-stone-600 font-body">
                    Instituição de Longa Permanência para Idosos (ILPI) · Juiz de Fora - MG
                  </p>
                </div>

                <div className="my-8 space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed font-body">
                  <div className="p-3 bg-stone-50 border border-stone-200 rounded-lg">
                    <p className="font-semibold text-[#073B91]">Documento:</p>
                    <p className="font-medium text-stone-900">{previewDoc.title}</p>
                    <p className="text-stone-500 text-xs mt-1">Categoria: {previewDoc.categoryLabel} · Exercício: {previewDoc.year}</p>
                  </div>

                  <p>
                    O Lar dos Idosos Santa Luiza de Marillac atesta, para os devidos fins de transparência pública, que os registros do exercício de {previewDoc.year} foram conferidos e homologados pelos responsáveis contábeis.
                  </p>

                  <div className="p-4 rounded-xl bg-[#F5F8F0] border border-stone-200 space-y-1.5 text-xs text-stone-700">
                    <p className="font-semibold text-stone-900 font-heading">Síntese do Relatório:</p>
                    <p>{previewDoc.summary}</p>
                  </div>
                </div>

                <div className="pt-8 border-t border-stone-300 grid grid-cols-2 gap-6 text-center text-xs text-stone-600 font-body">
                  <div>
                    <div className="h-0.5 w-32 bg-stone-400 mx-auto mb-1" />
                    <p className="font-semibold text-stone-800">Diretoria Executiva</p>
                    <p className="text-[11px]">Lar Santa Luiza de Marillac</p>
                  </div>
                  <div>
                    <div className="h-0.5 w-32 bg-stone-400 mx-auto mb-1" />
                    <p className="font-semibold text-stone-800">Conselho Fiscal</p>
                    <p className="text-[11px]">Aprovação em Ata</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 py-3.5 bg-stone-50 border-t border-stone-200 flex justify-between items-center text-xs text-[#66737A]">
              <span>Documento institucional oficial</span>
              <button
                type="button"
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 font-body transition-colors cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
