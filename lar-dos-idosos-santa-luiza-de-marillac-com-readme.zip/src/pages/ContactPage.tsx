import React, { useState } from 'react';
import { PageRoute } from '../types';
import { INSTITUTION_INFO } from '../data/institutionalData';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  MapPin,
  Phone,
  Mail,
  Instagram,
  Clock,
  Send,
  CheckCircle2,
  ExternalLink,
  MessageSquare,
  Bus,
} from 'lucide-react';
import { FaqSection } from '../components/common/FaqSection';
import { InteractiveMapSection } from '../components/common/InteractiveMapSection';
import { notifySuccess } from '../utils/notifications';

const contactSchema = z.object({
  fullName: z.string().min(3, 'Por favor, informe seu nome completo (mínimo 3 caracteres)'),
  email: z.string().email('Informe um endereço de e-mail válido'),
  phone: z.string().min(10, 'Informe um telefone válido com DDD'),
  subject: z.enum([
    'informacoes',
    'doacoes',
    'voluntariado',
    'parcerias',
    'prestacao_contas',
    'outros',
  ] as const),
  message: z.string().min(10, 'Sua mensagem deve conter no mínimo 10 caracteres'),
  consentLgpd: z.boolean().refine((val) => val === true, {
    message: 'É necessário concordar com o tratamento dos dados pessoais conforme a LGPD',
  }),
});

type ContactFormData = z.infer<typeof contactSchema>;

interface ContactPageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenPrivacyModal: () => void;
  onOpenVisitModal?: () => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({
  onNavigate,
  onOpenPrivacyModal,
  onOpenVisitModal,
}) => {
  const [isSuccess, setIsSuccess] = useState(false);
  const [submittedData, setSubmittedData] = useState<ContactFormData | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      subject: 'informacoes',
      message: '',
      consentLgpd: false,
    },
  });

  const onSubmit = (data: ContactFormData) => {
    setSubmittedData(data);
    setIsSuccess(true);
    notifySuccess('Mensagem enviada com sucesso! Responderemos o mais breve possível.');
  };

  const handleOpenWhatsAppFromMessage = () => {
    if (!submittedData) return;
    const subjectLabels: Record<string, string> = {
      informacoes: 'Informações sobre a instituição',
      doacoes: 'Doações e Corrente do Bem',
      voluntariado: 'Voluntariado',
      parcerias: 'Parcerias',
      prestacao_contas: 'Prestação de contas',
      outros: 'Outros assuntos',
    };

    const text = encodeURIComponent(
      `Olá! Meu nome é ${submittedData.fullName}.\n` +
      `Assunto: ${subjectLabels[submittedData.subject] || submittedData.subject}\n` +
      `Mensagem: ${submittedData.message}\n` +
      `Telefone de contato: ${submittedData.phone}`
    );
    window.open(`https://wa.me/${INSTITUTION_INFO.whatsappClean}?text=${text}`, '_blank');
  };

  return (
    <div className="w-full bg-white font-body">
      {/* Header Institucional */}
      <section className="bg-[#F5F8F0]/60 pt-16 pb-16 lg:pt-20 lg:pb-20 border-b border-stone-200/60">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#76A900] font-body">
              Canais de Contato
            </span>
            <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-[#27343B] leading-[1.15] tracking-tight">
              Fale com o Lar Santa Luiza de Marillac.
            </h1>
            <p className="text-base sm:text-lg text-[#66737A] font-body leading-relaxed">
              Estamos de portas e corações abertos para tirar dúvidas, receber doações, acolher voluntários e atender à comunidade de Juiz de Fora.
            </p>
          </div>
        </div>
      </section>

      {/* Formulário e Contatos */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            {/* Coluna Esquerda: Formulário de Mensagem */}
            <div className="lg:col-span-7 bg-[#F5F8F0] p-8 sm:p-10 rounded-2xl border border-stone-200/80 shadow-2xs">
              <div className="mb-8 space-y-1">
                <h2 className="font-heading font-bold text-2xl text-[#073B91]">
                  Envie sua Mensagem
                </h2>
                <p className="text-xs sm:text-sm text-[#66737A] font-body">
                  Preencha o formulário abaixo para entrar em contato com nossa equipe administrativa.
                </p>
              </div>

              {isSuccess && submittedData ? (
                <div className="bg-white p-8 rounded-2xl border border-stone-200 text-center space-y-4 font-body">
                  <div className="w-12 h-12 bg-[#76A900]/15 text-[#76A900] rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="font-heading font-bold text-xl text-[#073B91]">
                      Mensagem Recebida com Sucesso!
                    </h3>
                    <p className="text-xs sm:text-sm text-[#66737A] mt-1">
                      Agradecemos pelo seu contato, <strong>{submittedData.fullName}</strong>. Retornaremos pelo e-mail ou telefone informado.
                    </p>
                  </div>

                  <div className="p-4 bg-[#F5F8F0] rounded-xl text-xs text-[#66737A] text-left space-y-1">
                    <p><strong>Assunto:</strong> {submittedData.subject}</p>
                    <p className="line-clamp-2"><strong>Mensagem:</strong> {submittedData.message}</p>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                    <button
                      type="button"
                      onClick={handleOpenWhatsAppFromMessage}
                      className="inline-flex items-center justify-center gap-1.5 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#76A900] hover:bg-[#679400] rounded-lg transition-colors"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Agilizar no WhatsApp Oficial</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setIsSuccess(false);
                        setSubmittedData(null);
                        reset();
                      }}
                      className="px-5 py-2.5 text-xs sm:text-sm font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
                    >
                      Enviar outra mensagem
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-5 font-body">
                  {/* Nome Completo */}
                  <div>
                    <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1.5">
                      Nome completo <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      {...register('fullName')}
                      placeholder="Seu nome e sobrenome"
                      className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                    />
                    {errors.fullName && (
                      <p className="text-xs text-red-600 mt-1">{errors.fullName.message}</p>
                    )}
                  </div>

                  {/* E-mail e Telefone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1.5">
                        E-mail <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        {...register('email')}
                        placeholder="seuemail@exemplo.com"
                        className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                      />
                      {errors.email && (
                        <p className="text-xs text-red-600 mt-1">{errors.email.message}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1.5">
                        Telefone / WhatsApp <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="tel"
                        {...register('phone')}
                        placeholder="(32) 99999-9999"
                        className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                      />
                      {errors.phone && (
                        <p className="text-xs text-red-600 mt-1">{errors.phone.message}</p>
                      )}
                    </div>
                  </div>

                  {/* Assunto */}
                  <div>
                    <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1.5">
                      Assunto da mensagem <span className="text-red-500">*</span>
                    </label>
                    <select
                      {...register('subject')}
                      className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors"
                    >
                      <option value="informacoes">Informações sobre a instituição</option>
                      <option value="doacoes">Doações e Corrente do Bem</option>
                      <option value="voluntariado">Voluntariado</option>
                      <option value="parcerias">Parcerias e Apoio</option>
                      <option value="prestacao_contas">Prestação de Contas</option>
                      <option value="outros">Outros assuntos</option>
                    </select>
                    {errors.subject && (
                      <p className="text-xs text-red-600 mt-1">{errors.subject.message}</p>
                    )}
                  </div>

                  {/* Mensagem */}
                  <div>
                    <label className="block text-xs font-semibold text-[#27343B] uppercase tracking-wider mb-1.5">
                      Mensagem <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      {...register('message')}
                      rows={4}
                      placeholder="Escreva sua dúvida, proposta ou mensagem..."
                      className="w-full px-4 py-3 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors resize-none"
                    />
                    {errors.message && (
                      <p className="text-xs text-red-600 mt-1">{errors.message.message}</p>
                    )}
                  </div>

                  {/* Termo LGPD */}
                  <div className="pt-1">
                    <label className="flex items-start gap-2.5 cursor-pointer text-xs text-[#66737A] select-none">
                      <input
                        type="checkbox"
                        {...register('consentLgpd')}
                        className="mt-0.5 rounded-sm border-stone-300 text-[#073B91] focus:ring-[#073B91] h-4 w-4"
                      />
                      <span>
                        Concordo com o armazenamento e processamento dos meus dados para atendimento desta mensagem nos termos da{' '}
                        <button
                          type="button"
                          onClick={onOpenPrivacyModal}
                          className="text-[#073B91] underline underline-offset-2"
                        >
                          Política de Privacidade (LGPD)
                        </button>
                        .
                      </span>
                    </label>
                    {errors.consentLgpd && (
                      <p className="text-xs text-red-600 mt-1">{errors.consentLgpd.message}</p>
                    )}
                  </div>

                  {/* Botão de Envio */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="group w-full sm:w-auto px-8 py-3.5 text-sm font-bold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                    >
                      <Send className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                      <span>{isSubmitting ? 'Enviando...' : 'Enviar mensagem'}</span>
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Coluna Direita: Informações Institucionais */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white p-8 rounded-2xl border border-stone-200/80 shadow-2xs space-y-6">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#76A900] font-body">
                    Atendimento Oficial
                  </span>
                  <h3 className="font-heading font-bold text-2xl text-[#27343B] mt-1">
                    Informações de Contato
                  </h3>
                </div>

                <ul className="space-y-5 text-sm text-[#27343B] font-body">
                  <li className="flex items-start gap-3.5">
                    <div className="p-2.5 bg-[#F5F8F0] rounded-xl text-[#073B91] shrink-0">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="block text-[#27343B]">Endereço da Sede:</strong>
                      <span className="font-medium text-[#27343B]">{INSTITUTION_INFO.address}</span>
                      <p className="text-xs text-[#66737A] mt-0.5">
                        {INSTITUTION_INFO.addressComplement} · CEP {INSTITUTION_INFO.cep}
                      </p>
                      <p className="text-xs font-semibold text-[#073B91] mt-1 flex items-center gap-1.5">
                        <Bus className="w-3.5 h-3.5 text-[#073B91]" />
                        <span>Ônibus: Linhas {INSTITUTION_INFO.busLinesText}</span>
                      </p>
                    </div>
                  </li>

                  <li className="flex items-start gap-3.5">
                    <div className="p-2.5 bg-[#F5F8F0] rounded-xl text-[#073B91] shrink-0">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="block text-[#27343B]">Telefone e Secretaria:</strong>
                      <a href={`tel:${INSTITUTION_INFO.phoneClean}`} className="hover:text-[#073B91] transition-colors">
                        {INSTITUTION_INFO.phone}
                      </a>
                    </div>
                  </li>

                  <li className="flex items-start gap-3.5">
                    <div className="p-2.5 bg-[#F5F8F0] rounded-xl text-[#76A900] shrink-0">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="block text-[#27343B]">WhatsApp Oficial:</strong>
                      <a
                        href={`https://wa.me/${INSTITUTION_INFO.whatsappClean}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#073B91] hover:underline"
                      >
                        {INSTITUTION_INFO.whatsapp}
                      </a>
                    </div>
                  </li>

                  <li className="flex items-start gap-3.5">
                    <div className="p-2.5 bg-[#F5F8F0] rounded-xl text-[#073B91] shrink-0">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="block text-[#27343B]">E-mail Institucional:</strong>
                      <a href={`mailto:${INSTITUTION_INFO.email}`} className="hover:text-[#073B91] transition-colors break-all">
                        {INSTITUTION_INFO.email}
                      </a>
                    </div>
                  </li>

                  <li className="flex items-start gap-3.5">
                    <div className="p-2.5 bg-[#F5F8F0] rounded-xl text-[#76A900] shrink-0">
                      <Instagram className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="block text-[#27343B]">Instagram Oficial:</strong>
                      <a
                        href={INSTITUTION_INFO.instagramUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#073B91] hover:underline inline-flex items-center gap-1"
                      >
                        <span>{INSTITUTION_INFO.instagram}</span>
                        <ExternalLink className="w-3.5 h-3.5 text-stone-400" />
                      </a>
                    </div>
                  </li>

                  <li className="flex items-start gap-3.5">
                    <div className="p-2.5 bg-[#F5F8F0] rounded-xl text-[#073B91] shrink-0">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div>
                      <strong className="block text-[#27343B]">Horários de Atendimento:</strong>
                      <span>{INSTITUTION_INFO.hours}</span>
                      <p className="text-xs text-[#66737A] mt-1">
                        {INSTITUTION_INFO.visitHours}.
                      </p>
                    </div>
                  </li>
                </ul>

                <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row gap-3">
                  <a
                    href="#mapa-interativo"
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold text-[#073B91] bg-[#F5F8F0] hover:bg-stone-200 border border-stone-300 rounded-lg transition-colors font-body"
                  >
                    <MapPin className="w-4 h-4 text-[#76A900]" />
                    <span>Ver no Mapa Interativo</span>
                  </a>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${INSTITUTION_INFO.googleMapsQuery}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-lg transition-colors font-body"
                  >
                    <span>Google Maps</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção do Mapa Interativo com Marcador no Lar Santa Luiza de Marillac (Juiz de Fora - MG) */}
      <InteractiveMapSection
        onOpenVisitModal={onOpenVisitModal}
      />

      {/* Accordion de Perguntas Frequentes */}
      <FaqSection
        onNavigate={onNavigate}
        onOpenVisitModal={onOpenVisitModal}
      />
    </div>
  );
};
