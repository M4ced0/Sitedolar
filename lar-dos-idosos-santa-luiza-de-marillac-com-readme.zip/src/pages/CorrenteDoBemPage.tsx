import React, { useState, useMemo } from 'react';
import { PageRoute, NeedItem } from '../types';
import { DEMO_NEEDS, INSTITUTION_INFO } from '../data/institutionalData';
import {
  Heart,
  Search,
  Package,
  MapPin,
  Phone,
  Clock,
  QrCode,
  Apple,
  Bath,
  Shirt,
  Box,
  CheckCircle2,
  Sparkles,
  Copy,
  Check,
} from 'lucide-react';

import { DonationImpactCalculator } from '../components/common/DonationImpactCalculator';
import { WireframePlaceholder } from '../components/common/WireframePlaceholder';

interface CorrenteDoBemPageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: (options?: any) => void;
}

export const CorrenteDoBemPage: React.FC<CorrenteDoBemPageProps> = ({
  onNavigate,
  onOpenDonationModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [selectedPriority, setSelectedPriority] = useState<string>('todos');
  const [selectedStatus, setSelectedStatus] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedPix, setCopiedPix] = useState(false);

  const handleCopyPix = () => {
    navigator.clipboard.writeText(INSTITUTION_INFO.email);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2500);
  };

  const categories = [
    { id: 'todos', label: 'Todas as categorias' },
    { id: 'alimentos', label: 'Alimentos' },
    { id: 'higiene', label: 'Higiene pessoal' },
    { id: 'limpeza', label: 'Produtos de limpeza' },
    { id: 'diario', label: 'Materiais de uso diário' },
    { id: 'outros', label: 'Outros' },
  ];

  const priorities = [
    { id: 'todos', label: 'Todas' },
    { id: 'alta', label: 'Alta' },
    { id: 'media', label: 'Média' },
    { id: 'regular', label: 'Regular' },
  ];

  const statuses = [
    { id: 'todos', label: 'Todos os status' },
    { id: 'ativa', label: 'Necessidade ativa' },
    { id: 'em_andamento', label: 'Em andamento' },
    { id: 'atendida', label: 'Atendida' },
  ];

  const filteredNeeds = useMemo(() => {
    return DEMO_NEEDS.filter((item) => {
      const matchCategory = selectedCategory === 'todos' || item.category === selectedCategory;
      const matchPriority = selectedPriority === 'todos' || item.priority === selectedPriority;
      const matchStatus = selectedStatus === 'todos' || item.status === selectedStatus;
      const matchSearch =
        searchQuery === '' ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());

      return matchCategory && matchPriority && matchStatus && matchSearch;
    });
  }, [selectedCategory, selectedPriority, selectedStatus, searchQuery]);

  const getItemCategoryIcon = (category: string) => {
    switch (category) {
      case 'alimentos':
        return <Apple className="w-5 h-5 text-[#76A900]" />;
      case 'higiene':
        return <Bath className="w-5 h-5 text-[#073B91]" />;
      case 'limpeza':
        return <Sparkles className="w-5 h-5 text-[#76A900]" />;
      case 'diario':
        return <Shirt className="w-5 h-5 text-[#073B91]" />;
      default:
        return <Box className="w-5 h-5 text-stone-600" />;
    }
  };

  const getPriorityBadgeClass = (priority: string) => {
    switch (priority) {
      case 'alta':
        return 'text-red-700 bg-red-50 border-red-200';
      case 'media':
        return 'text-amber-800 bg-amber-50 border-amber-200';
      default:
        return 'text-stone-700 bg-stone-100 border-stone-200';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'atendida':
        return (
          <span className="inline-flex items-center gap-1 text-emerald-700 font-medium text-xs font-body">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Atendida
          </span>
        );
      case 'em_andamento':
        return (
          <span className="text-amber-700 font-medium text-xs font-body">
            Em arrecadação
          </span>
        );
      default:
        return (
          <span className="text-[#073B91] font-medium text-xs font-body">
            Necessidade aberta
          </span>
        );
    }
  };

  return (
    <div className="w-full bg-white font-body">
      {/* Apresentação Principal */}
      <section className="bg-[#F5F8F0]/60 pt-16 pb-16 lg:pt-20 lg:pb-20 border-b border-stone-200/60">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#76A900] font-body">
                Rede de Solidariedade
              </span>
              <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-[#27343B] leading-[1.15] tracking-tight">
                Corrente do Bem —{' '}
                <span className="text-[#073B91]">Sua ajuda transforma cuidado em acolhimento.</span>
              </h1>
              <p className="text-base sm:text-lg text-[#66737A] font-body leading-relaxed max-w-2xl">
                O Lar Santa Luiza de Marillac acolhe dezenas de idosos diariamente em Juiz de Fora. Esta página reúne as necessidades contínuas para que a comunidade possa contribuir com transparência e precisão.
              </p>
              <div className="p-4 bg-amber-50/80 rounded-xl border border-amber-200/80 text-xs text-amber-900 max-w-2xl font-body">
                <strong>Nota de Demonstração:</strong> Os itens listados abaixo são exemplos ilustrativos para validação visual e técnica da plataforma, prontos para receber a relação oficial de demandas da instituição.
              </div>
            </div>

            <div className="lg:col-span-4">
              <WireframePlaceholder
                label="Foto de Apoio Solidário & Doações"
                suggestedDimensions="800 × 600 px"
                aspectRatio="aspect-4/3"
                type="card"
                slotId="corrente-do-bem-hero"
                notes="Pequenos gestos que alimentam a esperança"
                className="w-full h-full min-h-[260px]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Catálogo de Necessidades com Filtros */}
      <section className="py-20 lg:py-28 bg-gradient-to-b from-[#FAFBF7] via-[#F4F8EE]/60 to-[#FAFBF7] border-b border-stone-200/80">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          {/* Barra de Filtros */}
          <div className="bg-[#F5F8F0] p-6 rounded-2xl border border-stone-200/80 mb-12 space-y-5 shadow-2xs">
            <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
              {/* Campo de Busca */}
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar necessidade por nome ou descrição..."
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#073B91] transition-colors font-body"
                />
              </div>

              {/* Filtros de Prioridade e Status */}
              <div className="flex flex-wrap items-center gap-3 text-xs font-body">
                <div className="flex items-center gap-1.5">
                  <span className="text-[#66737A] font-medium">Prioridade:</span>
                  <select
                    value={selectedPriority}
                    onChange={(e) => setSelectedPriority(e.target.value)}
                    className="bg-white border border-stone-300 rounded-md px-3 py-1.5 text-[#27343B] text-xs focus:ring-1 focus:ring-[#073B91]"
                  >
                    {priorities.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-[#66737A] font-medium">Status:</span>
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="bg-white border border-stone-300 rounded-md px-3 py-1.5 text-[#27343B] text-xs focus:ring-1 focus:ring-[#073B91]"
                  >
                    {statuses.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Abas de Categorias */}
            <div className="flex items-center gap-2 pt-2 border-t border-stone-200/70 overflow-x-auto pb-1">
              <span className="text-xs font-semibold text-[#66737A] whitespace-nowrap mr-1 font-body">
                Categorias:
              </span>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 font-body ${
                    selectedCategory === cat.id
                      ? 'bg-[#073B91] text-white shadow-2xs font-semibold'
                      : 'bg-white text-[#27343B] hover:bg-stone-100 border border-stone-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Resumo dos Resultados */}
          <div className="flex items-center justify-between text-xs text-[#66737A] mb-8 px-1 font-body">
            <span>
              Exibindo <strong>{filteredNeeds.length}</strong> {filteredNeeds.length === 1 ? 'item necessário' : 'itens necessários'}
            </span>
            <span>Atualizado para apoio contínuo</span>
          </div>

          {/* Grade de Itens */}
          {filteredNeeds.length === 0 ? (
            <div className="text-center py-16 bg-[#F5F8F0] rounded-2xl border border-stone-200 p-8 space-y-3">
              <Package className="w-10 h-10 text-stone-400 mx-auto" />
              <p className="font-heading font-bold text-lg text-[#27343B]">
                Nenhum item encontrado com os filtros atuais
              </p>
              <p className="text-xs text-[#66737A] font-body max-w-sm mx-auto">
                Tente redefinir a busca ou categoria para visualizar outras necessidades do Lar.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('todos');
                  setSelectedPriority('todos');
                  setSelectedStatus('todos');
                  setSearchQuery('');
                }}
                className="px-4 py-2 text-xs font-medium text-[#073B91] bg-white border border-stone-300 rounded-lg hover:bg-stone-50 font-body"
              >
                Limpar filtros
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredNeeds.map((need) => (
                <div
                  key={need.id}
                  className="bg-white rounded-xl border border-stone-200/80 p-6 flex flex-col justify-between shadow-2xs hover:shadow-xs transition-shadow"
                >
                  <div className="space-y-3.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="w-10 h-10 rounded-lg bg-[#F5F8F0] border border-stone-200 flex items-center justify-center shrink-0">
                        {getItemCategoryIcon(need.category)}
                      </div>
                      <span className={`px-2.5 py-0.5 rounded-sm border text-[11px] font-semibold font-body ${getPriorityBadgeClass(need.priority)}`}>
                        Prioridade {need.priority.toUpperCase()}
                      </span>
                    </div>

                    <div>
                      <span className="text-[11px] text-[#66737A] block uppercase tracking-wider font-semibold font-body">
                        {need.categoryLabel}
                      </span>
                      <h3 className="font-heading font-bold text-lg text-[#27343B] mt-1 leading-snug">
                        {need.name}
                      </h3>
                    </div>

                    <p className="text-xs sm:text-sm text-[#66737A] font-body leading-relaxed min-h-[40px]">
                      {need.description}
                    </p>

                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs font-body">
                      <span className="text-[#66737A]">Quantidade meta:</span>
                      <span className="font-semibold text-[#27343B] font-mono">
                        {need.quantityNeeded ? `${need.quantityNeeded} ${need.unit}` : need.unit}
                      </span>
                    </div>

                    <div className="pt-1 flex items-center justify-between text-xs font-body">
                      <span className="text-[#66737A]">Status:</span>
                      {getStatusBadge(need.status)}
                    </div>
                  </div>

                  <div className="pt-5 mt-4 border-t border-stone-100 flex items-center justify-between">
                    <span className="text-[11px] text-[#66737A] font-body">Exemplo</span>
                    <button
                      type="button"
                      onClick={() => onOpenDonationModal(need)}
                      className="group inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#76A900] hover:bg-[#689400] hover:-translate-y-0.5 active:translate-y-0 active:scale-95 rounded-xl transition-all shadow-2xs hover:shadow-xs font-body cursor-pointer"
                    >
                      <Heart className="w-3.5 h-3.5 fill-white group-hover:scale-110 transition-transform" />
                      <span>Quero doar</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Como Entregar a Doação */}
      <section className="py-20 lg:py-28 bg-[#F5F8F0]/60 border-b border-stone-200/60">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-14 space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#073B91] font-body">
              Logística & Acolhimento
            </span>
            <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-[#27343B]">
              Como Entregar a sua Doação
            </h2>
            <p className="text-sm sm:text-base text-[#66737A] font-body">
              Orientações para que seus donativos cheguem em segurança e com agilidade aos nossos residentes:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-7 rounded-xl border border-stone-200/80 space-y-3 shadow-2xs">
              <div className="w-10 h-10 rounded-lg bg-[#073B91]/10 text-[#073B91] flex items-center justify-center">
                <MapPin className="w-5 h-5" />
              </div>
              <h3 className="font-heading font-bold text-lg text-[#27343B]">
                1. Entrega Direta na Sede
              </h3>
              <p className="text-xs sm:text-sm text-[#66737A] font-body leading-relaxed">
                As doações podem ser entregues diretamente na portaria do Lar em Juiz de Fora:
                <br />
                <strong className="text-[#27343B] font-medium">{INSTITUTION_INFO.address}</strong>
                <br />
                <span className="text-xs text-[#66737A]">
                  {INSTITUTION_INFO.addressComplement} · CEP {INSTITUTION_INFO.cep}
                </span>
                <span className="block text-xs font-semibold text-[#073B91] mt-1">
                  Ônibus que atendem o local: Linhas {INSTITUTION_INFO.busLinesText}
                </span>
              </p>
            </div>

            <div className="bg-white p-7 rounded-xl border border-stone-200/80 space-y-3 shadow-2xs">
              <div className="w-10 h-10 rounded-lg bg-[#76A900]/15 text-[#76A900] flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="font-heading font-bold text-lg text-[#27343B]">
                2. Horários Recomendados
              </h3>
              <p className="text-xs sm:text-sm text-[#66737A] font-body leading-relaxed">
                De segunda a sexta-feira, das 08h às 17h. Aos sábados ou domingos, favor entrar em contato prévio para garantir a recepção pela equipe de plantão.
              </p>
            </div>

            <div className="bg-white p-7 rounded-xl border border-stone-200/80 space-y-3 shadow-2xs">
              <div className="w-10 h-10 rounded-lg bg-[#073B91]/10 text-[#073B91] flex items-center justify-center">
                <Phone className="w-5 h-5" />
              </div>
              <h3 className="font-heading font-bold text-lg text-[#27343B]">
                3. Alinhamento via WhatsApp
              </h3>
              <p className="text-xs sm:text-sm text-[#66737A] font-body leading-relaxed">
                Para itens volumosos ou arrecadações em campanhas de empresas e escolas, fale diretamente com nossa equipe pelo WhatsApp:{' '}
                <strong className="text-[#27343B] font-medium">{INSTITUTION_INFO.whatsapp}</strong>.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Calculadora de Impacto de Doação */}
      <DonationImpactCalculator
        onOpenDonationModal={onOpenDonationModal}
        onNavigate={onNavigate}
      />

      {/* Doações Financeiras (Área Reservada PIX) */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-8 sm:p-12 rounded-2xl bg-[#F5F8F0] border border-stone-200/80 space-y-6 max-w-4xl mx-auto">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-stone-200 pb-5">
              <div className="flex items-center gap-3">
                <span className="p-2.5 rounded-lg bg-[#073B91] text-white">
                  <QrCode className="w-6 h-6" />
                </span>
                <div>
                  <h3 className="font-heading text-xl sm:text-2xl font-bold text-[#073B91]">
                    Contribuições Financeiras (Chave PIX Oficial)
                  </h3>
                  <p className="text-xs text-[#66737A] font-body">
                    Apoio financeiro direto para manutenção da alimentação, medicamentos e rotina dos idosos
                  </p>
                </div>
              </div>
              <span className="text-xs font-semibold px-3 py-1 bg-emerald-50 text-[#4E7300] border border-emerald-200 rounded-md font-body">
                Entidade Filantrópica 100% Beneficente
              </span>
            </div>

            {/* Cartão de Cópia da Chave PIX em 1 Clique */}
            <div className="p-6 rounded-2xl bg-white border border-stone-200 shadow-2xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#76A900]">
                    Chave PIX Oficial (E-mail do Lar)
                  </span>
                  <div className="font-mono text-base sm:text-lg font-bold text-[#073B91] select-all break-all">
                    {INSTITUTION_INFO.email}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleCopyPix}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#F5F8F0] hover:bg-stone-200 text-[#073B91] font-bold text-xs sm:text-sm border border-stone-200 transition-all cursor-pointer shrink-0 shadow-2xs active:scale-95"
                >
                  {copiedPix ? (
                    <>
                      <Check className="w-4 h-4 text-[#76A900]" />
                      <span className="text-[#4E7300]">Chave Copiada com Sucesso!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-[#073B91]" />
                      <span>Copiar Chave PIX</span>
                    </>
                  )}
                </button>
              </div>

              <div className="p-4 bg-[#FAFBF7] rounded-xl border border-stone-200/90 text-xs text-[#5A666E] leading-relaxed">
                <p className="font-semibold text-[#27343B] mb-1">
                  Confirmação de doação & emissão de recibo filantrópico:
                </p>
                <p>
                  Após efetuar a transferência em seu banco, envie o comprovante para o nosso WhatsApp ou telefone <strong>{INSTITUTION_INFO.phone}</strong> para identificação e emissão de recibo de doação.
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => onOpenDonationModal()}
                className="group inline-flex items-center gap-2 px-7 py-3.5 text-xs sm:text-sm font-bold text-white bg-[#76A900] hover:bg-[#689400] rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all font-body cursor-pointer"
              >
                <Heart className="w-4 h-4 fill-white group-hover:scale-110 transition-transform" />
                <span>Registrar intenção de doação</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
