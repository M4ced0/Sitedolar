import React, { useState } from 'react';
import { PageRoute } from '../types';
import { TIMELINE_MILESTONES, INSTITUTION_INFO } from '../data/institutionalData';
import { motion } from 'motion/react';
import { ArrowRight, Clock, ShieldCheck, Heart, Award, Users } from 'lucide-react';

interface NossaHistoriaPageProps {
  onNavigate: (page: PageRoute) => void;
  onOpenDonationModal: () => void;
}

export const NossaHistoriaPage: React.FC<NossaHistoriaPageProps> = ({
  onNavigate,
  onOpenDonationModal,
}) => {
  const [activeMilestone, setActiveMilestone] = useState<number>(0);

  return (
    <div className="w-full bg-white">
      {/* Header institucional */}
      <section className="pt-16 pb-16 lg:pt-20 lg:pb-20 border-b border-stone-200/60 bg-[#F5F8F0]/50">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-semibold tracking-wider uppercase text-[#76A900] font-body">
              Trajetória & Memória
            </span>
            <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-[#27343B] tracking-tight leading-[1.15]">
              Mais de cinco décadas de história, acolhimento e dedicação.
            </h1>
            <p className="text-base sm:text-lg text-[#66737A] font-body leading-relaxed">
              O Lar dos Idosos Santa Luiza de Marillac é fruto da união da comunidade de Juiz de Fora em prol dos idosos que mais precisam de cuidado e afeto.
            </p>
          </div>
        </div>
      </section>

      {/* Estatísticas históricas em destaque */}
      <section className="py-12 border-b border-stone-200/60 bg-white">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="space-y-1">
              <span className="font-heading text-3xl sm:text-4xl font-bold text-[#073B91]">
                50+
              </span>
              <p className="text-xs sm:text-sm font-medium text-[#27343B] font-body">
                Anos de atividade ininterrupta
              </p>
              <p className="text-xs text-[#66737A] font-body">
                Fundação na década de 1970
              </p>
            </div>

            <div className="space-y-1">
              <span className="font-heading text-3xl sm:text-4xl font-bold text-[#76A900]">
                100%
              </span>
              <p className="text-xs sm:text-sm font-medium text-[#27343B] font-body">
                Caráter filantrópico
              </p>
              <p className="text-xs text-[#66737A] font-body">
                Entidade sem fins lucrativos
              </p>
            </div>

            <div className="space-y-1">
              <span className="font-heading text-3xl sm:text-4xl font-bold text-[#073B91]">
                24h
              </span>
              <p className="text-xs sm:text-sm font-medium text-[#27343B] font-body">
                Acolhimento contínuo
              </p>
              <p className="text-xs text-[#66737A] font-body">
                Acompanhamento e enfermagem
              </p>
            </div>

            <div className="space-y-1">
              <span className="font-heading text-3xl sm:text-4xl font-bold text-[#76A900]">
                JF - MG
              </span>
              <p className="text-xs sm:text-sm font-medium text-[#27343B] font-body">
                Juiz de Fora
              </p>
              <p className="text-xs text-[#66737A] font-body">
                Tradição no acolhimento
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Linha do Tempo Vertical Progressiva e Interativa */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            {/* Coluna Esquerda: Contexto Editorial */}
            <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
              <span className="text-xs font-semibold tracking-wider uppercase text-[#073B91] font-body">
                Linha do Tempo
              </span>
              <h2 className="font-heading text-2xl sm:text-3xl font-bold text-[#27343B] leading-tight">
                Os marcos que construíram a nossa história
              </h2>
              <p className="text-sm sm:text-base text-[#66737A] font-body leading-relaxed">
                Navegue pelos momentos decisivos da trajetória do Lar. Cada etapa representa o esforço conjunto de voluntários, religiosos, profissionais da saúde e doadores de Juiz de Fora.
              </p>

              <div className="p-4 rounded-xl bg-[#F5F8F0] border border-stone-200/80 text-xs text-[#66737A] space-y-1 font-body">
                <p className="font-semibold text-[#073B91]">
                  Nota sobre a documentação histórica:
                </p>
                <p>
                  Os marcos apresentados são registros preparatórios para inserção das atas de fundação e registros históricos definitivos do acervo da instituição.
                </p>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={onOpenDonationModal}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#76A900] hover:bg-[#679400] rounded-lg transition-colors shadow-xs"
                >
                  <Heart className="w-4 h-4 fill-white/20" />
                  <span>Apoie a continuidade desta história</span>
                </button>
              </div>
            </div>

            {/* Coluna Direita: Marcos Históricos Verticais */}
            <div className="lg:col-span-7">
              <div className="relative pl-6 sm:pl-8 border-l-2 border-[#76A900]/30 space-y-10">
                {TIMELINE_MILESTONES.map((milestone, index) => {
                  const isSelected = activeMilestone === index;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 15 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className={`relative cursor-pointer transition-all ${
                        isSelected ? 'opacity-100' : 'opacity-85 hover:opacity-100'
                      }`}
                      onClick={() => setActiveMilestone(index)}
                    >
                      {/* Ponto indicador na linha */}
                      <span
                        className={`absolute -left-[31px] sm:-left-[39px] top-1.5 w-4 h-4 rounded-full border-2 transition-colors ${
                          isSelected
                            ? 'bg-[#073B91] border-[#76A900]'
                            : 'bg-white border-stone-300'
                        }`}
                      />

                      <div
                        className={`p-6 rounded-xl border transition-all ${
                          isSelected
                            ? 'bg-[#F5F8F0] border-[#073B91]/30 shadow-xs'
                            : 'bg-white border-stone-200/80 hover:border-stone-300'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                          <span className="font-heading font-bold text-base text-[#073B91]">
                            {milestone.year}
                          </span>
                          <span className="text-xs font-medium text-[#76A900] font-body bg-white px-2 py-0.5 rounded border border-stone-200">
                            {milestone.tag}
                          </span>
                        </div>

                        <h3 className="font-heading font-bold text-lg text-[#27343B] mb-2">
                          {milestone.title}
                        </h3>

                        <p className="text-xs sm:text-sm text-[#66737A] font-body leading-relaxed">
                          {milestone.description}
                        </p>

                        <p className="text-[11px] text-[#66737A] pt-3 font-mono mt-2 border-t border-stone-200/60">
                          {milestone.isDemonstrativeNote}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Convite para conhecer as outras seções */}
      <section className="py-16 bg-[#F5F8F0] border-t border-stone-200/70">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <h3 className="font-heading text-xl sm:text-2xl font-bold text-[#27343B]">
            Quer saber mais sobre o atendimento e os serviços atuais?
          </h3>
          <p className="text-sm text-[#66737A] font-body max-w-xl mx-auto">
            Conheça as diretrizes da nossa instituição, nossa estrutura e os cuidados oferecidos diariamente.
          </p>
          <div className="flex flex-wrap gap-3.5 justify-center pt-3">
            <button
              type="button"
              onClick={() => onNavigate('sobre')}
              className="group inline-flex items-center gap-2 px-6 py-3 text-sm font-bold text-white bg-[#073B91] hover:bg-[#052c6e] rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all cursor-pointer"
            >
              <span>Conhecer Nossos Cuidados</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('corrente-do-bem')}
              className="group inline-flex items-center gap-2 px-6 py-3 text-sm font-bold text-[#76A900] hover:text-white bg-white hover:bg-[#76A900] border-2 border-[#76A900] rounded-xl shadow-2xs hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all cursor-pointer"
            >
              <Heart className="w-4 h-4 fill-[#76A900]/20 group-hover:fill-white text-current group-hover:animate-pulse" />
              <span>Ver Necessidades na Corrente do Bem</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
